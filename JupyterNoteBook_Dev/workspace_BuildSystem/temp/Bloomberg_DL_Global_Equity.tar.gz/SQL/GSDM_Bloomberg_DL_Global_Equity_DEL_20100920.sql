set define off;

Delete FROM FT_T_EQST WHERE eqst_oid in (Select eqst_oid from ft_t_eqst a 
where exists(Select 1 from ft_t_eqst where instr_id = a.instr_id and mkt_oid = a.mkt_oid and stats_curr_cde is null)
and exists(Select 1 from ft_t_eqst where instr_id = a.instr_id and mkt_oid = a.mkt_oid and stats_curr_cde is not null))
AND STATS_CURR_CDE IS NULL and last_chg_usr_id='BBEQEURO';

set define on;