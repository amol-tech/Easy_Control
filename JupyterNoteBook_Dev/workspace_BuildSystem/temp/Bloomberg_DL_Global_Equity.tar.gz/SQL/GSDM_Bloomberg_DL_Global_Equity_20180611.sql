SET DEFINE OFF;
-- | GT Ticket #: 148243
-- | Date: 2018-06-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Renita Raphael
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISGU,FT_T_IRGU,FT_T_FIGU
-- | Change Reason: Script to update GU_TYP to 'UNKNOWN' for standalone records whose GU_TYP is COUNTRY and GU_ID is UNKNOWN in ISGU,IRGU tables.
-- |               In case of duplicate ISGU records with same INSTR_ID,ISS_GU_PURP_TYP & GU_ID=UNKNOWN, script enddates the record with GU_TYP=COUNTRY
-- |               and retains the record with GU_TYP=UNKNOWN.
-- |               In case of duplicate IRGU records with same INSTR_ISSR_ID,ISSR_GU_PURP_TYP & GU_ID=UNKNOWN, script enddates the record with GU_TYP=COUNTRY
-- |               and retains the record with GU_TYP=UNKNOWN
-- |               In case of duplicate FIGU records with same INST_MNEM,FINS_GU_PURP_TYP & GU_ID=UNKNOWN, script enddates the record with GU_TYP=COUNTRY
-- |               and retains the record with GU_TYP=UNKNOWN              
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20180611.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISGU_BKP_148243 AS SELECT   *
        FROM   (SELECT   A.*,
                         ROW_NUMBER ()
                            OVER (PARTITION BY INSTR_ID, ISS_GU_PURP_TYP
                                  ORDER BY GU_TYP DESC)
                            AS CNT
                  FROM   FT_T_ISGU A
                 WHERE       TRIM(GU_ID) = ''UNKNOWN''
                         AND TRIM(ISS_GU_PURP_TYP) = ''TRADING''
                         AND TRIM(GU_TYP) IN (''UNKNOWN'', ''COUNTRY'')
                         AND END_TMS IS NULL
                         AND REGEXP_LIKE (LAST_CHG_USR_ID,''BBCRDRSK|BBCGCPFD|CURRFXRT|BBPREFPX|BBCERT|BBCOMOPT|BBEURWRT|BBMORTP|BBCMDTPX|BBMOTGNP|BBEQPREM|EQOPPREM|BBEXTDWI|BBINDXPX|BBINXEPX|BBEQEURO|BBGLMFND|BBPREFRD|BBEXTDPF|BBMUNICP|BBOPTEUR'')) B
       WHERE   B.GU_TYP = ''COUNTRY''';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_T_ISGU_BKP_148243  ADD CONSTRAINT FT_T_ISGU_BKP_148243_PK  PRIMARY KEY (ISGU_OID)';

   EXECUTE IMMEDIATE 'CREATE TABLE FT_T_IRGU_BKP_148243 AS  SELECT   *
        FROM   (SELECT   A.*,
                         ROW_NUMBER ()
                            OVER (
                               PARTITION BY INSTR_ISSR_ID, ISSR_GU_PURP_TYP
                               ORDER BY GU_TYP DESC
                            )
                            AS CNT
                  FROM   FT_T_IRGU A
                 WHERE       TRIM(GU_ID) = ''UNKNOWN''
                         AND TRIM(GU_TYP) IN (''UNKNOWN'', ''COUNTRY'')
                         AND TRIM(ISSR_GU_PURP_TYP) in (''DOMICILE'',''INCRPRTE'')
                         AND END_TMS IS NULL
                         AND REGEXP_LIKE (LAST_CHG_USR_ID,''BBCRDRSK|BBCGCPFD|CURRFXRT|BBPREFPX|BBCERT|BBCOMOPT|BBEURWRT|BBMORTP|BBCMDTPX|BBMOTGNP|BBEQPREM|EQOPPREM|BBEXTDWI|BBINDXPX|BBINXEPX|BBEQEURO|BBGLMFND|BBPREFRD|BBEXTDPF|BBMUNICP|BBOPTEUR'')) B
       WHERE   B.GU_TYP = ''COUNTRY''';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_T_IRGU_BKP_148243  ADD CONSTRAINT FT_T_IRGU_BKP_148243_PK  PRIMARY KEY (IRGU_OID)';

     EXECUTE IMMEDIATE 'CREATE TABLE FT_T_FIGU_BKP_148243 AS  SELECT   *
        FROM   (SELECT   A.*,
                         ROW_NUMBER ()
                            OVER (
                               PARTITION BY INST_MNEM, FINS_GU_PURP_TYP
                               ORDER BY GU_TYP DESC
                            )
                            AS CNT
                  FROM   FT_T_FIGU A
                 WHERE       TRIM(GU_ID) = ''UNKNOWN''
                         AND TRIM(GU_TYP) IN (''UNKNOWN'', ''COUNTRY'')
                         AND TRIM(FINS_GU_PURP_TYP)  IN  (''DOMICILE'',''INCRPRTE'')
                         AND REGEXP_LIKE (LAST_CHG_USR_ID,''BBCRDRSK|BBCGCPFD|CURRFXRT|BBPREFPX|BBCERT|BBCOMOPT|BBEURWRT|BBMORTP|BBCMDTPX|BBMOTGNP|BBEQPREM|EQOPPREM|BBEXTDWI|BBINDXPX|BBINXEPX|BBEQEURO|BBGLMFND|BBPREFRD|BBEXTDPF|BBMUNICP|BBOPTEUR'')
                         AND END_TMS IS NULL) B
       WHERE   B.GU_TYP = ''COUNTRY''';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_T_FIGU_BKP_148243  ADD CONSTRAINT FT_T_FIGU_BKP_148243_PK  PRIMARY KEY (FIGU_OID)';

END;

DECLARE
   CURSOR CUR_ISGU
   IS
      SELECT   * FROM FT_T_ISGU_BKP_148243;

   CURSOR CUR_IRGU
   IS
      SELECT   * FROM FT_T_IRGU_BKP_148243;
   
   CURSOR CUR_FIGU
   IS
      SELECT   * FROM FT_T_FIGU_BKP_148243;
      
BEGIN
   FOR I IN CUR_ISGU
   LOOP
      UPDATE   FT_T_ISGU
         SET   GU_TYP = CASE WHEN I.CNT = 1 THEN 'UNKNOWN' ELSE GU_TYP END,
               END_TMS = CASE WHEN I.CNT = 2 THEN SYSDATE ELSE END_TMS END,
               LAST_CHG_USR_ID = 'GS:MIG:148243:' || LAST_CHG_USR_ID,
               LAST_CHG_TMS=SYSDATE
       WHERE   ISGU_OID = I.ISGU_OID;

      COMMIT;
   END LOOP;

   FOR I IN CUR_IRGU
   LOOP
      UPDATE   FT_T_IRGU
         SET   GU_TYP = CASE WHEN I.CNT = 1 THEN 'UNKNOWN' ELSE GU_TYP END,
               END_TMS = CASE WHEN I.CNT = 2 THEN SYSDATE ELSE END_TMS END,
               LAST_CHG_USR_ID = 'GS:MIG:148243:' || LAST_CHG_USR_ID,
               LAST_CHG_TMS=SYSDATE
       WHERE   IRGU_OID = I.IRGU_OID;

      COMMIT;
   END LOOP;
   
   FOR I IN CUR_FIGU
   LOOP
      UPDATE   FT_T_FIGU
         SET   GU_TYP = CASE WHEN I.CNT = 1 THEN 'UNKNOWN' ELSE GU_TYP END,
               END_TMS = CASE WHEN I.CNT = 2 THEN SYSDATE ELSE END_TMS END,
               LAST_CHG_USR_ID = 'GS:MIG:148243:' || LAST_CHG_USR_ID,
               LAST_CHG_TMS=SYSDATE
       WHERE   FIGU_OID = I.FIGU_OID;

      COMMIT;
   END LOOP;

EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || ' and Message ' || SQLERRM
      );
END;

INSERT INTO FT_O_SCTL (
                          PATCH_ID,
                          PATCH_SEQ_NUM,
                          PATCH_ID_CTXT_TYP,
                          RELEASE_TMS,
                          BASE_MODL_VER_ID,
                          CURR_MODL_VER_ID,
                          PATCH_STAT_TYP,
                          PATCH_APPLIED_TMS
           )
  VALUES   (
               'GSDM_Bloomberg_DL_Global_Equity_20180611.sql',
               1,
               'GT148243',
               SYSDATE,
               '8.99.71.2',
               '8.99.71.3',
               'A',
               SYSDATE
           );

COMMIT;

SET DEFINE ON;