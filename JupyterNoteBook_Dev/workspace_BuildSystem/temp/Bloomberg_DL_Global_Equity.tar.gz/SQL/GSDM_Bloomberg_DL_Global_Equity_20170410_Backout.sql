SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454205
-- | GT Ticket #: 132863
-- | Date: 2017-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_INCL, FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to update data  WHERE INDUS_CL_SET_ID = 'NAICS'
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170410.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_BAK_INCL
   IS
      SELECT   * FROM FT_BAK_INCL_GT132863;

   TYPE TAB_BAK_INCL IS TABLE OF CUR_BAK_INCL%ROWTYPE;

   VAR_BAK_INCL   TAB_BAK_INCL;

   CURSOR CUR_BAK_FICL
   IS
      SELECT   *
        FROM   FT_BAK_FICL_GT132863
       WHERE   FINS_CLSF_OID IN (SELECT   FINS_CLSF_OID
                                   FROM   FT_T_FICL
                                  WHERE   LAST_CHG_USR_ID LIKE '%132863%');

   TYPE TAB_BAK_FICL IS TABLE OF CUR_BAK_FICL%ROWTYPE;

   VAR_BAK_FICL   TAB_BAK_FICL;

   CURSOR CUR_BAK_IRCL
   IS
      SELECT   *
        FROM   FT_BAK_IRCL_GT132863
       WHERE   ISSR_CLSF_OID IN (SELECT   ISSR_CLSF_OID
                                   FROM   FT_T_IRCL
                                  WHERE   LAST_CHG_USR_ID LIKE '%132863%');

   TYPE TAB_BAK_IRCL IS TABLE OF CUR_BAK_IRCL%ROWTYPE;

   VAR_BAK_IRCL   TAB_BAK_IRCL;


   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_BAK_INCL;

   LOOP
      FETCH CUR_BAK_INCL BULK COLLECT INTO   VAR_BAK_INCL LIMIT 10000;

      FORALL I IN 1 .. VAR_BAK_INCL.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_INCL
            SET   LAST_CHG_TMS = VAR_BAK_INCL (I).LAST_CHG_TMS,
                  LAST_CHG_USR_ID = VAR_BAK_INCL (I).LAST_CHG_USR_ID,
                  END_TMS = VAR_BAK_INCL (I).END_TMS
          WHERE   CLSF_OID = VAR_BAK_INCL (I).CLSF_OID
                  AND CL_VALUE = VAR_BAK_INCL (I).CL_VALUE;

      COMMIT;

      EXIT WHEN CUR_BAK_INCL%NOTFOUND;
   END LOOP;

   CLOSE CUR_BAK_INCL;

   OPEN CUR_BAK_FICL;

   LOOP
      FETCH CUR_BAK_FICL BULK COLLECT INTO   VAR_BAK_FICL LIMIT 10000;

      FORALL I IN 1 .. VAR_BAK_FICL.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_FICL
            SET   CLSF_OID = VAR_BAK_FICL (I).CLSF_OID,
                  CL_VALUE = VAR_BAK_FICL (I).CL_VALUE,
                  LAST_CHG_TMS = VAR_BAK_FICL (I).LAST_CHG_TMS,
                  LAST_CHG_USR_ID = VAR_BAK_FICL (I).LAST_CHG_USR_ID,
                  END_TMS = VAR_BAK_FICL (I).END_TMS
          WHERE   FINS_CLSF_OID = VAR_BAK_FICL (I).FINS_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_BAK_FICL%NOTFOUND;
   END LOOP;

   CLOSE CUR_BAK_FICL;

   OPEN CUR_BAK_IRCL;

   LOOP
      FETCH CUR_BAK_IRCL BULK COLLECT INTO   VAR_BAK_IRCL LIMIT 10000;

      FORALL I IN 1 .. VAR_BAK_IRCL.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_IRCL
            SET   CLSF_OID = VAR_BAK_IRCL (I).CLSF_OID,
                  CL_VALUE = VAR_BAK_IRCL (I).CL_VALUE,
                  LAST_CHG_TMS = VAR_BAK_IRCL (I).LAST_CHG_TMS,
                  LAST_CHG_USR_ID = VAR_BAK_IRCL (I).LAST_CHG_USR_ID,
                  END_TMS = VAR_BAK_IRCL (I).END_TMS
          WHERE   ISSR_CLSF_OID = VAR_BAK_IRCL (I).ISSR_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_BAK_IRCL%NOTFOUND;
   END LOOP;

   CLOSE CUR_BAK_IRCL;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS
      );

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || V_COUNT
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
      END LOOP;
END;


