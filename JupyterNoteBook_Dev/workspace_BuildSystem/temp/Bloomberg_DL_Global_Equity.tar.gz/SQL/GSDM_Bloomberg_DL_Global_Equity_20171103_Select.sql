SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456382
-- | GT Ticket #:141093
-- | Date: 2017-10-27
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST
-- | Change Reason: Script to retrieve ISST records where STAT_DEF_ID ='POSEURPR'
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171103.sql
-- |----------------------------------------------------------------

SELECT   *
  FROM   FT_T_ISST A
 WHERE       END_TMS IS NULL
         AND STAT_DEF_ID = 'POSEURPR'
         AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

SET DEFINE ON;