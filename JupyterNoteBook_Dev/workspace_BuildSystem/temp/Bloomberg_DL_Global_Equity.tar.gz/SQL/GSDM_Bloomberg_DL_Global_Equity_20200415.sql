SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 475625
-- | GT Ticket #: 161951
-- | Date: 2020-04-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nusrat Khan
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to end-date multiple rows created for INDUSCLSETID = 'NAICS' in FICL and IRCL, keeping the latest row active based on LAST_CHG_TMS.
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20200415_Select.sql
-- |----------------------------------------------------------------

BEGIN

--BACKUP FICL

   EXECUTE IMMEDIATE
      'CREATE TABLE FT_BKP_FICL_161951
AS
SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT A.*,
               ROW_NUMBER ()
                  OVER (PARTITION BY INST_MNEM ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_FICL A
         WHERE     INDUS_CL_SET_ID = ''NAICS''
               AND END_TMS IS NULL)
 WHERE CNT > 1';


   EXECUTE IMMEDIATE
      'ALTER TABLE FT_BKP_FICL_161951 ADD CONSTRAINT FT_BKP_FICL_161951_PK PRIMARY KEY(FINS_CLSF_OID)';

--BACKUP IRCL

   EXECUTE IMMEDIATE
      'CREATE TABLE FT_BKP_IRCL_161951
AS
SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT A.*,
               ROW_NUMBER ()
                  OVER (PARTITION BY INSTR_ISSR_ID ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_IRCL A
         WHERE     INDUS_CL_SET_ID = ''NAICS''
               AND END_TMS IS NULL)
 WHERE CNT > 1';


   EXECUTE IMMEDIATE
      'ALTER TABLE FT_BKP_IRCL_161951 ADD CONSTRAINT FT_BKP_IRCL_161951_PK PRIMARY KEY(ISSR_CLSF_OID)';
END;


DECLARE

--CURSOR 1

   CURSOR CUR_FICL
   IS
      SELECT * FROM FT_BKP_FICL_161951;

   TYPE FICL_TAB IS TABLE OF CUR_FICL%ROWTYPE;

   VAR_FICL_TAB   FICL_TAB;

--CURSOR 2

   CURSOR CUR_IRCL
   IS
      SELECT * FROM FT_BKP_IRCL_161951;

   TYPE IRCL_TAB IS TABLE OF CUR_IRCL%ROWTYPE;

   VAR_IRCL_TAB   IRCL_TAB;

   V_NUMERRORS    NUMBER (10);
   
BEGIN

--ENDDATE FICL

   OPEN CUR_FICL;

   LOOP
      FETCH CUR_FICL
         BULK COLLECT INTO VAR_FICL_TAB
         LIMIT 10000;

      FORALL I IN 1 .. VAR_FICL_TAB.COUNT SAVE EXCEPTIONS
         UPDATE /*+ APPEND */
               FT_T_FICL
            SET END_TMS = SYSDATE,
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID =
                   'GS:CON:161951:' || VAR_FICL_TAB (I).LAST_CHG_USR_ID
          WHERE FINS_CLSF_OID = VAR_FICL_TAB (I).FINS_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_FICL%NOTFOUND;
   END LOOP;

   CLOSE CUR_FICL;

--ENDDATE IRCL

   OPEN CUR_IRCL;

   LOOP
      FETCH CUR_IRCL
         BULK COLLECT INTO VAR_IRCL_TAB
         LIMIT 10000;

      FORALL I IN 1 .. VAR_IRCL_TAB.COUNT SAVE EXCEPTIONS
         UPDATE /*+ APPEND */
               FT_T_IRCL
            SET END_TMS = SYSDATE,
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID =
                   'GS:CON:161951:' || VAR_IRCL_TAB (I).LAST_CHG_USR_ID
          WHERE ISSR_CLSF_OID = VAR_IRCL_TAB (I).ISSR_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_IRCL%NOTFOUND;
   END LOOP;

   CLOSE CUR_IRCL;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20200415.sql',
             1,
             'GT161951',
             SYSDATE,
             '8.99.76.0',
             '8.99.77.1',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;