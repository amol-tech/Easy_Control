SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #: 138515
-- | Date: 2017-08-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Migration Script provided inorder to append leading zero in ISS_ID upto 8 character length where ID_CTXT_TYP='JAPAN'
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170828_Select.sql
-- |----------------------------------------------------------------
BEGIN
EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_ISID_138515
                   AS (SELECT ISID_OID,ISS_ID,LAST_CHG_USR_ID,LAST_CHG_TMS
                       FROM FT_T_ISID
                       WHERE ID_CTXT_TYP=''JAPAN''
					   AND END_TMS IS NULL
                       AND LENGTH(ISS_ID)<8
                       AND LAST_CHG_USR_ID LIKE ''%BBEXTDPF%'')';
END;


DECLARE
CURSOR CUR_ISID
IS
SELECT * FROM FT_BAK_ISID_138515;


BEGIN

FOR I IN CUR_ISID

LOOP

   UPDATE FT_T_ISID
   SET ISS_ID=LPAD(ISS_ID,8,0),
   LAST_CHG_USR_ID='GS:MIG:BBEXTDPF:138515',
   LAST_CHG_TMS=SYSDATE
   WHERE ISID_OID =I.ISID_OID;

COMMIT;

END LOOP;


EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Error Code ' || SQLCODE || 'Error Message ' || SQLERRM
      ); 


END;

INSERT INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ('GSDM_Bloomberg_DL_Global_Equity_20170821.sql', 1, 'GT138515', SYSDATE, '8.99.64.0', '8.99.66.0', 'A',  SYSDATE);

COMMIT;

SET DEFINE ON;