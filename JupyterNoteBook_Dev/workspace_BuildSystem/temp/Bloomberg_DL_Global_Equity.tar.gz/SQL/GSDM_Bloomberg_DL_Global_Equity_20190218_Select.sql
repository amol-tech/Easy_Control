SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:463371
-- | GT Ticket #:154246
-- | Date: 2019-02-18
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISSU
-- | Change Reason: Script to retrieve rows from FT_T_ISSU where ISSU.ISS_TYP = ETF created via BBGLMFND or BBEQEURO.
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190218.sql
-- |----------------------------------------------------------------

SELECT *
  FROM FT_T_ISSU
 WHERE     END_TMS IS NULL
       AND ISS_TYP = 'ETF'
       AND REGEXP_LIKE (LAST_CHG_USR_ID, 'BBGLMFND|BBEQEURO');

SET DEFINE ON;