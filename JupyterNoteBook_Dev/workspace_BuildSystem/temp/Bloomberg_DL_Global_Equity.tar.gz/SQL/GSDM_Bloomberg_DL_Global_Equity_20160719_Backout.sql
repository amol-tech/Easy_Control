SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:437116
-- | GT Ticket #:127316
-- | Date: 2016-07-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Script to Rollback the changes made though GSDM_Bloomberg_DL_Global_Equity_20160719.sql
-- |----------------------------------------------------------------

CREATE TABLE FT_TEMP_PPDF
AS
   SELECT   *
     FROM   FT_BAK_PPDF
    WHERE   REASON LIKE 'Duplicate PPDF GT127316%';

ALTER TABLE FT_TEMP_PPDF
DROP (REASON, CNT);

INSERT INTO FT_T_PPDF
     SELECT   * FROM FT_TEMP_PPDF;

DROP TABLE FT_TEMP_PPDF;

SET DEFINE ON;