SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454063
-- | GT Ticket #: 136338
-- | Date: 2017-06-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Script to delete the duplicate PPDF records for Maturity schedules on the basis of START_TMS and PRIN_EV_PRT_ID.
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170628_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_T_PPDF_BKP_136338
AS
   SELECT   *
     FROM   FT_T_PPDF
    WHERE   PRIN_PAY_DEF_ID IN
                  (SELECT   PRIN_PAY_DEF_ID
                     FROM   (SELECT   A.*,
                                      ROW_NUMBER ()
                                         OVER (
                                            PARTITION BY A.PRIN_EV_PRT_ID,
                                                         A.START_TMS
                                            ORDER BY A.LAST_CHG_TMS DESC
                                         )
                                         CNT
                               FROM   FT_T_PPDF A, FT_T_PEVP B
                              WHERE       EV_RATE_BAS_TYP = ''PAR VAL''
                                      AND ISS_PART_RL_TYP = ''RECEIVE''
                                      AND A.PRIN_EV_PRT_ID = B.PRIN_EV_PRT_ID
                                      AND B.PRT_PURP_TYP = ''MATURITY'')
                    WHERE   CNT > 1)';


   EXECUTE IMMEDIATE '                                      ALTER TABLE FT_T_PPDF_BKP_136338 ADD
      CONSTRAINT
      FT_T_PPDF_BKP_136338_PK PRIMARY KEY(PRIN_PAY_DEF_ID)';
END;

DECLARE

    v_NumErrors     NUMBER(10);

   CURSOR CUR_PPDF
   IS
      SELECT   PRIN_PAY_DEF_ID FROM FT_T_PPDF_BKP_136338;

   TYPE TAB_CUR_PPDF IS TABLE OF CUR_PPDF%ROWTYPE;

   VAR_TAB_CUR_PPDF   TAB_CUR_PPDF;
BEGIN
   OPEN CUR_PPDF;

   LOOP
      FETCH CUR_PPDF BULK COLLECT INTO   VAR_TAB_CUR_PPDF LIMIT 10000;

      FORALL I IN 1 .. VAR_TAB_CUR_PPDF.COUNT
      SAVE EXCEPTIONS
         DELETE FROM   FT_T_PPDF
               WHERE   PRIN_PAY_DEF_ID = VAR_TAB_CUR_PPDF (I).PRIN_PAY_DEF_ID;

      COMMIT;

      EXIT WHEN CUR_PPDF%NOTFOUND;
   END LOOP;

   CLOSE CUR_PPDF;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS
      );

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || V_COUNT
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
      END LOOP; 

END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   (' GSDM_Bloomberg_DL_Global_Equity_20170628.sql',
            1,
            'GT136338',
            SYSDATE,
            '8.99.33.0',
            '8.99.65.0',
            'A',
            SYSDATE);

COMMIT;

SET DEFINE ON;