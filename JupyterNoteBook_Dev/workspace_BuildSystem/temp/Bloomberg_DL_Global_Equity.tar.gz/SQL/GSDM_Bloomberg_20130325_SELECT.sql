-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:89470
-- | Date: 2013-03-25
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MIXR
-- | Change Reason: Migration script select's those records of FT_T_MIXR table whose ISID is end dated and whose LAST_CHG_USR_ID is 'GS:CON:MIG' and ISS_USAGE_TYP IS NULL AND ID_CTXT_TYP = 'BBTRDGSYMB'
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

select * from FT_T_MIXR where END_TMS is NULL and ISID_OID in ( select ISID_OID from FT_T_ISID where LAST_CHG_USR_ID like 'GS:CON:MIG%' AND ISS_USAGE_TYP IS NULL AND END_TMS IS NOT NULL AND ID_CTXT_TYP = 'BBTRDGSYMB');

SET DEFINE ON;