SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462389
-- | GT Ticket #:154683
-- | Date: 2019-03-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISMC
-- | Change Reason:Script to retrieve rows from ISMC table where CAPITAL_TYP = 'CSEQSHS'
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190305.sql
-- |----------------------------------------------------------------

-----Script to be executed Before executing script in file GSDM_Bloomberg_DL_Global_Equity_20190305.sql

SELECT *
  FROM FT_T_ISST
 WHERE     END_TMS IS NULL
       AND STAT_DEF_ID = 'SHROUTOT'
       AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

-----Script to be executed After executing script in file GSDM_Bloomberg_DL_Global_Equity_20190305.sql

SELECT *
  FROM FT_T_ISMC ISMC
 WHERE     CAPITAL_TYP = 'CSEQSHS'
       AND END_TMS IS NULL
       AND EXISTS
              (SELECT 'X'
                 FROM FT_T_ISST ISST
                WHERE     ISMC.INSTR_ID = ISST.INSTR_ID
                      AND ISST.END_TMS IS NULL
                      AND ISST.STAT_DEF_ID = 'SHROUTOT'
                      AND ISST.LAST_CHG_USR_ID LIKE '%BBEQEURO%');

SET DEFINE ON;