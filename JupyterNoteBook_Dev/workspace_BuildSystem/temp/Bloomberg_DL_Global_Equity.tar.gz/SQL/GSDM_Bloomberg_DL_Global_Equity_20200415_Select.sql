SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 475625
-- | GT Ticket #: 161951
-- | Date: 2020-04-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nusrat Khan
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to fetch multiple rows created for INDUSCLSETID = 'NAICS' in FICL and IRCL, that are to be end-dated, keeping the latest row active.
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20200415.sql
-- |----------------------------------------------------------------


--FETCH FICL RECORDS

SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT A.*,
               ROW_NUMBER ()
                  OVER (PARTITION BY INST_MNEM ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_FICL A
         WHERE     INDUS_CL_SET_ID = 'NAICS'
               AND END_TMS IS NULL)
 WHERE CNT > 1;
 
 
--FETCH IRCL RECORDS

SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT A.*,
               ROW_NUMBER ()
                  OVER (PARTITION BY INSTR_ISSR_ID ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_IRCL A
         WHERE     INDUS_CL_SET_ID = 'NAICS'
               AND END_TMS IS NULL)
 WHERE CNT > 1;

SET DEFINE ON;