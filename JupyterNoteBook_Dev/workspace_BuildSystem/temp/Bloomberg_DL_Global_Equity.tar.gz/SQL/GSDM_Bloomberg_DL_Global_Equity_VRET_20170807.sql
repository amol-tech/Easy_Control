-- |----------------------------------------------------------------
-- | Front Office #: 455957
-- | GT Ticket #: 137887
-- | Date: 2017-07-20
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected : FT_CFG_VRET
-- | Change Reason: VRET insert needs to be provided for Issue type =Stapled Security
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

INSERT INTO ft_cfg_vret (VND_RQST_TYP, EXT_ISS_TYP_TXT)
                 SELECT 'Equity','Stapled Security'  FROM DUAL
                       WHERE NOT EXISTS (SELECT 1 FROM ft_cfg_vret WHERE VND_RQST_TYP = 'Equity' and EXT_ISS_TYP_TXT='Stapled Security' );

SET DEFINE ON;