SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 463543
-- | GT Ticket #: 153620 
-- | Date: 2019-02-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Nusrat Khan
-- | Approved By: Neha Chaturvedi
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_ISID
-- |
-- | Change Reason: Select Script to move end-dated data from ISID.ISID_OID to ISID.MERGE_UNIQ_OID for BBUNIQUE and TICKER..
-- |----------------------------------------------------------------



SELECT *
  FROM (SELECT A.*,
               ROW_NUMBER ()
               OVER (
                  PARTITION BY INSTR_ID,
                               MKT_OID,
                               ISS_ID,
                               ISS_USAGE_TYP,
                               START_TMS
                  ORDER BY END_TMS DESC)
                  COUNT
          FROM FT_T_ISID A
         WHERE     LAST_CHG_USR_ID IN ('BBGLMFND', 'BBEQEURO')
               AND ID_CTXT_TYP IN ('BBUNIQUE', 'TICKER'))
 WHERE COUNT > 1; 

SET DEFINE ON;
