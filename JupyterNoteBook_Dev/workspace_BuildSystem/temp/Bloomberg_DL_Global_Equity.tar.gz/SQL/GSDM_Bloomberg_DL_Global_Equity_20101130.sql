-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:59386
-- | Date: 2010-11-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Ashwini Nagarkatti
-- | Approved By: Kakoti Chiranjib
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: to change TRDNGCURRCDE to NULL
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update ft_t_isid set trdng_curr_cde=NULL where last_chg_usr_id='BBEQEURO';

SET DEFINE ON;