-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:101399
-- | Date: 2014-02-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By:Swapnali Jadhav
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: Back up Tables
-- | Change Reason: Script to truncate a backup of following tables to restoring the data.
-- |----------------------------------------------------------------

SET DEFINE OFF;

truncate table ft_bak_ipdf;

truncate table ft_bak_isll;

truncate table ft_bak_ppdf; --GT127316

SET DEFINE ON;