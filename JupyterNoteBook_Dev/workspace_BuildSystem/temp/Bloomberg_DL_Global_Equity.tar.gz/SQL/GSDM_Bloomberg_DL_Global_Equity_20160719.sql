SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:437116
-- | GT Ticket #:127316
-- | Date: 2016-07-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Migration script to delete duplicate PPDF rows found on the basis of columns PRIN_EV_PRT_ID, EV_INSTR_ID and START_TMS for PEDF.EV_TYP = MATURITY.
-- | Select Script : GSDM_Bloomberg_DL_Global_Equity_20160719_SELECT.sql
-- |----------------------------------------------------------------

-----Backup

INSERT INTO FT_BAK_PPDF
   SELECT   e.*, 1, 'Duplicate PPDF GT127316 ' || SYSDATE REASON
     FROM   FT_T_PPDF e
    WHERE   PRIN_PAY_DEF_ID IN
                  (SELECT   PRIN_PAY_DEF_ID
                     FROM   (SELECT   PRIN_PAY_DEF_ID,
                                      RANK ()
                                         OVER (
                                            PARTITION BY PRIN_EV_PRT_ID,
                                                         EV_INSTR_ID,
                                                         START_TMS
                                            ORDER BY LAST_CHG_TMS
                                         )
                                         PPDF_CNT
                               FROM   FT_T_PPDF
                              WHERE   PRIN_EV_PRT_ID IN
                                            (SELECT   PRIN_EV_PRT_ID
                                               FROM   FT_T_PEVP
                                              WHERE   PRIN_EV_DEF_ID IN
                                                            (SELECT   PRIN_EV_DEF_ID
                                                               FROM   FT_T_PEDF
                                                              WHERE   EV_TYP =
                                                                         'MATURITY')))
                    WHERE   PPDF_CNT > 1);

-----Delete PPDF

DELETE FROM   FT_T_PPDF
      WHERE   PRIN_PAY_DEF_ID IN
                    (SELECT   PRIN_PAY_DEF_ID
                       FROM   FT_BAK_PPDF
                      WHERE   REASON LIKE 'Duplicate PPDF GT127316%');

INSERT INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ('GSDM_Bloomberg_DL_Global_Equity_20160719.sql', 1, '127316', SYSDATE, '8.99.16.0', '8.99.52.0', 'A',  SYSDATE);


SET DEFINE ON;                      