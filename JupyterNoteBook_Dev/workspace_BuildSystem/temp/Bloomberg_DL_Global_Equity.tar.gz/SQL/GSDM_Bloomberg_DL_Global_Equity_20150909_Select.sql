-- |----------------------------------------------------------------
-- | Front Office #: 437116
-- | GT Ticket #: 120036
-- | Date: 2015-09-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sakshi Mehta
-- | Approved By: Chiranjib Kakoti
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_BDST
-- | Query Patch : GSDM_Bloomberg_DL_Global_Equity_20150909.sql
-- | Change Reason: To update the OUTST_CAMT to NULL for the BDST rows where OUTST_CAMT = 0 and DATA_SRC_ID = 'BLOOMBERG'
-- | 		    				These rows currently have the OUTST_CAMT = 0 which is misleading  as there are cases where the vendor does not know the actual value and we were setting this value as 0.
-- | Thus mapping has been modified to compare incoming value against ".00" and if it equals, Null will be populated in OUTST_CAMT.
--------------------------------------------------------------------

SET DEFINE OFF;

SELECT  *
FROM    FT_T_BDST    
WHERE   OUTST_CAMT = 0
AND     DATA_SRC_ID = 'BB'
and     LAST_CHG_USR_ID LIKE '%BBEXTDPF%';

SET DEFINE ON;





