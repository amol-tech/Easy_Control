-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:74231
-- | Date: 2012-01-07
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Gaurav Mhasalkar
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISMC
-- | Change Reason: 
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update  FT_T_ismc set end_tms=sysdate ,last_chg_usr_id='GSCON:MIG'  where ismc_oid in         
(Select ismc_oid from (Select ismc_oid,INSTR_id,last_chg_tms,row_number()                     
over(partition by INSTR_id,CAPITAL_TYP order by last_chg_tms desc) cnt           
From ft_t_ismc where CAPITAL_TYP='OUTSTAND' and last_chg_usr_id ='BBEQEURO') where cnt !=1  );


SET DEFINE ON;