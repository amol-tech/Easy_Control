SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 462828
-- | GT Ticket #: 155136 
-- | Date: 2019-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Nusrat Khan
-- | Approved By: Adil Shaikh
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Script to end-date the multiple entries present in in FT_T_ISID table, wherein one INSTR_ID have multiple ISS_IDs with same MKT_OID and ISS_USAGE_TYP
-- |
-- |----------------------------------------------------------------


BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_BAK_ISID_GT155136
AS
SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT INSTR_ID,
               ISID_OID,
               ISS_ID,
               ID_CTXT_TYP,
               NVL (MKT_OID, ''A'') "MKT_1",
               END_TMS,
               LAST_CHG_TMS,
               NVL (ISS_USAGE_TYP, ''B'') "USAGE_1",
               LAST_CHG_USR_ID,
               ROW_NUMBER ()
               OVER (PARTITION BY MKT_OID, INSTR_ID, ISS_USAGE_TYP, ID_CTXT_TYP
                     ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_ISID
         WHERE     ID_CTXT_TYP IN (''BBCMPSEC'', ''WI-BBCMPSEC'')
               AND DATA_SRC_ID = ''BB''
               AND END_TMS IS NULL)
 WHERE CNT > 1';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_BAK_ISID_GT155136 ADD CONSTRAINT FT_BAK_ISID_GT155136_PK PRIMARY KEY (ISID_OID)';
     
    EXECUTE IMMEDIATE
      'CREATE INDEX FT_BAK_ISID_GT155136_IND ON FT_BAK_ISID_GT155136 (INSTR_ID, MKT_1, USAGE_1)';
   
END;


DECLARE
   CURSOR CUR_ISID
   IS
      SELECT /*+ PARALLEL(16) */
            *
        FROM FT_BAK_ISID_GT155136 A,
             (SELECT /*+ PARALLEL(16) */
                    *
                FROM (SELECT START_TMS,
                             NVL (MKT_OID, 'A') "MKT_2",
                             INSTR_ID "INSTR",
                             NVL (ISS_USAGE_TYP, 'B') "USAGE_2",
                             ROW_NUMBER ()
                             OVER (
                                PARTITION BY MKT_OID, INSTR_ID, ISS_USAGE_TYP, ID_CTXT_TYP
                                ORDER BY LAST_CHG_TMS DESC)
                                CNT_2
                        FROM FT_T_ISID
                       WHERE     ID_CTXT_TYP IN ('BBCMPSEC', 'WI-BBCMPSEC')
                             AND DATA_SRC_ID = 'BB'
                             AND END_TMS IS NULL)
               WHERE CNT_2 = 1) B
       WHERE     A.INSTR_ID = B.INSTR
             AND A.MKT_1 = B.MKT_2
             AND A.USAGE_1 = B.USAGE_2;

   TYPE ISID_TAB IS TABLE OF CUR_ISID%ROWTYPE;

   VAR_ISID_TAB   ISID_TAB;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISID;
LOOP
   FETCH CUR_ISID
      BULK COLLECT INTO VAR_ISID_TAB
      LIMIT 10000;

   FORALL I IN 1 .. VAR_ISID_TAB.COUNT SAVE EXCEPTIONS
      UPDATE /*+ APPEND +*/
           FT_T_ISID
         SET END_TMS = VAR_ISID_TAB (I).START_TMS - 1,
             LAST_CHG_TMS = SYSDATE,
             LAST_CHG_USR_ID =
                'GS:CON:155136:' || VAR_ISID_TAB (I).LAST_CHG_USR_ID
       WHERE ISID_OID = VAR_ISID_TAB (I).ISID_OID;

   DBMS_OUTPUT.PUT_LINE ('Records end dated: ' || VAR_ISID_TAB.COUNT);

   COMMIT;
EXIT WHEN CUR_ISID%NOTFOUND;
   END LOOP;
   CLOSE CUR_ISID;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;


INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20190410.sql',
             1,
             'GT155136',
             SYSDATE,
             '8.99.74.4',
             '8.99.75.1',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;