-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:89470
-- | Date: 2013-03-25
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MIXR
-- | Change Reason: Migration script end date's those records of FT_T_MIXR table whose ISID is end dated and whose LAST_CHG_USR_ID is 'GS:CON:MIG' and ISS_USAGE_TYP IS NULL AND ID_CTXT_TYP = 'BBTRDGSYMB'
-- | Select Query Patch: GSDM_Bloomberg_20130325_SELECT.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_MIXR set LAST_CHG_USR_ID = 'GS:MIG:89470:'||LAST_CHG_USR_ID , END_TMS = SYSDATE where END_TMS is NULL and ISID_OID in ( select ISID_OID from FT_T_ISID where LAST_CHG_USR_ID like 'GS:CON:MIG%' AND ISS_USAGE_TYP IS NULL AND END_TMS IS NOT NULL AND ID_CTXT_TYP = 'BBTRDGSYMB');

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_20130325.sql', 1, 'GT#89470', TO_DATE( '03/25/2013 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.4.0', 'A',  SYSDATE);

SET DEFINE ON;