-- |----------------------------------------------------------------
-- | Front Office #:437773,437239
-- | GT #: 85238,84003
-- | Date: 2012-12-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Yash Somaiya
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: MKIS,EQCH,EQST
-- |
-- | Change Reason: Migration script to Nullify the EQCH.ANNUAL_DIVIDEND_CURR_CDE and MKIS.prc_ut_meas_typ and delete duplicate EQST.

-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update ft_t_mkis set prc_ut_meas_typ='Blank',last_chg_usr_id='GS:MIG:85238:BBEQEURO' where last_chg_usr_id like '%BBEQEURO%' and prc_ut_meas_typ='PIECE';

update ft_t_eqch set ANNUAL_DIVIDEND_CURR_CDE=NULL,last_chg_usr_id='GS:MIG:85238:BBEQEURO' where last_chg_usr_id like '%BBEQEURO%';

delete from ft_t_eqst eq1 where exists (select 'X' from ft_t_eqst where instr_id=eq1.instr_id and mkt_oid=eq1.mkt_oid and stats_curr_cde is not NULL) 
and last_chg_usr_id like '%BBEQEURO%' and stats_curr_cde is NULL;

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20121211.sql', 1, 'GT#85238', TO_DATE( '07/25/2010 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.0.40', 'A',  SYSDATE);

SET DEFINE ON;