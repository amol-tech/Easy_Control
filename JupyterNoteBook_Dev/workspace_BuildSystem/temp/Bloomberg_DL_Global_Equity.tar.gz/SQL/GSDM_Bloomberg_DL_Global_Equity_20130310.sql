SET DEFINE OFF;


-- |----------------------------------------------------------------
-- | Front Office #:440551
-- | GT Ticket #:96996
-- | Date: 2013-10-03
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rajath Shetty
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF , FT_T_PEVP
-- | Change Reason: Script to change PEVP.PRT_PURP_TYP to 'SINKING' from 'SNKFDRED'
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20130310_SELECT.sql
-- |----------------------------------------------------------------



insert into ft_bak_ppdf
select a.*, 'ppdf_BB:96996' || SYSDATE reason  from FT_T_ppdf a where PRIN_PAY_DEF_ID in
(select PRIN_PAY_DEF_ID from (select * from ft_t_ppdf where PRIN_EV_PRT_ID in (select PRIN_EV_PRT_ID from(SELECT PRIN_EV_PRT_ID FROM 
(SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SNKFDRED') where cnt !=1  ))));



insert into ft_bak_ppdf
select a.*, 'ppdf_BB:96996' || SYSDATE reason  from FT_T_ppdf a where PRIN_PAY_DEF_ID in
(select PRIN_PAY_DEF_ID from (select * from ft_t_ppdf where PRIN_EV_PRT_ID in (select PRIN_EV_PRT_ID from(SELECT PRIN_EV_PRT_ID FROM 
(SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SINKING') where cnt !=1 ))));



insert into ft_bak_ppdf
select a.*, 'ppdf_BB:96996' || SYSDATE reason  from FT_T_ppdf a where PRIN_PAY_DEF_ID in
(select PRIN_PAY_DEF_ID from(select * from ft_t_ppdf where PRIN_EV_PRT_ID in(select PRIN_EV_PRT_ID from (select * from FT_T_pevp a where exists (select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SNKFDRED') and exists ( select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SINKING')and PRT_PURP_TYP='SINKING')))) ;


delete from ft_t_ppdf where PRIN_PAY_DEF_ID in(select PRIN_PAY_DEF_ID from ft_bak_ppdf);




insert into ft_bak_pevp
select a.*, 'pevp_BB:96996' || SYSDATE reason  from FT_T_pevp a where PRIN_EV_PRT_ID in(SELECT PRIN_EV_PRT_ID FROM (SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SNKFDRED') where cnt !=1  );

insert into ft_bak_pevp
select a.*, 'pevp_BB:96996' || SYSDATE reason  from FT_T_pevp a where PRIN_EV_PRT_ID in(SELECT PRIN_EV_PRT_ID FROM (SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SINKING') where cnt !=1  );

insert into ft_bak_pevp
select a.*, 'pevp_BB:96996' || SYSDATE reason  from FT_T_pevp a where PRIN_EV_PRT_ID in(select PRIN_EV_PRT_ID from (select * from FT_T_pevp a where exists (select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SNKFDRED') and exists ( select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SINKING')and PRT_PURP_TYP='SINKING'));

DELETE FROM FT_t_PEVP WHERE PRIN_EV_PRT_ID in(select PRIN_EV_PRT_ID from ft_bak_pevp);



update ft_T_pevp pevp set pevp.PRT_PURP_TYP='SINKING',LAST_CHG_USR_ID='GS:96996:BBEXTDPF' where pevp.PRT_PURP_TYP='SNKFDRED' and not exists (select 'X' from ft_T_pevp where PRT_PURP_TYP='SINKING' and PRIN_EV_DEF_ID=pevp.PRIN_EV_DEF_ID);


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130310.sql',1, 'GT#96996', TO_DATE( '10/07/2013 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.17.0', 'A',  SYSDATE);


SET DEFINE ON;



