
SET DEFINE OFF;
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | FrontOffice ID: 438083
-- | GT Ticket #: 152151
-- | Date: 2018-12-31
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Priyanka Meshram
-- | Approved By: Mihir Sabnis
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Tables Affected:FT_T_ISSD
-- | Change Reason: Script to update ISID.ISS_USAGE_TYP to null for ISID having ID_CTXT_TYP IN ('BBCONNECT ','WI-BBCONNECT') AND LAST_CHG_USR_ID = 'BBEQEURO' records.
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181231.sql
-- |--------------------------------------------------------------------------------------------------------------------------------

--------------  Create Dummy Table -------------------

BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_T_ISID_BACKUP_GT152151
                    AS
                    SELECT ISID_OID,
       INSTR_ID,
       ID_CTXT_TYP,
       ISS_ID,
       START_TMS,
       END_TMS,
       LAST_CHG_TMS,
       LAST_CHG_USR_ID,
       MKT_OID,
       TRDNG_CURR_CDE,
       ISS_USAGE_TYP,
       DATA_STAT_TYP,
       DATA_SRC_ID,
       LISTING_SYMBOL_IND,
       ERGONOMIC_SYMBOL_IND,
       TRADER_SYMBOL_IND,
       MULTI_SEDOL_SYMBOL_IND,
       INSTR_SYMBOL_STAT_TYP,
       WHEN_ISSUED_IND,
       MERGE_UNIQ_OID,
       ISS_TENOR_TYP,
       NOT_TRADABLE_IND,
       SRCE_CURR_CDE,
       TRGT_CURR_CDE,
       ROOT_SYMBOL_MNEM,
       GLOBAL_UNIQ_IND,
       ORIG_DATA_PROV_ID,
       WHEN_DISTRIBUTED_IND,
       INST_MNEM,
       PRELIM_TERM_PRSPCTUS_IND,
       PRIM_TRD_MRKT_QUOTE_IND	   
  FROM FT_T_ISID
 WHERE ISID_OID IN
          (SELECT ISID_OID
             FROM (SELECT ISID_OID,
                          ROW_NUMBER ()
                          OVER (PARTITION BY INSTR_ID
                                ORDER BY LAST_CHG_TMS DESC)
                             CNT
                       FROM FT_T_ISID
					  WHERE ID_CTXT_TYP IN (''BBCONNECT'',''WI-BBCONNECT'')
					    AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%'')               
            WHERE CNT >= 1)
	AND END_TMS IS NULL
	AND ISS_USAGE_TYP IS NOT NULL';
	
   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_ISID_BACKUP_GT152151 ADD CONSTRAINT FT_T_ISID_BACKUP_GT152151_PK PRIMARY KEY(ISID_OID)';	
	
END;

------------  Block to update null in ISID.ISS_USAGE_TYP column -------------------------

DECLARE
   CURSOR CUR_ISID_UPD
   IS
      SELECT * FROM FT_T_ISID_BACKUP_GT152151;


   TYPE TYP_ISID_UPD IS TABLE OF CUR_ISID_UPD%ROWTYPE;

   VAR_ISID_UPD   TYP_ISID_UPD;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISID_UPD;

   LOOP
      FETCH CUR_ISID_UPD
         BULK COLLECT INTO VAR_ISID_UPD
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_UPD.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISID
            SET ISS_USAGE_TYP = NULL,
				LAST_CHG_TMS = SYSDATE,
				LAST_CHG_USR_ID = 'GS:CON:152151:'|| VAR_ISID_UPD (I).LAST_CHG_USR_ID
          WHERE ISID_OID = VAR_ISID_UPD (I).ISID_OID;

      COMMIT;
      EXIT WHEN CUR_ISID_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;


INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20181231.sql',
             1,
             'GT152151',
             SYSDATE,
             '8.99.73.1',
             '8.99.74.0',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;   

	