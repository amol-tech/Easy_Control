-- |----------------------------------------------------------------
-- | Front Office #: 435157
-- | Bugzilla #: 78695
-- | Date: 2012-05-25
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Navin Agarwal
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Table Affected:FT_T_ISID
-- |
-- | Change Reason: Script to End date the duplicate ISID record for BBTRDGSYMB having ISS_USAGE_TYP as null and 
-- | Other ISS_USAGE_TYP as not null With rest of the columns being same.
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_ISID SET ID_CTXT_TYP='BBTRDGSYMB',LAST_CHG_USR_ID='GS:CON:MIG' WHERE ID_CTXT_TYP='TRDGSYMB' AND data_src_id like 'BB%';

update ft_t_isid set ID_CTXT_TYP='BBTRDGSYMB',LAST_CHG_USR_ID='GS:CON:MIG' where ID_CTXT_TYP='TKTRDGSYMB' and   data_src_id like 'BB%';

update  FT_T_ISID a set END_TMS=SYSDATE, LAST_CHG_USR_ID='GS:CON:MIG'  where exists (select 1 from FT_T_ISID where instr_id =a.instr_id and mkt_oid=a.mkt_oid and a.ID_CTXT_TYP=ID_CTXT_TYP
and iss_usage_typ is null) and exists ( select 1 from FT_T_ISID where instr_id =a.instr_id and mkt_oid=a.mkt_oid and a.ID_CTXT_TYP=ID_CTXT_TYP
and iss_usage_typ is not null)  and iss_usage_typ is  null and  data_src_id like 'BB%' and id_ctxt_typ='BBTRDGSYMB' ;

SET DEFINE ON;





