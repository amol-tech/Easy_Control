-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:152151
-- | Date: 2018-12-04
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Priyanka Meshram
-- | Approved By: Mihir Sabnis
-- | Change Reason: Script to fetch ISID records which have been set up for 
-- |                ID_CTXT_TYP = ('BBCONNECT ','WI-BBCONNECT') 
-- |                AND LAST_CHG_USR_ID = 'BBEQEURO'
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181231_SELECT.sql
-- |----------------------------------------------------------------
SET DEFINE OFF;

SELECT * 
  FROM FT_T_ISID  
 WHERE ID_CTXT_TYP IN ('BBCONNECT','WI-BBCONNECT')
   AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
   AND END_TMS IS NULL
   AND ISS_USAGE_TYP IS NOT NULL;

SET DEFINE ON;