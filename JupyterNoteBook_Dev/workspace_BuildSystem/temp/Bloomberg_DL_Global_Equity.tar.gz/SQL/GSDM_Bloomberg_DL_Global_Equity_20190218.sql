SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:463371
-- | GT Ticket #:154246
-- | Date: 2019-02-18
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISSU
-- | Change Reason: Script to retrieve records from FT_T_ISSU created via BBGLMFND' and 'BBEQEURO' and update ISSU.ISS_TYP from ETF to HYBRID
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190218_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_BAK_ISSU_GT154246
AS
   SELECT INSTR_ID,
          ISS_TYP,
          ISCD_OID,
          EIST_OID,
          START_TMS,
          LAST_CHG_USR_ID,
          LAST_CHG_TMS
     FROM FT_T_ISSU
    WHERE     END_TMS IS NULL
          AND ISS_TYP = ''ETF''
          AND REGEXP_LIKE (LAST_CHG_USR_ID, ''BBGLMFND|BBEQEURO'')';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_BAK_ISSU_GT154246 ADD CONSTRAINT PK_BAK_ISSU_GT154246 PRIMARY KEY (INSTR_ID)';
END;

DECLARE
   CURSOR CUR_ISSU
   IS
      SELECT INSTR_ID FROM FT_BAK_ISSU_GT154246;

   TYPE TYP_ISSU IS TABLE OF CUR_ISSU%ROWTYPE;

   VAR_ISSU      TYP_ISSU;

   V_NUMERRORS   NUMBER (10);
BEGIN
   OPEN CUR_ISSU;

   LOOP
      FETCH CUR_ISSU
         BULK COLLECT INTO VAR_ISSU
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISSU.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISSU
            SET ISS_TYP = 'HYBRID',
                (ISCD_OID, EIST_OID) =
                   (SELECT ISCD_OID, EIST_OID
                      FROM FT_T_EIST
                     WHERE EXT_ISS_TYP_NME = 'ETP' AND DATA_SRC_ID = 'BB'),
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:CON:154246:' || LAST_CHG_USR_ID
          WHERE INSTR_ID = VAR_ISSU (I).INSTR_ID;

      COMMIT;
      EXIT WHEN CUR_ISSU%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISSU;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;


INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20190218.sql',
             1,
             'GT154246',
             SYSDATE,
             '8.99.61.1',
             '8.99.74.3',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;