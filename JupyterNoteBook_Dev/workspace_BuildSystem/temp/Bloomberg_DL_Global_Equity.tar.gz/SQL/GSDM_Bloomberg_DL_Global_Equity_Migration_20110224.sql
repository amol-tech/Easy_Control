-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:63150
-- | Date: 2010-02-24
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Susan Alvares
-- | Approved By: Kakoti Chiranjib
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISMC
-- | Change Reason: migration of data from the column FLT_CQTY of the EQST table to the column FREE_FLT_CPCT of the ISCM table.
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_ISMC A SET A.LAST_CHG_USR_ID = 'GSCON:MIG',A.FREE_FLT_CPCT =NVL((SELECT B.FLT_CQTY FROM FT_T_EQST B WHERE A.INSTR_ID=B.INSTR_ID AND LAST_CHG_USR_ID = 'BBEQEURO' and rownum=1),A.FREE_FLT_CPCT) WHERE LAST_CHG_USR_ID = 'BBEQEURO' and A.INSTR_ID in (SELECT INSTR_ID FROM FT_T_EQST B WHERE A.INSTR_ID=B.INSTR_ID AND LAST_CHG_USR_ID = 'BBEQEURO');

SET DEFINE ON;