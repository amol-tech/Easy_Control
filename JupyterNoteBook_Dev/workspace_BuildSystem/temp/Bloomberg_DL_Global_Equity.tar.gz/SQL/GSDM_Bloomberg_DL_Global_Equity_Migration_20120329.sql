-- |----------------------------------------------------------------
-- | Front Office #: 434427
-- | GT Ticket #:76557
-- | Date: 2012-03-29
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Divya Poojari
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MUST
-- | Change Reason: EQY_SH_OUT_TOT_MULT_SH value population in MUST.STAT_CHAR_VAL_TXT
-- | 
-- |----------------------------------------------------------------

SET DEFINE ON;

UPDATE FT_T_MUST SET STAT_VAL_CAMT=CAST(STAT_CHAR_VAL_TXT AS NUMBER(31,11))*1000000,STAT_CHAR_VAL_TXT=NULL,LAST_CHG_USR_ID='GSCON:MIG' WHERE STAT_DEF_ID='OUTSTSHR' AND LAST_CHG_USR_ID='BBEQEURO';
 
SET DEFINE ON;