SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | FrontOffice ID: 456382
-- | GT Ticket #: 138745
-- | Date: 2018-04-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISST
-- | Change Reason: Script to end date duplicate records with same INSTR_ID keeping the latest record active by nullifying DENOM_CURR_CDE in FT_T_ISST
-- |                where STAT_DEF_ID='PREEURPR' and DENOM_CURR_CDE is not null and LAST_CHG_USR_ID='BBEQEURO'and END_TMS is null
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20180430_Select.sql
-- |----------------------------------------------------------------


BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_T_ISST_BKP_138745 AS
    SELECT   a.*,
                             ROW_NUMBER ()
                                OVER (PARTITION BY INSTR_ID
                                      ORDER BY LAST_CHG_TMS DESC) cnt
                      FROM   FT_T_ISST a
                     WHERE       STAT_DEF_ID = ''PREEURPR''
                             AND LAST_CHG_USR_ID = ''BBEQEURO''
                             AND END_TMS IS NULL';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_ISST_BKP_138745 ADD CONSTRAINT FT_T_ISST_BKP_138745_PK  PRIMARY KEY (STAT_ID)';
END;

DECLARE
   CURSOR CUR_FT_T_ISST_UPD
   IS
      SELECT STAT_ID,
             INSTR_ID,
             STAT_DEF_ID,
             START_TMS,
             CNT
        FROM (SELECT A.STAT_ID,
                     A.INSTR_ID,
                     A.STAT_DEF_ID,
                     A.START_TMS,
                     ROW_NUMBER ()
                     OVER (PARTITION BY INSTR_ID, STAT_DEF_ID
                           ORDER BY LAST_CHG_TMS DESC, DENOM_CURR_CDE ASC)
                        CNT
                FROM FT_T_ISST A
               WHERE     END_TMS IS NULL
                     AND LAST_CHG_USR_ID = 'BBEQEURO'
                     AND STAT_DEF_ID = 'PREEURPR')
       WHERE CNT = 1;

   CURSOR CUR_FT_T_ISST_ENDDT (
      P_INSTRID      VARCHAR2,
      P_STATDEFID    VARCHAR2)
   IS
      SELECT STAT_ID,
             INSTR_ID,
             STAT_DEF_ID,
             START_TMS,
             CNT
        FROM (SELECT A.STAT_ID,
                     A.INSTR_ID,
                     A.STAT_DEF_ID,
                     A.START_TMS,
                     ROW_NUMBER ()
                     OVER (PARTITION BY INSTR_ID, STAT_DEF_ID
                           ORDER BY LAST_CHG_TMS DESC, DENOM_CURR_CDE DESC)
                        CNT
                FROM FT_T_ISST A
               WHERE     END_TMS IS NULL
                     AND LAST_CHG_USR_ID = 'BBEQEURO'
                     AND INSTR_ID = P_INSTRID
                     AND STAT_DEF_ID = P_STATDEFID)
       WHERE CNT > 1;

BEGIN
   FOR I IN CUR_FT_T_ISST_UPD
   LOOP
      FOR J IN CUR_FT_T_ISST_ENDDT (I.INSTR_ID, I.STAT_DEF_ID)
      LOOP
         UPDATE FT_T_ISST
            SET END_TMS = SYSDATE,
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:CON:138745:' || LAST_CHG_USR_ID,
                START_TMS =
                   CASE
                      WHEN I.START_TMS = J.START_TMS
                      THEN
                         START_TMS - (J.CNT / 3600)
                      ELSE
                         START_TMS
                   END
          WHERE STAT_ID = J.STAT_ID;

         COMMIT;
      END LOOP;

      UPDATE FT_T_ISST
         SET DENOM_CURR_CDE = NULL,
             LAST_CHG_TMS = SYSDATE,
             LAST_CHG_USR_ID = 'GS:CON:138745:' || LAST_CHG_USR_ID
       WHERE STAT_ID = I.STAT_ID AND DENOM_CURR_CDE IS NOT NULL;

      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || 'and Message: ' || SQLERRM);
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20180430.sql',
             1,
             'GT138745',
             SYSDATE,
             '8.99.71.0',
             '8.99.71.2',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON