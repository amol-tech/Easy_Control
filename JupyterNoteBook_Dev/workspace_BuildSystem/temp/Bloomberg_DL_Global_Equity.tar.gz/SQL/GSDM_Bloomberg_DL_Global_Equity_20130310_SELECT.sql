SET DEFINE OFF;


-- |----------------------------------------------------------------
-- | Front Office #:440551
-- | GT Ticket #:96996
-- | Date: 2013-10-03
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rajath Shetty
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF , FT_T_PEVP
-- | Change Reason: Script to change PEVP.PRT_PURP_TYP to 'SINKING' from 'SNKFDRED'
-- |----------------------------------------------------------------


select * from ft_t_ppdf where PRIN_EV_PRT_ID in (select PRIN_EV_PRT_ID from(SELECT PRIN_EV_PRT_ID FROM 
(SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SNKFDRED') where cnt !=1  ));


select * from ft_t_ppdf where PRIN_EV_PRT_ID in (select PRIN_EV_PRT_ID from(SELECT PRIN_EV_PRT_ID FROM 
(SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SINKING') where cnt !=1  ));


select * from ft_t_ppdf where PRIN_EV_PRT_ID in(select PRIN_EV_PRT_ID from (select * from FT_T_pevp a where exists (select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SNKFDRED') and exists ( select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SINKING')and PRT_PURP_TYP='SINKING'));



select * from FT_T_pevp   where PRIN_EV_PRT_ID in(SELECT PRIN_EV_PRT_ID FROM (SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SNKFDRED') where cnt !=1  );

select * from FT_T_pevp  where PRIN_EV_PRT_ID in(SELECT PRIN_EV_PRT_ID FROM (SELECT PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,LAST_CHG_TMS,row_number()                     
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP ORDER BY LAST_CHG_TMS desc) cnt           
FROM ft_T_pevp WHERE  PRT_PURP_TYP ='SINKING') where cnt !=1  );


select * from FT_T_pevp  where PRIN_EV_PRT_ID in(select PRIN_EV_PRT_ID from (select * from FT_T_pevp a where exists (select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SNKFDRED') and exists ( select 1 from FT_T_pevp where PRIN_EV_DEF_ID =a.PRIN_EV_DEF_ID 
and PRT_PURP_TYP='SINKING')and PRT_PURP_TYP='SINKING'));



SET DEFINE ON;