SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454063
-- | GT Ticket #: 136338
-- | Date: 2017-06-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By:Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Script to select the duplicate PPDF records for Maturity schedules on the basis of START_TMS and PRIN_EV_PRT_ID.
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170628.sql
-- |----------------------------------------------------------------


   SELECT   *
     FROM   FT_T_PPDF
    WHERE   PRIN_PAY_DEF_ID IN
                  (SELECT   PRIN_PAY_DEF_ID
                     FROM   (SELECT   A.*,
                                      ROW_NUMBER ()
                                         OVER (
                                            PARTITION BY A.PRIN_EV_PRT_ID,
                                                         A.START_TMS
                                            ORDER BY A.LAST_CHG_TMS DESC
                                         )
                                         CNT
                               FROM   FT_T_PPDF A, FT_T_PEVP B
                              WHERE       EV_RATE_BAS_TYP = 'PAR VAL'
                                      AND ISS_PART_RL_TYP = 'RECEIVE'
                                      AND A.PRIN_EV_PRT_ID = B.PRIN_EV_PRT_ID
                                      AND B.PRT_PURP_TYP = 'MATURITY')
                    WHERE   CNT > 1);


SET DEFINE ON;
