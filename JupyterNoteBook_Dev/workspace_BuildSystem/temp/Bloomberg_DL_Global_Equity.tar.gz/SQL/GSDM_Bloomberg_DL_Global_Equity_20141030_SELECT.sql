-- |----------------------------------------------------------------
-- | Front Office #:443350
-- | GT Ticket #: 106746
-- | Date: 2014-10-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Suvarna Rane
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISCL, FT_T_MICL
-- | Change Reason: select script to view the ISCL records that we are end dateing, those created for [LSE_SEGMENT] and [LSE_SECTOR] fields having INDUS_CL_SET_ID 'LSESEGMENT' and CLSF_PURP_TYP as 'INSUBTYP','INDCLASS'
-- |                and latest ISCL active record for which we are creating entry in MICL table.
-- | Script Name: GSDM_Bloomberg_DL_Global_Equity_20141030.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;


    SELECT  DISTINCT INDUS_CL_SET_ID, CLSF_OID, CL_VALUE, START_TMS, SYSDATE, 'GS:MIG:BBEQEURO:106746', DATA_SRC_ID, MKT_ISS_OID, DATA_STAT_TYP
    FROM    (
                SELECT  DISTINCT B.INDUS_CL_SET_ID, B.CLSF_OID, B.CL_VALUE, A.MKT_ISS_OID, B.LAST_CHG_USR_ID, B.START_TMS, B.LAST_CHG_TMS, B.DATA_SRC_ID, B.DATA_STAT_TYP,
                        ROW_NUMBER() OVER (PARTITION BY A.INSTR_ID, A.MKT_OID, B.INDUS_CL_SET_ID ORDER BY B.LAST_CHG_TMS DESC) CNT
                FROM    FT_T_MKIS A,
                        FT_T_ISCL B,
                        FT_T_ISID C
                WHERE   A.INSTR_ID = B.INSTR_ID
                AND     B.INDUS_CL_SET_ID = 'LSESEGMENT'
                AND     B.CLSF_PURP_TYP IN ('INSUBTYP','INDCLASS')
                AND     B.ISID_OID = C.ISID_OID
                AND     A.INSTR_ID = C.INSTR_ID
                AND     B.INSTR_ID = C.INSTR_ID
                AND     C.ID_CTXT_TYP in ( 'TICKER', 'WI-TICKER')
                AND     A.MKT_OID = C.MKT_OID
                AND     A.END_TMS IS NULL
                AND     C.END_TMS IS NULL
                AND     B.END_TMS IS NULL)MKIS_ISCL
    WHERE   CNT = 1
    AND     NOT EXISTS (SELECT    1
                                    FROM    FT_T_MICL
                                    WHERE     MKIS_ISCL.INDUS_CL_SET_ID = INDUS_CL_SET_ID
                                    AND     MKIS_ISCL.CLSF_OID = CLSF_OID
                                    AND     MKIS_ISCL.CL_VALUE = CL_VALUE
                                    AND     MKIS_ISCL.MKT_ISS_OID = MKT_ISS_OID);
    
    SELECT  *
        FROM    FT_T_ISCL A
        WHERE   A.INDUS_CL_SET_ID = 'LSESEGMENT'
        AND     A.CLSF_PURP_TYP IN ('INSUBTYP','INDCLASS')
        AND     A.END_TMS IS NULL
        AND     EXISTS (SELECT 1
                        FROM    FT_T_ISID B
                        WHERE   A.INSTR_ID = B.INSTR_ID
                        AND     A.ISID_OID = B.ISID_OID
                        AND     B.ID_CTXT_TYP in ( 'TICKER', 'WI-TICKER')); 
                        
 SET DEFINE ON;
    