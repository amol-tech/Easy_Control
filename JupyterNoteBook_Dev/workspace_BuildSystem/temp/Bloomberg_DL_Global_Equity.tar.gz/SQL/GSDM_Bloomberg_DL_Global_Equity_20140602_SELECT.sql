-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:106506
-- | Date: 2014-05-22
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sanket Salot
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RISS.
-- | Select Query Patch Name - GSDM_Bloomberg_DL_Global_Equity_20140602_SELECT.sql
-- | Change Reason: To end date the duplicate entries present in RISS provided REL_TYP is CONV in RIDF table.
-- | 
-- |----------------------------------------------------------------


SET DEFINE OFF;


(Select riss_oid from 
(SELECT riss_oid,row_number()                     
over(partition by RLD_ISS_FEAT_ID,INSTR_ID,PART_UNITS_TYP,ISS_PART_RL_TYP,UDRLY_ASSET_SUB_TYP,UDRLY_ASSET_TYP order by last_chg_tms desc) cnt           
FROM ft_T_riss WHERE end_tms is null and RLD_ISS_FEAT_ID in
(select RLD_ISS_FEAT_ID from ft_T_ridf where RLD_ISS_FEAT_ID in
(SELECT distinct RLD_ISS_FEAT_ID FROM (SELECT RLD_ISS_FEAT_ID,row_number()                     
over(partition by RLD_ISS_FEAT_ID,INSTR_ID,PART_UNITS_TYP,ISS_PART_RL_TYP,UDRLY_ASSET_SUB_TYP,UDRLY_ASSET_TYP order by last_chg_tms desc) cnt           
FROM ft_T_riss WHERE end_tms is null
) WHERE cnt !=1  )
and REL_TYP = 'CONV')
) where cnt !=1);


SET DEFINE ON;