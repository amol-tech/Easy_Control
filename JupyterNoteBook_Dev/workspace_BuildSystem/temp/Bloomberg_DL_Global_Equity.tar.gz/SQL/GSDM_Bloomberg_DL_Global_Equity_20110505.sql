-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:66393
-- | Date: 2011-05-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nived Soman
-- | Approved By: Kakoti Chiranjib
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKCA
-- | Change Reason: 
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;


update ft_t_mkca set mkt_oid=null where mkt_iss_oid is not null and mkt_oid is not null and last_chg_usr_id in('BBCONV','BBGOVTAG','BBCORP','BBEQEURO','BBPREFRD');


SET DEFINE ON;