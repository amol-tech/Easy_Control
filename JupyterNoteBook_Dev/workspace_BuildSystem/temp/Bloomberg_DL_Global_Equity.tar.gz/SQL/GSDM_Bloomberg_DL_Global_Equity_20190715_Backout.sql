SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 464164
-- | GT Ticket #: 156691
-- | Date: 2019-07-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID, FT_T_IBMR
-- | Change Reason: Script to revert changes applied through the below update query.
-- | Update Query : GSDM_Bloomberg_DL_Global_Equity_20190715.sql
-- |----------------------------------------------------------------


DECLARE 

    CURSOR CUR_IBMR IS
    
        SELECT  *
        FROM    FT_T_IBMR_BKP_156691;
        
    TYPE TYP_CUR_IBMR   IS TABLE OF CUR_IBMR%ROWTYPE;
        
    V_BULK_TYPE_IBMR     TYP_CUR_IBMR;
    
    CURSOR CUR_ISID IS
    
        SELECT  *
        FROM    FT_T_ISID_BKP_156691;
        
    TYPE TYP_CUR_ISID   IS TABLE OF CUR_ISID%ROWTYPE;
        
    V_BULK_TYPE_ISID     TYP_CUR_ISID;
    
    CURSOR CUR_IBMR_INSTR IS
    
        SELECT  *
        FROM    FT_T_IBMR_BKP_156691_2;
        
    TYPE TYP_CUR_IBMR_INSTR   IS TABLE OF CUR_IBMR_INSTR%ROWTYPE;
        
    V_BULK_TYPE_IBMR_INSTR     TYP_CUR_IBMR_INSTR;
    
BEGIN

    OPEN CUR_IBMR;
    
    LOOP
    
        FETCH CUR_IBMR BULK COLLECT INTO  V_BULK_TYPE_IBMR LIMIT 1000;
        
        FORALL I IN 1..V_BULK_TYPE_IBMR.COUNT SAVE EXCEPTIONS
        
            UPDATE  FT_T_IBMR
            SET     END_TMS = V_BULK_TYPE_IBMR(I).END_TMS,
                    LAST_CHG_USR_ID = V_BULK_TYPE_IBMR(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = V_BULK_TYPE_IBMR(I).LAST_CHG_TMS
            WHERE   IBMR_OID = V_BULK_TYPE_IBMR(I).IBMR_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_IBMR%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_IBMR;
    
    OPEN CUR_ISID;
    
    LOOP
    
        FETCH CUR_ISID BULK COLLECT INTO V_BULK_TYPE_ISID LIMIT 1000;
    
        FORALL I IN 1..V_BULK_TYPE_ISID.COUNT SAVE EXCEPTIONS 
        
            UPDATE  FT_T_ISID
            SET     END_TMS = V_BULK_TYPE_ISID(I).END_TMS,
                    LAST_CHG_USR_ID = V_BULK_TYPE_ISID(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = V_BULK_TYPE_ISID(I).LAST_CHG_TMS
            WHERE   ISID_OID = V_BULK_TYPE_ISID(I).ISID_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_ISID%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_ISID;
    
    OPEN CUR_IBMR_INSTR;
    
    LOOP
    
        FETCH CUR_IBMR_INSTR BULK COLLECT INTO V_BULK_TYPE_IBMR_INSTR LIMIT 1000;
    
        FORALL I IN 1..V_BULK_TYPE_IBMR_INSTR.COUNT SAVE EXCEPTIONS 
        
            UPDATE  FT_T_IBMR
            SET     INSTR_ID = V_BULK_TYPE_IBMR_INSTR(I).INSTR_ID,
                    LAST_CHG_USR_ID = V_BULK_TYPE_IBMR_INSTR(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = V_BULK_TYPE_IBMR_INSTR(I).LAST_CHG_TMS
            WHERE   IBMR_OID = V_BULK_TYPE_IBMR_INSTR(I).IBMR_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_IBMR_INSTR%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_IBMR_INSTR;
    
END;