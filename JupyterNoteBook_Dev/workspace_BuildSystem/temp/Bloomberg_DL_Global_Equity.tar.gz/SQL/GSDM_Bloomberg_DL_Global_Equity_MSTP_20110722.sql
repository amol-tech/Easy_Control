
--MSTY

INSERT INTO FT_CFG_MSTP (MSTP_OID, MSG_TYP_NME, MAPPING_URI, BSFD_OID, VDDB_PROPAGATION_IND,
USE_KEY_TYP, MSG_KEY_XPATH, WRITE_EXCEPTION_TYP, WRITE_NOTFCN_TYP, SAVE_INPUT_MSG_TYP,
SAVE_TRANSLATED_MSG_TYP, SAVE_PROCESSED_MSG_TYP, LAST_CHG_TMS, LAST_CHG_USR_ID,
CAPTURE_PROCESSED_MSG_IND, ROLLBACK_ON_ERROR_IND, SYNC_PUBLISHING_IND, SAVE_VENDOR_DATA_TYP)SELECT new_oid(), 'BBGlobalEquityShortSaleCircuitBreak', 'db://resource/mapping/Bloomberg/BBGlobalEquityShortSaleCircuitBreak.mdx'
, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 'Y', 'N', NULL, 'SUCCESS', 'WARNING', 'ERROR', 'ERROR', 'ERROR'
,  TO_Date( '07/22/2011 01:12:25 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'anonymous', 'N'
, 'N', 'N', 'None' FROM DUAL
WHERE NOT EXISTS ( SELECT 'X' FROM FT_CFG_MSTP WHERE MSG_TYP_NME='BBGlobalEquityShortSaleCircuitBreak');



INSERT INTO FT_CFG_MSTP (MSTP_OID, MSG_TYP_NME, MAPPING_URI, BSFD_OID, VDDB_PROPAGATION_IND,
USE_KEY_TYP, MSG_KEY_XPATH, WRITE_EXCEPTION_TYP, WRITE_NOTFCN_TYP, SAVE_INPUT_MSG_TYP,
SAVE_TRANSLATED_MSG_TYP, SAVE_PROCESSED_MSG_TYP, LAST_CHG_TMS, LAST_CHG_USR_ID,
CAPTURE_PROCESSED_MSG_IND, ROLLBACK_ON_ERROR_IND, SYNC_PUBLISHING_IND, SAVE_VENDOR_DATA_TYP)SELECT new_oid(), 'BBGlobalEquityShortSale', 'db://resource/mapping/Bloomberg/BBGlobalEquityShortSale.mdx'
,(Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 'Y', 'N', NULL, 'SUCCESS', 'WARNING', 'ERROR', 'ERROR', 'ERROR'
,  TO_Date( '07/22/2011 01:13:26 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'anonymous', 'N'
, 'N', 'N', 'None' FROM DUAL
WHERE NOT EXISTS ( SELECT 'X' FROM FT_CFG_MSTP WHERE MSG_TYP_NME='BBGlobalEquityShortSale');

--VRTY

INSERT INTO FT_CFG_VRTY ( VND_RQST_TYP, DATA_SRC_ID, URI, MSTP_OID, FILE_PATTERN_TYP, EXIST_REC_IND,LAST_CHG_TMS, LAST_CHG_USR_ID, VND_RQST_DESC, VND_RQST_DPSY_IND )
SELECT 'EquityShortSaleCircuitBreak', 'BB', 'db://resource/xslt/request/bloomberg/BBGlobalEquity.xslt', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBGlobalEquityShortSaleCircuitBreak'), 'gs*.req', 'N',  TO_Date( '07/22/2011 12:38:17 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'autobnp', NULL, 'Y' FROM DUAL 
WHERE NOT EXISTS ( SELECT 'X' FROM FT_CFG_VRTY WHERE VND_RQST_TYP='EquityShortSaleCircuitBreak');


INSERT INTO FT_CFG_VRTY ( VND_RQST_TYP, DATA_SRC_ID, URI, MSTP_OID, FILE_PATTERN_TYP, EXIST_REC_IND,LAST_CHG_TMS, LAST_CHG_USR_ID, VND_RQST_DESC, VND_RQST_DPSY_IND )
SELECT 'EquityShortSale', 'BB', 'db://resource/xslt/request/bloomberg/BBGlobalEquity.xslt', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBGlobalEquityShortSale'), 'gs*.req', 'N',  TO_Date( '07/22/2011 12:38:17 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'autobnp', NULL, 'Y' FROM DUAL 
WHERE NOT EXISTS ( SELECT 'X' FROM FT_CFG_VRTY WHERE VND_RQST_TYP='EquityShortSale');