SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #: 138515
-- | Date: 2017-08-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Migration Script provided inorder to append leading zero in ISS_ID upto 8 character length where ID_CTXT_TYP='JAPAN'
-- |----------------------------------------------------------------

SELECT *
FROM FT_T_ISID
WHERE ID_CTXT_TYP='JAPAN'
AND END_TMS IS NULL
AND LENGTH(ISS_ID)<8
AND LAST_CHG_USR_ID LIKE '%BBEXTDPF%';

SET DEFINE ON;