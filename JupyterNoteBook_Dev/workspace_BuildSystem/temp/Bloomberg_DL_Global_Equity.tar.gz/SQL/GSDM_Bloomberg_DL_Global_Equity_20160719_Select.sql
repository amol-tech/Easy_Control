SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:437116
-- | GT Ticket #:127316
-- | Date: 2016-07-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Migration script to delete duplicate PPDF rows found on the basis of columns PRIN_EV_PRT_ID, EV_INSTR_ID and START_TMS for PEDF.EV_TYP = MATURITY.
-- | Main Script : GSDM_Bloomberg_DL_Global_Equity_20160719.sql
-- |----------------------------------------------------------------

SELECT   *
  FROM   FT_T_PPDF
 WHERE   PRIN_PAY_DEF_ID IN
               (SELECT   PRIN_PAY_DEF_ID
                  FROM   (SELECT   PRIN_PAY_DEF_ID,
                                   RANK ()
                                      OVER (
                                         PARTITION BY PRIN_EV_PRT_ID,
                                                      EV_INSTR_ID,
                                                      START_TMS
                                         ORDER BY LAST_CHG_TMS
                                      )
                                      PPDF_CNT
                            FROM   FT_T_PPDF
                           WHERE   PRIN_EV_PRT_ID IN
                                         (SELECT   PRIN_EV_PRT_ID
                                            FROM   FT_T_PEVP
                                           WHERE   PRIN_EV_DEF_ID IN
                                                         (SELECT   PRIN_EV_DEF_ID
                                                            FROM   FT_T_PEDF
                                                           WHERE   EV_TYP =
                                                                      'MATURITY')))
                 WHERE   PPDF_CNT > 1);

SET DEFINE ON;                 