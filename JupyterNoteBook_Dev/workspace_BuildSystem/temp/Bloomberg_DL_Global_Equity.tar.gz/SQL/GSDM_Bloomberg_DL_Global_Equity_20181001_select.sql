
SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:460548
-- | GT Ticket #:149810
-- | Date: 2018-09-07
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: Script to select records in ISID having IDCTXTTYP IN ('CPTICKER', 'CPSEDOL', 'CPBBUNIQ', 'CPGLOBAL','WI-CPGLOBAL') AND DATASRCID = 'BB'
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181001.sql
-- |----------------------------------------------------------------



SELECT *
  FROM FT_T_ISID
 WHERE     ID_CTXT_TYP IN ('TRDGSYSID', 'WI-TRDGSYSID')
       AND GLOBAL_UNIQ_IND = 'G'
       AND REGEXP_LIKE (LAST_CHG_USR_ID,
                        'BBEQEURO|BBNONEQLISOP|BBEQLISFUT|BBEQLISOP')
       AND END_TMS IS NULL;

SET DEFINE ON;