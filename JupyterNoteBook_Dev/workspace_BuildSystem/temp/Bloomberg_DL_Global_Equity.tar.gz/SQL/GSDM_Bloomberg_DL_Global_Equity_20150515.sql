-- |----------------------------------------------------------------
-- | Front Office #: 437116
-- | GT Ticket #: 115488
-- | Date: 2015-05-15
-- |----------------------------------------------------------------
-- | Product ID: GS Connectors
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_FICL
-- | Change Reason: 1) Migration To end date the duplicate records from FICL where INDUS_CL_SET_ID as 'INDSUBGR' or 'BBINDSGR' having the same INST_MNEM, CLSF_PURP_TYP and keep the latest one.
-- |								2) Migration script to update the INDUS_CL_SET_ID of the FICL record from 'INDSUBGR' to 'BBINDSGR'.
-- | Select Patch : GSDM_Bloomberg_DL_Global_Equity_20150515_SELECT.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_FICL SET END_TMS=SYSDATE, LAST_CHG_USR_ID='GS:MIG:BBEXTDPF:115488' where FINS_CLSF_OID in 
(SELECT FINS_CLSF_OID from (SELECT FINS_CLSF_OID, INST_MNEM, INDUS_CL_SET_ID, CLSF_PURP_TYP, LAST_CHG_TMS, ROW_NUMBER()
Over (PARTITION BY INST_MNEM, CLSF_PURP_TYP order by LAST_CHG_TMS desc) CNT 
from FT_T_FICL where INDUS_CL_SET_ID IN ('BBINDSGR','INDSUBGR') AND END_TMS IS NULL ) WHERE CNT !=1);

UPDATE FT_T_FICL set INDUS_CL_SET_ID = 'BBINDSGR', LAST_CHG_USR_ID='GS:MIG:BBEXTDPF:115488' where INDUS_CL_SET_ID = 'INDSUBGR' and END_TMS IS NULL;

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20150515.sql', 1, 'GT115488', SYSDATE, '8.99.38.0', '8.99.41.0', 'A',  SYSDATE);

SET DEFINE ON;