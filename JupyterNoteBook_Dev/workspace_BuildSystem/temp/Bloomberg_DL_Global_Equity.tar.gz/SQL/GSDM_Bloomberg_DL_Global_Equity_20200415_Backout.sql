SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 475625
-- | GT Ticket #: 161951
-- | Date: 2020-04-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nusrat Khan
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to revert the changes made via GSDM_Bloomberg_DL_Global_Equity_20200415.sql
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20200415_Select.sql
-- |----------------------------------------------------------------

DECLARE

--CURSOR 1

   CURSOR CUR_FICL_UPD
   IS
      SELECT * FROM FT_BKP_FICL_161951;

   TYPE TYP_FICL_UPD IS TABLE OF CUR_FICL_UPD%ROWTYPE;

   VAR_FICL      TYP_FICL_UPD;

--CURSOR 2

   CURSOR CUR_IRCL_UPD
   IS
      SELECT * FROM FT_BKP_IRCL_161951;

   TYPE TYP_IRCL_UPD IS TABLE OF CUR_IRCL_UPD%ROWTYPE;

   VAR_IRCL      TYP_IRCL_UPD;

   V_NUMERRORS   NUMBER (10);
   
BEGIN

--BACKOUT FICL

   OPEN CUR_FICL_UPD;

   LOOP
      FETCH CUR_FICL_UPD
         BULK COLLECT INTO VAR_FICL
         LIMIT 10000;

      FORALL I IN 1 .. VAR_FICL.COUNT SAVE EXCEPTIONS
         UPDATE /*+ APPEND */
               FT_T_FICL
            SET END_TMS = NULL,
                LAST_CHG_USR_ID = VAR_FICL (I).LAST_CHG_USR_ID,
                LAST_CHG_TMS = VAR_FICL (I).LAST_CHG_TMS
          WHERE FINS_CLSF_OID = VAR_FICL (I).FINS_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_FICL_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_FICL_UPD;

--BACKOUT IRCL

   OPEN CUR_IRCL_UPD;

   LOOP
      FETCH CUR_IRCL_UPD
         BULK COLLECT INTO VAR_IRCL
         LIMIT 10000;

      FORALL I IN 1 .. VAR_IRCL.COUNT SAVE EXCEPTIONS
         UPDATE /*+ APPEND */
               FT_T_IRCL
            SET END_TMS = NULL,
                LAST_CHG_USR_ID = VAR_IRCL (I).LAST_CHG_USR_ID,
                LAST_CHG_TMS = VAR_IRCL (I).LAST_CHG_TMS
          WHERE ISSR_CLSF_OID = VAR_IRCL (I).ISSR_CLSF_OID;

      COMMIT;

      EXIT WHEN CUR_IRCL_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_IRCL_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS);

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || V_COUNT
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;