SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:448051
-- | GT Ticket #:119930
-- | Date: 2015-09-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sonal Chaudhary
-- | Approved By: Prashant Zamre
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MICL
-- | Select Script name : GSDM_Bloomberg_DL_Global_Equity_20150910_SELECT.sql
-- | Change Reason: Migration script to update CLSF_PURP_TYP in MICL table
-- |                with INDCLASS if LEVEL_NUM from INCL is 1 or with INSUBTYP if LEVEL_NUM from INCL is 2.
-- |----------------------------------------------------------------

DECLARE

    v_NumErrors     NUMBER(10);

    TYPE R_TYPE IS RECORD (P_CLSF_PURP_TYP FT_T_MICL.CLSF_PURP_TYP%TYPE, P_MICL_OID FT_T_MICL.MICL_OID%TYPE);

    TYPE TR_LSE_CODE_TYPE IS TABLE OF R_TYPE;
    
    P_BULKCLEANUP   TR_LSE_CODE_TYPE;

    CURSOR  CUR_LSE_CODES IS    
        
        SELECT  CASE B.LEVEL_NUM WHEN 1 THEN 'INDCLASS'
                WHEN 2 THEN   'INSUBTYP'
                ELSE '' END AS CLSF_PURP_TYP, A.MICL_OID
        FROM    FT_T_MICL A,
                FT_T_INCL B
        WHERE   A.INDUS_CL_SET_ID = B.INDUS_CL_SET_ID
        AND     B.LEVEL_NUM IN ('1','2')
        AND     A.CLSF_OID = B.CLSF_OID
        AND     A.CLSF_PURP_TYP IS NULL
        AND     A.INDUS_CL_SET_ID = 'LSESEGMENT'
        AND     A.END_TMS IS NULL;
    
--VAR_CUR_LSE_CODES CUR_LSE_CODES%ROWTYPE;
    
BEGIN
    
--    FOR VAR_CUR_LSE_CODES IN CUR_LSE_CODES LOOP

OPEN    CUR_LSE_CODES;

LOOP

    FETCH  CUR_LSE_CODES BULK COLLECT INTO P_BULKCLEANUP LIMIT 1000;
    
        FORALL I IN 1..P_BULKCLEANUP.COUNT SAVE EXCEPTIONS
    
            UPDATE  FT_T_MICL
            SET     CLSF_PURP_TYP = P_BULKCLEANUP (I).P_CLSF_PURP_TYP,
                    LAST_CHG_USR_ID = 'GS:MIG:119930:BBEQEURO'
            WHERE   MICL_OID =  P_BULKCLEANUP (I).P_MICL_OID;
        
    EXIT WHEN CUR_LSE_CODES%NOTFOUND;
    
    END LOOP;

    CLOSE CUR_LSE_CODES;
       
         EXCEPTION
               WHEN OTHERS THEN
                 DBMS_OUTPUT.PUT_LINE('Got exception: ' || SQLERRM);
                 v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
                 DBMS_OUTPUT.PUT_LINE(
                   'Number of errors during processing: ' || v_NumErrors);
                 FOR v_Count IN 1..v_NumErrors LOOP
                   DBMS_OUTPUT.PUT_LINE('Error ' || v_Count || ', iteration ' ||
                     SQL%BULK_EXCEPTIONS(v_Count).error_index || ' is: ' ||
                     SQLERRM(0 - SQL%BULK_EXCEPTIONS(v_Count).error_code));
                 END LOOP;

    
END;

 Insert INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
 VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20150910.sql', 1, 'GT119930', SYSDATE, '8.99.25.0', '8.99.46.0', 'A',  SYSDATE);