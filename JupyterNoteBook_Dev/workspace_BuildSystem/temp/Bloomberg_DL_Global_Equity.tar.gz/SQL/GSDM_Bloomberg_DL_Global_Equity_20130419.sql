-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:90032
-- | Date: 2013-04-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Suvarna Rane 
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS, FT_T_ISSU
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20130419_SELECT.sql
-- | Change Reason: 1) Migration script to update MKIS.ACTIVELY_TRADED_IND as 'Y' when ISSU.ISS_ACTVY_STAT_TYP is 'ACTIVE'
-- |                2) Migration script to update MKIS.ACTIVELY_TRADED_IND as 'N' when ISSU.ISS_ACTVY_STAT_TYP is 'INACTIVE' 
-- |                3) Migration script to update the ISSU.ISS_ACTVY_STAT_TYP to 'ACTIVE' wherever it is set up as INACTIVE or DEFAULT for last_chng_usr_id - "BBEXTDPF"    
-- |----------------------------------------------------------------

set define off;

update ft_t_mkis a set ACTIVELY_TRADED_IND='Y' , last_chg_usr_id ='GS:MIG:BBEXTDPF' where instr_id in (select instr_id from ft_t_issu b where ISS_ACTVY_STAT_TYP ='ACTIVE' and last_chg_usr_id like '%BBEXTDPF%'and a.instr_id=b.instr_id )and ACTIVELY_TRADED_IND is null and last_chg_usr_id like '%BBEXTDPF%';

update ft_t_mkis a set ACTIVELY_TRADED_IND='N' , last_chg_usr_id ='GS:MIG:BBEXTDPF' where instr_id in (select instr_id from ft_t_issu b where ISS_ACTVY_STAT_TYP ='INACTIVE' and last_chg_usr_id like '%BBEXTDPF%'and a.instr_id=b.instr_id )and ACTIVELY_TRADED_IND is null and last_chg_usr_id like '%BBEXTDPF%';

update ft_t_issu set ISS_ACTVY_STAT_TYP='ACTIVE', last_chg_usr_id ='GS:MIG:BBEXTDPF' where last_chg_usr_id like '%BBEXTDPF%' and ISS_ACTVY_STAT_TYP ='INACTIVE';

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130419.sql', 1, 'GT#90032', TO_DATE( '04/19/2013 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.5.0', 'A',  SYSDATE);

set define on;