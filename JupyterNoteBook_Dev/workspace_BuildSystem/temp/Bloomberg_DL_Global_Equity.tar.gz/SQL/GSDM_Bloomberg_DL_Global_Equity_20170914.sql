-- |----------------------------------------------------------------
-- | Front Office #:456025
-- | GT Ticket #:139574
-- | Date: 2017-09-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: Script to update ISID.MKTOID to point to the composite exchanges that are newly created in MKID having MKID.MKTIDCTXTTYP = 'BBCOMPEXCH'
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170914_Select.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

BEGIN
    
/* CREATING BACKUP TABLE */
    
EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISID_BKP_139574
AS
SELECT   ISID_OID,ID_CTXT_TYP,INSTR_ID,MKT_OID,LAST_CHG_TMS,LAST_CHG_USR_ID
        FROM   FT_T_ISID
       WHERE   MKT_OID IN
                     (SELECT   A.MKT_OID
                        FROM   FT_T_MKID A, FT_T_MKID B
                       WHERE       A.MKT_ID_CTXT_TYP = ''BBEXCH''
                               AND B.MKT_ID_CTXT_TYP = ''BBCOMPEXCH''
                               AND A.MKT_ID = B.MKT_ID
                               AND A.MKT_OID != B.MKT_OID
                               AND A.DATA_SRC_ID = ''BB''
                               AND B.DATA_SRC_ID = ''BB''
                               AND A.END_TMS IS NULL
                               AND B.END_TMS IS NULL)
               AND ID_CTXT_TYP IN (''CPTICKER'', ''CPSEDOL'', ''CPBBUNIQ'', ''CPGLOBAL'',''WI-CPGLOBAL'')
               AND DATA_SRC_ID = ''BB''
               AND END_TMS IS NULL
               AND MKT_OID NOT IN
                        (SELECT   DISTINCT MKT_OID
                           FROM   FT_T_MKID
                          WHERE   MKT_ID IN (''IA'',''BC'',''ZS'',''GU'',''JY'',''EK'',''AI'',''NX'',''LN'',''LI'')
                                  AND MKT_ID_CTXT_TYP = ''BBEXCH''
                                  AND DATA_SRC_ID = ''BB'')';


EXECUTE IMMEDIATE 'ALTER TABLE FT_T_ISID_BKP_139574 ADD CONSTRAINT
      FT_T_ISID_BKP_139574_PK PRIMARY KEY(ISID_OID)';
   
EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISID_DUP_BKP_139574
AS
SELECT   ISID_OID,ID_CTXT_TYP,INSTR_ID,MKT_OID,LAST_CHG_TMS,LAST_CHG_USR_ID
         FROM   FT_T_ISID
        WHERE   INSTR_ID IN
                      (SELECT   INSTR_ID
                         FROM   FT_T_ISID
                        WHERE   MKT_OID IN
                                      (SELECT   DISTINCT MKT_OID
                                         FROM   FT_T_MKID
                                        WHERE   MKT_ID IN (''IA'',''BC'',''ZS'',''GU'',''JY'',''EK'',''AI'',''NX'',''LN'',''LI'')
                                                AND MKT_ID_CTXT_TYP =''BBEXCH''
                                                AND DATA_SRC_ID = ''BB''
                                                AND END_TMS IS NULL)
                                AND ID_CTXT_TYP = ''CPTICKER''
                                AND DATA_SRC_ID = ''BB''
                                AND END_TMS IS NULL)
                AND ID_CTXT_TYP IN (''CPTICKER'', ''CPSEDOL'', ''CPBBUNIQ'', ''CPGLOBAL'',''WI-CPGLOBAL'')
                AND MKT_OID IN (SELECT   DISTINCT MKT_OID
                      FROM   FT_T_MKID
                     WHERE   MKT_ID IN (''IA'',''BC'',''ZS'',''GU'',''JY'',''EK'',''AI'',''NX'',''LN'',''LI'')
                             AND MKT_ID_CTXT_TYP = ''BBEXCH''
                             AND DATA_SRC_ID = ''BB''
                             AND END_TMS IS NULL)
                AND DATA_SRC_ID = ''BB''
                AND END_TMS IS NULL';


   EXECUTE IMMEDIATE 'ALTER TABLE FT_T_ISID_DUP_BKP_139574 ADD CONSTRAINT
      FT_T_ISID_DUP_BKP_139574_PK PRIMARY KEY(ISID_OID)';   
      
      
END;

DECLARE
   v_NumErrors    NUMBER (10);

   CURSOR CUR_ISID
   IS
      SELECT  *                     
        FROM  FT_T_ISID_BKP_139574;
      


   CURSOR CUR_ISID_DUP
   IS
       SELECT  *                     
         FROM  FT_T_ISID_DUP_BKP_139574;


   TYPE TAB_ISID IS TABLE OF CUR_ISID%ROWTYPE;

   VAR_ISID       TAB_ISID;

   TYPE TAB_ISID_DUP IS TABLE OF CUR_ISID_DUP%ROWTYPE;

   VAR_ISID_DUP   TAB_ISID_DUP;
   
BEGIN
   
   OPEN CUR_ISID;

   LOOP
      FETCH CUR_ISID BULK COLLECT INTO   VAR_ISID LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_ISID
            SET   MKT_OID =
                     (SELECT   MKT_OID
                        FROM   FT_T_MKID
                       WHERE   MKT_ID IN
                                     (SELECT   MKT_ID
                                        FROM   FT_T_MKID
                                       WHERE   MKT_OID = VAR_ISID (I).MKT_OID
                                               AND MKT_ID_CTXT_TYP = 'BBEXCH'
                                               AND DATA_SRC_ID = 'BB')
                               AND MKT_ID_CTXT_TYP = 'BBCOMPEXCH'
                               AND DATA_SRC_ID = 'BB'),
                  LAST_CHG_USR_ID = 'GS:MIG:139574:BB',
                  LAST_CHG_TMS = SYSDATE
          WHERE   ISID_OID = VAR_ISID (I).ISID_OID;
          
          COMMIT;

      EXIT WHEN CUR_ISID%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID;


   
   OPEN CUR_ISID_DUP;

   LOOP
      FETCH CUR_ISID_DUP BULK COLLECT INTO   VAR_ISID_DUP LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_DUP.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_ISID
            SET   MKT_OID =
                     (SELECT   MKT_OID
                        FROM   FT_T_MKID
                       WHERE   MKT_ID =
                                  (SELECT   DISTINCT SUBSTR (RTRIM (ISS_ID), -2, 2)
                                     FROM   FT_T_ISID
                                    WHERE   ID_CTXT_TYP = 'CPTICKER'
                                            AND INSTR_ID = VAR_ISID_DUP (I).INSTR_ID
                                            AND MKT_OID =  VAR_ISID_DUP (I).MKT_OID)
                               AND MKT_ID_CTXT_TYP = 'BBCOMPEXCH'
                               AND DATA_SRC_ID = 'BB'),
                  LAST_CHG_USR_ID = 'GS:MIG:139574:BB',
                  LAST_CHG_TMS = SYSDATE
          WHERE       INSTR_ID = VAR_ISID_DUP (I).INSTR_ID
                  AND MKT_OID = VAR_ISID_DUP (I).MKT_OID
                  AND ISID_OID = VAR_ISID_DUP (I).ISID_OID;
                  
      COMMIT;            

      EXIT WHEN CUR_ISID_DUP%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_DUP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors
      );

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || v_Count
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(v_Count).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(v_Count).ERROR_CODE));
      END LOOP;
END;


INSERT INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20170914.sql',1, 'GT139574', SYSDATE, '8.99.66.0', '8.99.68.0', 'A',  SYSDATE);

COMMIT;

SET DEFINE ON;