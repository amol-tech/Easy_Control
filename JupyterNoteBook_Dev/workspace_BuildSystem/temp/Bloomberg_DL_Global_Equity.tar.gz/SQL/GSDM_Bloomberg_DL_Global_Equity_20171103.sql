SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456382
-- | GT Ticket #:141093
-- | Date: 2017-10-27
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST
-- | Change Reason: Script to identify duplicate ISST based on INSTR_ID and STAT_DEF_ID ='POSEURPR' and retain the latest ISST.
-- |                Also update ISST.DENOM_CURR_CDE with ISSU.DENOM_CURR_CDE of all active ISST records where STAT_DEF_ID ='POSEURPR'
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171103_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_ISST_141093
AS
   SELECT   STAT_ID,
         INSTR_ID,
         STAT_DEF_ID,
         DENOM_CURR_CDE,
         LAST_CHG_TMS,
         LAST_CHG_USR_ID,
         START_TMS,
         END_TMS
  FROM   FT_T_ISST A
 WHERE       END_TMS IS NULL
         AND STAT_DEF_ID = ''POSEURPR''
         AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%''';


   EXECUTE IMMEDIATE 'ALTER TABLE FT_BAK_ISST_141093 ADD CONSTRAINT FT_BAK_ISST_141093_PK PRIMARY KEY(STAT_ID)';
END;

DECLARE
   CURSOR CUR_DELDUP
   IS
      SELECT   *
        FROM   (SELECT   ISST.INSTR_ID,
                         ISST.STAT_ID,
                         ISST.LAST_CHG_USR_ID,
                         ISST.DENOM_CURR_CDE,
                         ISSU.DENOM_CURR_CDE ISSU_DENOM_CURR_CDE,
                         ROW_NUMBER ()
                            OVER (
                               PARTITION BY ISST.INSTR_ID
                               ORDER BY
                                  CASE
                                     WHEN ISST.DENOM_CURR_CDE =
                                             ISSU.DENOM_CURR_CDE
                                     THEN
                                        1
                                  END,
                                  ISST.LAST_CHG_TMS DESC
                            )
                            CNT
                  FROM   FT_T_ISST ISST, FT_T_ISSU ISSU
                 WHERE       ISST.STAT_DEF_ID = 'POSEURPR'
                         AND ISST.INSTR_ID = ISSU.INSTR_ID
                         AND ISST.END_TMS IS NULL
                         AND ISST.LAST_CHG_USR_ID LIKE '%BBEQEURO%')
       WHERE   CNT > 1;

   CURSOR CUR_UPDISST
   IS
      SELECT   STAT_ID,
               LAST_CHG_USR_ID,
               INSTR_ID,
               DENOM_CURR_CDE
        FROM   FT_T_ISST
       WHERE       STAT_DEF_ID = 'POSEURPR'
               AND END_TMS IS NULL
               AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

   V_DENOM   FT_T_ISSU.DENOM_CURR_CDE%TYPE;
BEGIN
   FOR ENDDT IN CUR_DELDUP
   LOOP
      UPDATE   FT_T_ISST
         SET   END_TMS = SYSDATE,
               LAST_CHG_TMS = SYSDATE,
               LAST_CHG_USR_ID = 'GS:MIG:141093:' || LAST_CHG_USR_ID
       WHERE   STAT_ID = ENDDT.STAT_ID;

      COMMIT;
   END LOOP;

   FOR UPD IN CUR_UPDISST
   LOOP
      SELECT   DENOM_CURR_CDE
        INTO   V_DENOM
        FROM   FT_T_ISSU
       WHERE   INSTR_ID = UPD.INSTR_ID;


      IF NVL (V_DENOM, 'GSO') <> NVL (UPD.DENOM_CURR_CDE, 'GSO')
      THEN
         UPDATE   FT_T_ISST ISST
            SET   DENOM_CURR_CDE = V_DENOM,
                  LAST_CHG_USR_ID = 'GS:MIG:141093:' || LAST_CHG_USR_ID,
                  LAST_CHG_TMS = SYSDATE
          WHERE   STAT_ID = UPD.STAT_ID;

         COMMIT;
      END IF;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLCODE || ' - ' || SQLERRM);
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   ('GSDM_Bloomberg_DL_Global_Equity_20171103.sql',
            1,
            'GT141093',
            SYSDATE,
            '8.99.69.0',
            '8.99.70.0',
            'A',
            SYSDATE);

COMMIT;

SET DEFINE ON;