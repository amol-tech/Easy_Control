SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 464164
-- | GT Ticket #: 156691
-- | Date: 2019-07-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID, FT_T_IBMR
-- | Change Reason: Script to fetch the ISID's been created with null ISS_USAGE_TYP in FT_T_ISID and its corresponding records present in FT_T_IBMR.
-- | Update Query : GSDM_Bloomberg_DL_Global_Equity_20190715.sql
-- |----------------------------------------------------------------


SELECT  *
FROM    FT_T_ISID
WHERE   (ISS_ID,ID_CTXT_TYP) IN (
                    SELECT  ISS_ID,ID_CTXT_TYP
                    FROM    FT_T_ISID
                    WHERE   ID_CTXT_TYP = 'BBIDXTKR'
                    AND     END_TMS IS NULL
                    GROUP BY ISS_ID,ID_CTXT_TYP
                    HAVING COUNT(1) > 1)
AND     ID_CTXT_TYP = 'BBIDXTKR'
AND     END_TMS IS NULL
AND     ISS_USAGE_TYP IS NULL;

-------------------------------------------------------------------------
-------------------------------------------------------------------------
                    
SELECT  DISTINCT B.*
FROM    FT_T_ISID A,
        FT_T_IBMR B
WHERE   A.INSTR_ID = B.INSTR_ID
AND     A.ID_CTXT_TYP = 'BBIDXTKR'
AND     A.ISS_USAGE_TYP IS NULL
AND     B.END_TMS IS NULL
AND     (A.ISS_ID,ID_CTXT_TYP) IN ( 
                SELECT  ISS_ID,
                        ID_CTXT_TYP
                FROM    FT_T_ISID
                WHERE   (ISS_ID, ID_CTXT_TYP) IN (
                                                SELECT  DISTINCT C.ISS_ID,
                                                        C.ID_CTXT_TYP
                                                FROM    FT_T_ISID C,
                                                        FT_T_IBMR D
                                                WHERE   C.INSTR_ID = D.INSTR_ID
                                                AND     C.ID_CTXT_TYP = 'BBIDXTKR'
                                                AND     C.ISS_USAGE_TYP IS NULL
                                                INTERSECT
                                                SELECT  DISTINCT C.ISS_ID,
                                                        C.ID_CTXT_TYP
                                                FROM    FT_T_ISID C,
                                                        FT_T_IBMR D
                                                WHERE   C.INSTR_ID = D.INSTR_ID
                                                AND     C.ID_CTXT_TYP = 'BBIDXTKR'
                                                AND     C.ISS_USAGE_TYP IS NOT NULL)
                AND     ID_CTXT_TYP = 'BBIDXTKR'
                GROUP BY ISS_ID, ID_CTXT_TYP
                HAVING COUNT(1) > 1);

-------------------------------------------------------------------------
-------------------------------------------------------------------------                

SELECT  Y.*, X.INSTR_ID AS ACTIVE_INSTR_ID
FROM    (   SELECT  B.*,
                    (   SELECT  C.INSTR_ID
                        FROM    FT_T_ISID C
                        WHERE   B.ISS_ID = C.ISS_ID
                        AND     C.ID_CTXT_TYP = 'BBIDXTKR'
                        AND     C.ISS_USAGE_TYP IS NULL) AS INACTIVE_INSTR_ID
            FROM    FT_T_ISID B
            WHERE   (B.ISS_ID, B.ID_CTXT_TYP) IN (
                                        SELECT  ISS_ID,ID_CTXT_TYP
                                        FROM    FT_T_ISID
                                        WHERE   ID_CTXT_TYP = 'BBIDXTKR'
                                        AND     END_TMS IS NULL
                                        GROUP BY ISS_ID,ID_CTXT_TYP
                                        HAVING COUNT(1) > 1)
            AND     NOT EXISTS (SELECT  'X'
                                FROM    FT_T_IBMR C
                                WHERE   B.INSTR_ID = C.INSTR_ID)
            AND     ID_CTXT_TYP = 'BBIDXTKR') X,
            FT_T_IBMR Y
WHERE   X.INACTIVE_INSTR_ID = Y.INSTR_ID
AND     Y.END_TMS IS NULL;


SET DEFINE ON;