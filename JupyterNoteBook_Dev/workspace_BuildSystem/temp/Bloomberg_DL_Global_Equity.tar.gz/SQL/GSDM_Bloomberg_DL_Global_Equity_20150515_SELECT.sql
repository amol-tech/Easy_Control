-- |----------------------------------------------------------------
-- | Front Office #: 437116
-- | GT Ticket #: 115488
-- | Date: 2015-05-15
-- |----------------------------------------------------------------
-- | Product ID: GS Connectors
-- | Project ID: Bloomberg
-- | Requested By: Keval Savla
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_FICL
-- | Change Reason: 1) Select Query for Migration To end date the duplicate records from FICL where INDUS_CL_SET_ID as 'INDSUBGR' or 'BBINDSGR' having the same INST_MNEM, CLSF_PURP_TYP and keep the latest one.
-- |								2) Select Query for Migration script to update the INDUS_CL_SET_ID of the FICL record from 'INDSUBGR' to 'BBINDSGR'.
-- | Main Patch : GSDM_Bloomberg_DL_Global_Equity_20150515.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

Select * from FT_T_FICL where FINS_CLSF_OID in 
(SELECT FINS_CLSF_OID from (SELECT FINS_CLSF_OID, INST_MNEM, INDUS_CL_SET_ID, CLSF_PURP_TYP, LAST_CHG_TMS, ROW_NUMBER()
Over (PARTITION BY INST_MNEM, CLSF_PURP_TYP order by LAST_CHG_TMS desc) CNT 
from FT_T_FICL where INDUS_CL_SET_ID IN ('BBINDSGR','INDSUBGR') AND END_TMS IS NULL ) WHERE CNT !=1);

Select * from FT_T_FICL where INDUS_CL_SET_ID = 'INDSUBGR' and END_TMS IS NULL;

SET DEFINE ON;