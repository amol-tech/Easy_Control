-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:74931
-- | Date: 2012-03-12
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Divya Poojari
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID.
-- | Change Reason: Migration Script to update ID_CTXT_TYP from 'TRDGSYMB' to 'BBTRDGSYMB'
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_ISID SET ID_CTXT_TYP='BBTRDGSYMB',LAST_CHG_USR_ID='GS:CON:MIG' WHERE ID_CTXT_TYP='TRDGSYMB' AND DATA_SRC_ID='BB';

SET DEFINE ON;







