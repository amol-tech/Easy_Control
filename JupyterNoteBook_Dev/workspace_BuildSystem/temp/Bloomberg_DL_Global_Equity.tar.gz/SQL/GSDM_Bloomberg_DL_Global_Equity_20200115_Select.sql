-- | GT Ticket #:160637
-- | Date: 2020-01-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Kamini Shukla
-- | Approved By: Nilesh Desai
-- | Tables Affected: FT_T_IEDF
-- | Change Reason:Script to remove '-----' from IEDF.EV_DESC and IEDF.DAY_CNT_DESC..
-- | Main Query:GSDM_Bloomberg_DL_Global_Equity_20200115.sql
-- |----------------------------------------------------------------


SET DEFINE OFF;

SELECT *
  FROM FT_T_IEDF
 WHERE    EV_DESC IN
             ('ISDA 30E/360-----', 'ISDA 30E/365-----', 'ISDA 30E/ACT-----')
       OR DAY_CNT_DESC IN
             ('ISDA 30E/360-----', 'ISDA 30E/365-----', 'ISDA 30E/ACT-----');

SET DEFINE ON;