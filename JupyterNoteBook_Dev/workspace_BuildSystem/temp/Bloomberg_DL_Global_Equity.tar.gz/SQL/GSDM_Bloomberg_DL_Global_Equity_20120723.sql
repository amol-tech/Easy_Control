-- |----------------------------------------------------------------
-- | Front Office #:435829
-- | GT Ticket #:80014
-- | Date: 2012-07-23
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Swapnali Jadhav	
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: 1.Endating the duplicate rows by keeping the record without market active in the database(i.e. The record present with MKT_OID will end dated) For the same INSTR_ID ,ISS_ID and ID_CTXT_TYP='SICOVAM' for Bloomberg.
-- |                2.Removing MKT_OID if the single row present in the database with INSTR_ID ,ISS_ID and ID_CTXT_TYP='SICOVAM' with MKT_OID for Bloomberg
-- |----------------------------------------------------------------

SET DEFINE OFF;

--1.Endating the duplicate rows by keeping the record without market active in the database(i.e. The record present with MKT_OID will end dated) For the same INSTR_ID ,ISS_ID and ID_CTXT_TYP='SICOVAM' for Bloomberg.

update FT_T_ISID set END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:MIG:80014' where isid_oid in (select isid_oid from ft_T_isid a where (select count(*) from ft_T_isid b where a.instr_id= b.instr_id and a.iss_id = b.iss_id and id_ctxt_typ='SICOVAM') > 1 and MKT_OID is not null and LAST_CHG_USR_ID like 'BB%');

update FT_T_ISID set END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:MIG:80014' where isid_oid in (select isid_oid from ft_T_isid a where (select count(*) from ft_T_isid b where a.instr_id= b.instr_id and a.iss_id = b.iss_id and id_ctxt_typ='WI-SICOVAM') > 1 and MKT_OID is not null and LAST_CHG_USR_ID like 'BB%');

--2.Removing MKT_OID if the single row present in the database with INSTR_ID ,ISS_ID and ID_CTXT_TYP='SICOVAM' with MKT_OID for Bloomberg

Update FT_T_ISID set MKT_OID=null,LAST_CHG_USR_ID='GS:MIG:80014' where isid_oid in (select isid_oid from ft_T_isid a where (select count(*) from ft_T_isid b where a.instr_id= b.instr_id and a.iss_id= b.iss_id and id_ctxt_typ='SICOVAM' ) = 1 and mkt_oid is not null and LAST_CHG_USR_ID like 'BB%');

Update FT_T_ISID set MKT_OID=null,LAST_CHG_USR_ID='GS:MIG:80014' where isid_oid in (select isid_oid from ft_T_isid a where (select count(*) from ft_T_isid b where a.instr_id= b.instr_id and a.iss_id= b.iss_id and id_ctxt_typ='WI-SICOVAM' ) = 1 and mkt_oid is not null and LAST_CHG_USR_ID like 'BB%');

SET DEFINE ON;