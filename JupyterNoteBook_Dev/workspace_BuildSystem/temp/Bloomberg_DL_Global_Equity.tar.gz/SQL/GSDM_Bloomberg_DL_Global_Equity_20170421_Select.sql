SET DEFINE OFF;
--------------------------------------------------------------
-- | Frontoffice ID #:454284
-- | GT Ticket #: 134195
-- | Date: 21-04-2017 
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- | Tables Affected: FT_T_ISID, FT_T_MIXR
-- | Change Reason: Script to select the ISID rows where ID_CTXT_TYP='BBUNIQUE' for the below mentioned asset classes along with its MIXR's
-- | Script Name: GSDM_Bloomberg_DL_Global_Equity_20170421.sql
--------------------------------------------------------------


SELECT /*+PARALLEL(16)*/ DISTINCT ISID.*
FROM
 (SELECT   /*+PARALLEL(16)*/  A.*
                            FROM    FT_T_ISID A WHERE A.ID_CTXT_TYP = 'BBUNIQUE') ISID,
                            ( SELECT /*+PARALLEL(16)*/    B.INSTR_ID FROM
                                    FT_T_ISCL B,
                                    FT_T_INCL C
                            WHERE   B.CLSF_OID = C.CLSF_OID
                            and     B.CL_value = C.CL_VALUE 
                            AND     C.INDUS_CL_SET_ID = 'BBMKTSCT'    
                            AND     C.cl_nme IN ('Govt',
                                                                                          'Pfd',
                                                                                          'Corp',
                                                                                          'Mtge',
                                                                                          'Muni',
                                                                                          'ComdtyFut',
                                                                                          'ComdtyOpt',
                                                                                          'Comdty','Index','Curncy')) ISCL
              WHERE    ISID.INSTR_ID=ISCL.INSTR_ID
 UNION
 SELECT /*+PARALLEL(16)*/ * FROM (SELECT * FROM 
                      (SELECT /*+PARALLEL(16)*/ * FROM FT_T_ISID WHERE ID_CTXT_TYP='BBUNIQUE' ) A
                      WHERE  EXISTS( SELECT 1 FROM FT_T_ISID B
                                    WHERE A.ISS_ID=B.ISS_ID
                                    AND A.INSTR_ID!=B.INSTR_ID
                                    AND A.START_TMS=B.START_TMS
                                    AND B.ID_CTXT_TYP=A.ID_CTXT_TYP));              




SELECT * FROM FT_T_MIXR 
WHERE ISID_OID IN (SELECT ISID.ISID_OID FROM FT_T_ISID ISID,
																				FT_T_ISCL ISCL,
																				FT_T_INCL INCL
									WHERE ISID.INSTR_ID=ISCL.INSTR_ID
									AND ISID.ID_CTXT_TYP='BBUNIQUE'
									AND ISCL.CLSF_OID=INCL.CLSF_OID
									AND INCL.INDUS_CL_SET_ID = 'BBMKTSCT'    
                            AND     INCL.cl_nme IN ('Govt',
                                                                                          'Pfd',
                                                                                          'Corp',
                                                                                          'Mtge',
                                                                                          'Muni',
                                                                                          'ComdtyFut',
                                                                                          'ComdtyOpt',
                                                                                          'Comdty','Index','Curncy'))
AND END_TMS IS NULL;



SET DEFINE ON;                                                                                           


    
    