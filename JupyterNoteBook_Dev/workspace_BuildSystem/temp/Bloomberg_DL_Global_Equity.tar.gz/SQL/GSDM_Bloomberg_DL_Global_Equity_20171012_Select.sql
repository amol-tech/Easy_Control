SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456436
-- | GT Ticket #:139015
-- | Date: 2017-10-12
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST, FT_T_MUST
-- | Change Reason: Script to select the ISST rows having STAT_DEF_ID='ADJIPOPX'
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20171012.sql
-- |----------------------------------------------------------------

SELECT   *
  FROM   FT_T_ISST 
 WHERE   STAT_DEF_ID = 'ADJIPOPX' AND STAT_VAL_CAMT IS NOT NULL AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
         AND END_TMS IS NULL
         AND INSTR_ID IN (  SELECT   INSTR_ID
                              FROM   FT_T_MKIS
                             WHERE   END_TMS IS NULL
                          GROUP BY   INSTR_ID
                            HAVING   COUNT ( * ) = 1);
                                                    

SET DEFINE ON;                            