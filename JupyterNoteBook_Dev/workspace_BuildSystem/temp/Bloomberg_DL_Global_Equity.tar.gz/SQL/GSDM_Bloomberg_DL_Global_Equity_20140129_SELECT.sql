-- |----------------------------------------------------------------
-- | Front Office #:439312
-- | GT Ticket #:99365
-- | Date: 2014-01-29
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Keval Savla
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_RIDF,FT_T_RISS,FT_T_RIXR
-- | SQL Patch : GSDM_Bloomberg_DL_Global_Equity_20140129.sql
-- | Change Reason: Select Script to fetch the duplicate RIDF rows present with REL_TYP= 'CONV' or 'WARRANT' for the same instr_id having same LEG_NUM and its respective RISS's and RIXR's.
-- |----------------------------------------------------------------


SET DEFINE OFF;


----RIDF Select

select * from ft_T_ridf where 
 RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from (select RLD_ISS_FEAT_ID,rel_typ,instr_id,last_chg_tms,row_number() over
(partition by instr_id,rel_typ,leg_num order by last_chg_tms desc)  cnt 
from ft_T_ridf where rel_typ in ('CONV','WARRANT') and end_tms is null )x where cnt!=1);

----RISS Select

select * from ft_t_riss where RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from (select RLD_ISS_FEAT_ID,rel_typ,instr_id,last_chg_tms,row_number() over
(partition by instr_id,rel_typ,leg_num order by last_chg_tms desc)  cnt 
from ft_T_ridf where rel_typ in ('CONV','WARRANT') and end_tms is null )x where cnt!=1) and end_tms is null;

----RIXR Select 

select * from ft_t_rixr where riss_oid in (select riss_oid from fT_T_riss where RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from (select RLD_ISS_FEAT_ID,rel_typ,instr_id,last_chg_tms,row_number() over
(partition by instr_id,rel_typ,leg_num order by last_chg_tms desc)  cnt 
from ft_T_ridf where rel_typ in ('CONV','WARRANT') and end_tms is null )x where cnt!=1)and end_tms is null) and end_tms is null;

SET DEFINE ON;