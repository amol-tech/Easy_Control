SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454063
-- | GT Ticket #: 136338
-- | Date: 2017-06-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_PPDF
-- | Change Reason: Script to rollback the changes provided through GSDM_Bloomberg_DL_Global_Equity_20170628.sql
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170628.sql
-- |----------------------------------------------------------------


BEGIN
   
      INSERT INTO FT_T_PPDF
      SELECT   *
        FROM   FT_T_PPDF_BKP_136338
       WHERE   PRIN_PAY_DEF_ID NOT IN
                     (SELECT   PRIN_PAY_DEF_ID FROM FT_T_PPDF);
END;

SET DEFINE ON;