SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:448051
-- | GT Ticket #:119930
-- | Date: 2015-09-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sonal Chaudhary
-- | Approved By: Prashant Zamre
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MICL
-- | Select Script name : GSDM_Bloomberg_DL_Global_Equity_20150910_Select.sql
-- | Change Reason: Script to fetch the records which are going to get updated in MICL table.
-- |----------------------------------------------------------------        
		
		SELECT  *
        FROM    FT_T_MICL A,
                FT_T_INCL B
        WHERE   A.INDUS_CL_SET_ID = B.INDUS_CL_SET_ID
        AND     B.LEVEL_NUM IN ('1','2')
        AND     A.CLSF_OID = B.CLSF_OID
        AND     A.CLSF_PURP_TYP IS NULL
        AND     A.INDUS_CL_SET_ID = 'LSESEGMENT'
        AND     A.END_TMS IS NULL;
        
SET DEFINE ON;