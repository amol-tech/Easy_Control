SET DEFINE OFF;
--------------------------------------------------------------
-- | Frontoffice ID #:452378
-- | GT Ticket #: 129547
-- | Date: 21 November 2016
-- | Product ID: GS Securities
-- | Project ID: BBDLGlobalEquity
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- | Tables Affected:FT_T_MKIS
-- | Change Reason:Migration script provided to update field TRDNG_UT_MEAS_TYP  to 'PIECE' for the existing rows where the field TRDNG_UT_MEAS_TYP is 'SHARE'
-- | and record exists in ft_T_iscl table with same instr_id as that of ft_t_mkis where field INDUS_CL_SET_ID is 'BBSECTYP' and CLSF_PURP_TYP is 'INSUBTYP' and CL_VALUE is 'Mutual Fund'
-- | Query Patch Name:GSDM_Bloomberg_DL_Global_Equity_20161121_Select.sql
----------------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_MKIS_129547
                     AS
                        SELECT MKT_ISS_OID,TRDNG_UT_MEAS_TYP,LAST_CHG_USR_ID,LAST_CHG_TMS  FROM FT_T_MKIS MKIS
                        WHERE EXISTS (SELECT  INSTR_ID 
                                      FROM    FT_T_ISCL ISCL
                                      WHERE   INDUS_CL_SET_ID = ''BBSECTYP''
                                      AND     CLSF_PURP_TYP  = ''INSUBTYP'' 
                                      AND     CL_VALUE = ''Mutual Fund''
                                      AND     DATA_SRC_ID=''BB''
                                      AND     MKIS.INSTR_ID=ISCL.INSTR_ID)
                                  AND     TRDNG_UT_MEAS_TYP=''SHARE''
                                  AND     LAST_CHG_USR_ID LIKE ''%BBEQEURO%''
                                  AND     END_TMS IS  NULL';
                                  
 EXECUTE IMMEDIATE  'ALTER TABLE FT_BAK_MKIS_129547
                     ADD PRIMARY KEY (MKT_ISS_OID)';
   
END;

DECLARE

v_NumErrors NUMBER;

CURSOR CUR_MKIS
IS  (SELECT MKT_ISS_OID
    FROM FT_t_MKIS MKIS
    WHERE EXISTS (SELECT  INSTR_ID 
              FROM    FT_t_ISCL ISCL
              WHERE   INDUS_CL_SET_ID = 'BBSECTYP'
              AND     CLSF_PURP_TYP  = 'INSUBTYP' 
              AND     CL_VALUE = 'Mutual Fund' 
              AND     DATA_SRC_ID='BB'
              AND      MKIS.INSTR_ID=ISCL.INSTR_ID)
    AND TRDNG_UT_MEAS_TYP='SHARE'
    AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
    AND END_TMS IS  NULL);
    
TYPE TYPE_MKIS  IS TABLE OF FT_t_MKIS.MKT_ISS_OID%TYPE;

 P_BULK_MKIS TYPE_MKIS;

BEGIN

OPEN CUR_MKIS;
    
 LOOP
     
        FETCH CUR_MKIS BULK COLLECT INTO P_BULK_MKIS  LIMIT 10000;
        
            FORALL  I IN 1..P_BULK_MKIS.COUNT SAVE EXCEPTIONS
            
                UPDATE  FT_T_MKIS
                SET     TRDNG_UT_MEAS_TYP='PIECE',
                        LAST_CHG_USR_ID='GS:MIG:BBEQEURO:129547' ,
                        LAST_CHG_TMS = SYSDATE
                WHERE   MKT_ISS_OID = P_BULK_MKIS(I);
                
        
        
        COMMIT;
        
        EXIT WHEN CUR_MKIS%NOTFOUND;
        
    END LOOP;
    
CLOSE CUR_MKIS;

EXCEPTION
               WHEN OTHERS THEN
                 DBMS_OUTPUT.PUT_LINE('Got exception: ' || SQLERRM);
                 v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
                 DBMS_OUTPUT.PUT_LINE(
                   'Number of errors during processing: ' || v_NumErrors);
                 FOR v_Count IN 1..v_NumErrors LOOP
                   DBMS_OUTPUT.PUT_LINE('Error ' || v_Count || ', iteration ' ||
                     SQL%BULK_EXCEPTIONS(v_Count).error_index || ' is: ' ||
                     SQLERRM(0 - SQL%BULK_EXCEPTIONS(v_Count).error_code));
                 END LOOP;
 


END;

INSERT INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20161121.sql', 1, 'GT129547',SYSDATE, '8.99.49.0', '8.99.56.0', 'A', SYSDATE);
 

SET DEFINE ON;
