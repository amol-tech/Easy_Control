-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:111712
-- | Date: 2014-11-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Bhuvanesh Mavatkar
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RISS
-- | Select Query Patch Name - GSDM_Bloomberg_DL_Global_Equity_20141119_841_SELECT.sql
-- | Change Reason: 1. To end date the duplicate entries present in RISS provided REL_TYP is CONV in RIDF table.
-- | 								2. To Remove the value of END_TMS if only single future ENDATED RISS segment is present against a single RIDF where RIDF.REL_TYP as CONV
-- |								3. In case of Multiple future ENDATED RISS segment is present against a single RIDF, then keep the latest records end_tms as Null and enddate the other records with timestamp
-- | 
-- |----------------------------------------------------------------


SET DEFINE OFF;

UPDATE   ft_T_riss
   SET   end_tms = NULL, last_chg_usr_id = 'GS:MIG:111712:BBEXTDPF'
 WHERE   riss_oid IN
               (SELECT   riss_oid
                  FROM   (SELECT   riss_oid,
                                   ROW_NUMBER ()
                                      OVER (
                                         PARTITION BY INSTR_ID,PART_UNITS_TYP,RLD_ISS_FEAT_ID,UDRLY_ASSET_ID_CTXT_TYP,UDRLY_ASSET_ISS_ID
                                         ORDER BY last_chg_tms DESC
                                      )
                                      cnt
                            FROM   ft_T_riss a
                           WHERE   end_tms > SYSDATE
                                   AND EXISTS
                                         (SELECT   'X'
                                            FROM   ft_T_ridf b
                                           WHERE   a.RLD_ISS_FEAT_ID =
                                                      b.RLD_ISS_FEAT_ID
                                                   AND b.REL_TYP = 'CONV')));

UPDATE   ft_T_riss
   SET   end_tms = SYSDATE, last_chg_usr_id = 'GS:MIG:111712:BBEXTDPF'
 WHERE   riss_oid IN
               (SELECT   riss_oid
                  FROM   (SELECT   riss_oid,
                                   ROW_NUMBER ()
                                      OVER (
                                         PARTITION BY INSTR_ID,PART_UNITS_TYP,RLD_ISS_FEAT_ID,UDRLY_ASSET_ID_CTXT_TYP,UDRLY_ASSET_ISS_ID
                                         ORDER BY last_chg_tms DESC
                                      )
                                      cnt
                            FROM   ft_T_riss a
                           WHERE   end_tms IS NULL
                                   AND EXISTS
                                         (SELECT   'X'
                                            FROM   ft_T_ridf b
                                           WHERE   a.RLD_ISS_FEAT_ID =
                                                      b.RLD_ISS_FEAT_ID
                                                   AND b.REL_TYP = 'CONV'))
                 WHERE   cnt != 1);


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20141119_841.sql', 1, 'GT111712', sysdate, '8.99.33.0', '8.99.34.0', 'A',  SYSDATE);


SET DEFINE ON;