SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #:156516
-- | Date: 2019-08-22
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Ashwini Desai
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason:Script to restore ISID data which has end-dated by GSDM_Bloomberg_DL_Global_Equity_20190830.sql script.
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20190830.sql
-- |----------------------------------------------------------------


DECLARE
   CURSOR CUR_ISID_UPD
   IS
      SELECT * FROM FT_BAK_ISID_GT156516;


   TYPE TYP_ISID_UPD IS TABLE OF CUR_ISID_UPD%ROWTYPE;

   VAR_ISID      TYP_ISID_UPD;

   V_NUMERRORS   NUMBER (10);
BEGIN
   OPEN CUR_ISID_UPD;

   LOOP
      FETCH CUR_ISID_UPD
         BULK COLLECT INTO VAR_ISID;

      FORALL I IN 1 .. VAR_ISID.COUNT SAVE EXCEPTIONS
         UPDATE /*+APPEND+*/
               FT_T_ISID
            SET END_TMS = NULL,
                LAST_CHG_USR_ID = VAR_ISID (I).LAST_CHG_USR_ID,
                LAST_CHG_TMS = VAR_ISID (I).LAST_CHG_TMS
          WHERE ISID_OID = VAR_ISID (I).ISID_OID;

      COMMIT;

      EXIT WHEN CUR_ISID_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS);

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || V_COUNT
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;