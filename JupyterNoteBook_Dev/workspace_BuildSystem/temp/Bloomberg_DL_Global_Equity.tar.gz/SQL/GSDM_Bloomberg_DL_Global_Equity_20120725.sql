-- |----------------------------------------------------------------
-- | Front Office #:435895
-- | GT Ticket #:80094
-- | Date: 2012-07-25
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Swapnali Jadhav	
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Migration script to transfer all values of EV_DESC to DAY_CNT_DESC.
-- |----------------------------------------------------------------

SET DEFINE OFF;

update FT_T_IEDF set DAY_CNT_DESC = EV_DESC ,LAST_CHG_USR_ID = 'GS:MIG:80094' where last_chg_usr_id='BBEXTDPF' and DAY_CNT_DESC is null;

SET DEFINE ON;