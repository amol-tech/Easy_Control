-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:
-- | Date: 2010-07-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Kaushik Raul	
-- | Approved By: Kakoti Chiranjib
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS,FT_T_ISSR
-- | Change Reason: 
-- | 
-- |----------------------------------------------------------------
SET DEFINE OFF;

UPDATE FT_T_MKIS M SET MULT_SHR_IND =  
(SELECT NVL(A.MULT_SHR_IND,C.MULT_SHR_IND) FROM FT_T_ISSR A,FT_T_ISSU B,FT_T_MKIS C WHERE A.INSTR_ISSR_ID = B.INSTR_ISSR_ID AND B.INSTR_ID = C.INSTR_ID AND C.MKT_ISS_OID = M.MKT_ISS_OID)
WHERE LAST_CHG_USR_ID='BBEQEURO';

UPDATE FT_T_ISSR SET MULT_SHR_IND=NULL WHERE LAST_CHG_USR_ID='BBEQEURO';

SET DEFINE ON;