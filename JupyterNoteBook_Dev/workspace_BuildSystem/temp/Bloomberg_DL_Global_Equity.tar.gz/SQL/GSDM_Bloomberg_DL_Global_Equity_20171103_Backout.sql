SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456382
-- | GT Ticket #:141093
-- | Date: 2017-10-27
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST
-- | Change Reason: Script to restore updated data in ISST where STAT_DEF_ID ='POSEURPR'
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171103.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISSTBAK
   IS
      SELECT   *
        FROM   FT_BAK_ISST_141093
       WHERE   STAT_ID IN (SELECT   STAT_ID
                             FROM   FT_T_ISST
                            WHERE   LAST_CHG_USR_ID LIKE '%141093%');
BEGIN
   FOR I IN CUR_ISSTBAK
   LOOP
      UPDATE   FT_T_ISST
         SET   DENOM_CURR_CDE = I.DENOM_CURR_CDE,
               LAST_CHG_TMS = I.LAST_CHG_TMS,
               LAST_CHG_USR_ID = I.LAST_CHG_USR_ID,
               END_TMS = I.END_TMS
       WHERE   STAT_ID = I.STAT_ID AND INSTR_ID = I.INSTR_ID;

      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLCODE || '- ' || SQLERRM);
END;