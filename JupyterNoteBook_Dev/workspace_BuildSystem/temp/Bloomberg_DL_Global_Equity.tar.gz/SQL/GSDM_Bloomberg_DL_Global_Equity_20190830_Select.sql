SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #:156516
-- | Date: 2019-08-22
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Ashwini Desai
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason:Script to fetch ISID records which have been set up with same instruments having same Market, ISS_USAGE_TYP.
-- | Update Query : GSDM_Bloomberg_DL_Global_Equity_20190830.sql
-- |----------------------------------------------------------------


SELECT /*+PARALLEL16*/
      *
  FROM (SELECT A.*,
               ROW_NUMBER ()
               OVER (
                  PARTITION BY NVL (MKT_OID, 'A'),
                               INSTR_ID,
                               NVL (ISS_USAGE_TYP, 'B')
                  ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_ISID A
         WHERE     ID_CTXT_TYP = 'BBCMPSEC'
               AND DATA_SRC_ID = 'BB'
               AND END_TMS IS NULL)
 WHERE CNT > 1;


 SET DEFINE ON;

