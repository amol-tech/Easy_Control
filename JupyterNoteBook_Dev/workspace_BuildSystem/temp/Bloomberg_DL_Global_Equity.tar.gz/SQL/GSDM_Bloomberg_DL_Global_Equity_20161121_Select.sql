SET DEFINE OFF;
--------------------------------------------------------------
-- | Frontoffice ID #:452378
-- | GT Ticket #: 129547
-- | Date: 21 November 2016
-- | Product ID: GS Securities
-- | Project ID: BBDLGlobalEquity
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- | Tables Affected:FT_T_MKIS
-- | Change Reason: Select script to view the records where field TRDNG_UT_MEAS_TYP would be updated to PIECE for the existing rows where the field TRDNG_UT_MEAS_TYP is 'SHARE'
-- | and record exists in ft_T_iscl table with same instr_id as that of ft_t_mkis where field INDUS_CL_SET_ID is 'BBSECTYP' and CLSF_PURP_TYP is 'INSUBTYP' and CL_VALUE is 'Mutual Fund'
-- | Query Patch Name:GSDM_Bloomberg_DL_Global_Equity_20161121.sql
----------------------------------------------------------------

SELECT * 
FROM FT_T_MKIS MKIS
WHERE EXISTS (SELECT  INSTR_ID 
              FROM    FT_T_ISCL ISCL
              WHERE   INDUS_CL_SET_ID = 'BBSECTYP'
              AND     CLSF_PURP_TYP  = 'INSUBTYP' 
              AND     CL_VALUE = 'Mutual Fund' 
              AND     DATA_SRC_ID='BB'
              AND      MKIS.INSTR_ID=ISCL.INSTR_ID)
AND TRDNG_UT_MEAS_TYP='SHARE'
AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
AND END_TMS IS  NULL;

SET DEFINE ON;