SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #:141102
-- | Date: 2017-10-26
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RGCH
-- | Change Reason: Script to identify duplicate RGCH based on INSTR_ID and retain the oldest RGCH. Also nullify GUID, GUTYP, GUCNT columns of the oldest RGCH.
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171026_Select.sql
-- |----------------------------------------------------------------

-- |NOTE :- Migration script is applicable only when the CCO RecordRegInfoForGeoRegion is set to NO.

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_RGCH_141102
AS
   SELECT   *
     FROM   FT_T_RGCH A
    WHERE   END_TMS IS NULL';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_BAK_RGCH_141102 ADD CONSTRAINT RGCH_BAK_141102_PK PRIMARY KEY(RGCH_OID)';
END;

DECLARE
   CURSOR CUR_RGCH
   IS
      SELECT   *
        FROM   (SELECT   A.RGCH_OID,
                         A.START_TMS,
                         A.INSTR_ID,
                         A.LAST_CHG_USR_ID,
                         ROW_NUMBER ()
                            OVER (PARTITION BY INSTR_ID
                                  ORDER BY START_TMS ASC, RGCH_OID ASC)
                            AS CNT
                  FROM   FT_T_RGCH A
                 WHERE       END_TMS IS NULL
                         AND INSTR_ID IN (  SELECT   INSTR_ID
                                              FROM   FT_T_RGCH
                                             WHERE   END_TMS IS NULL
                                          GROUP BY   INSTR_ID
                                            HAVING   COUNT (1) > 1))
       WHERE   CNT = 1;



   VAR_CUR_RGCH   CUR_RGCH%ROWTYPE;

   CURSOR CUR_RGCH_PARAM (
      INSTR_ID_VAR                 VARCHAR2
   )
   IS
      SELECT   *
        FROM   (SELECT   A.RGCH_OID,
                         A.START_TMS,
                         ROW_NUMBER ()
                            OVER (PARTITION BY INSTR_ID
                                  ORDER BY START_TMS ASC, RGCH_OID ASC)
                            AS CNT
                  FROM   FT_T_RGCH A
                 WHERE   END_TMS IS NULL AND INSTR_ID = INSTR_ID_VAR)
       WHERE   CNT > 1;



   CURSOR CUR_COLLIST
   IS
      SELECT   COL_NME
        FROM   FT_T_CLDF
       WHERE   TBL_ID = 'RGCH'
               AND COL_NME NOT IN
                        ('DATA_SRC_ID',
                         'DATA_STAT_TYP',
                         'END_TMS',
                         'GU_CNT',
                         'GU_ID',
                         'GU_TYP',
                         'INSTR_ID',
                         'LAST_CHG_TMS',
                         'LAST_CHG_USR_ID',
                         'RGCH_OID',
                         'RGAT_OID',
                         'START_TMS');

   VAR_STMNT      CLOB;
   VAR_CONDN      VARCHAR2 (2000);
   VAR_QUERY      CLOB;
   VAR_SEL        CLOB;
   V_NUMERRORS    NUMBER (10);
BEGIN
   --DBMS_OUTPUT.PUT_LINE (VAR_CONDN);


   FOR VAR_CUR_COLLIST IN CUR_COLLIST
   LOOP
      VAR_STMNT := VAR_STMNT || VAR_CUR_COLLIST.COL_NME || ',';
      VAR_SEL :=
            VAR_SEL
         || ' NVL ( RGCHOUT.'
         || VAR_CUR_COLLIST.COL_NME
         || ', RGCHIN.'
         || VAR_CUR_COLLIST.COL_NME
         || '),';
   END LOOP;

   VAR_STMNT := RTRIM (VAR_STMNT, ',') || ')';
   VAR_SEL := RTRIM (VAR_SEL, ',');



   FOR VAR_CUR_RGCH IN CUR_RGCH
   LOOP
      FOR VAR_CUR_RGCH_PARAM IN CUR_RGCH_PARAM (VAR_CUR_RGCH.INSTR_ID)
      LOOP
         UPDATE   FT_T_RGCH
            SET   START_TMS =
                     CASE
                        WHEN VAR_CUR_RGCH_PARAM.START_TMS =
                                VAR_CUR_RGCH.START_TMS
                        THEN
                           START_TMS
                           - VAR_CUR_RGCH_PARAM.CNT / (24 * 60 * 60)
                        ELSE
                           START_TMS
                     END,
                  END_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:MIG:141102:' || LAST_CHG_USR_ID,
                  LAST_CHG_TMS = SYSDATE
          WHERE   RGCH_OID = VAR_CUR_RGCH_PARAM.RGCH_OID;

          COMMIT;

         VAR_CONDN :=
            ' GU_ID = NULL , GU_TYP = NULL , GU_CNT = NULL ,  LAST_CHG_TMS = SYSDATE , START_TMS = START_TMS + 1, LAST_CHG_USR_ID = ''GS:MIG:141102:'
            || VAR_CUR_RGCH.LAST_CHG_USR_ID
            || ''' WHERE RGCH_OID = '''
            || VAR_CUR_RGCH.RGCH_OID
            || '''';


         VAR_QUERY :=
               'UPDATE /*+ PARALLEL(16) */ FT_T_RGCH RGCHOUT SET ('
            || VAR_STMNT
            || '= (SELECT '
            || VAR_SEL
            || ' FROM FT_T_RGCH RGCHIN WHERE RGCH_OID = '''
            || VAR_CUR_RGCH_PARAM.RGCH_OID
            || '''),'
            || VAR_CONDN;



       --  DBMS_OUTPUT.PUT_LINE (VAR_QUERY);

         EXECUTE IMMEDIATE VAR_QUERY;

         COMMIT;
      END LOOP;

      UPDATE   FT_T_RGCH
         SET   START_TMS = VAR_CUR_RGCH.START_TMS
       WHERE   RGCH_OID = VAR_CUR_RGCH.RGCH_OID;

      COMMIT;
   END LOOP;

   FOR I IN (SELECT   RGCH_OID
               FROM   FT_T_RGCH
              WHERE       INSTR_ID IN (  SELECT   INSTR_ID
                                           FROM   FT_T_RGCH
                                          WHERE   END_TMS IS NULL
                                       GROUP BY   INSTR_ID
                                         HAVING   COUNT (1) = 1)
                      AND END_TMS IS NULL
                      AND GU_ID IS NOT NULL)
   LOOP
      UPDATE   FT_T_RGCH
         SET   GU_ID = NULL,
               GU_TYP = NULL,
               GU_CNT = NULL,
               LAST_CHG_TMS = SYSDATE,
               LAST_CHG_USR_ID = 'GS:MIG:141102:' || LAST_CHG_USR_ID
       WHERE   RGCH_OID = I.RGCH_OID;

      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('SQLCODE : ' || SQLCODE||' SQL ERROR MESSAGE : '||SQLERRM);
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   ('GSDM_Bloomberg_DL_Global_Equity_20171026.sql',
            1,
            'GT141102',
            SYSDATE,
            '8.99.56.0',
            '8.99.70.0',
            'A',
            SYSDATE);

COMMIT;

SET DEFINE ON;