-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT #: 101399
-- | Date: 2014-02-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Swapnali Jadhav
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: IEDF,IEVP,IPDF
-- |
-- | Change Reason: Below SELECT queries will fetch the corresponding IPDF/IEVP/IEDF records which are getting deleted/enddated by migration script for following reasons:
-- |                 1. To delete the IPDF records that were created due to duplicate IEDF records, (the duplicate IEDFs were set up due to START_TMS being a future date (at the time of setting up the row) for same insturment and EV_TYP="INTEREST" or "DIVIDEND")
-- |                 2. To End date IEVP records that were created due to duplicate IEDF records, (the duplicate IEDFs were set up due to START_TMS being a future date (at the time of setting up the row) for same insturment and EV_TYP="INTEREST" or "DIVIDEND")
-- |                 3. To end date duplicate IEDF records that were created on the basis of START_TMS (future date at the time of setting up) for same insturment and EV_TYP="INTEREST" or "DIVIDEND"
-- |                 4. To update the START_TMS of active IEDF with sysdate if START_TMS is greater than sysdate and EV_TYP="INTEREST" or "DIVIDEND" to ensure no duplicates of IEDF occur in the future.
-- | SQL Patch: GSDM_Bloomberg_DL_Global_Equity_20140205.sql
-- |----------------------------------------------------------------

set define off;

---=====================================================INTEREST===========================================================

---To update the IPDF's of duplicated IEDF's


select *  from
ft_T_ipdf e   where INC_EV_PRT_ID in (select INC_EV_PRT_ID from FT_T_ievp where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1)
and end_tms is null);


---To update the IEVP's of duplicated IEDF's

select * from ft_t_ievp  where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1)
and end_tms is null;

---To end date the duplicate IEDF records present on the basis of EV_TYP='INTEREST' and INSTR_ID

select * from fT_T_iedf b  where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1);

---To update the end dated IEDF's which might cause Uniqness Constraint failuer as we are going to update start_tms of active IEDF's with the truncated sys date. 

select * from fT_T_iedf a 
where (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id and ev_typ='INTEREST') >1
and end_tms is not null and start_tms=(select trunc(sysdate,'DDD') from fT_T_iedf c where a.instr_id=c.instr_id and a.ev_typ=c.ev_typ and end_tms is null and start_tms > sysdate and ev_typ='INTEREST')
and ev_typ='INTEREST';

--To Update start tms of active IEDF's with the truncated sys date amongst the duplicate IEDF's

select * from ft_T_iedf a 
where ev_typ='INTEREST'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) >1 
and end_tms is null
and sysdate <= start_tms;

--To Update start tms of active IEDF's with the truncated sys date of standalone IEDF's

select * from ft_T_iedf a
where ev_typ='INTEREST'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) =1
and end_tms is null
and sysdate <= start_tms;


---=====================================================DIVIDEND===========================================================

---To update the IPDF's of duplicated IEDF's


select *  from
ft_T_ipdf e   where INC_EV_PRT_ID in (select INC_EV_PRT_ID from FT_T_ievp where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1)
and end_tms is null);


---To update the IEVP's of duplicated IEDF's

select * from ft_t_ievp  where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1)
and end_tms is null;

---To end date the duplicate IEDF records present on the basis of EV_TYP='DIVIDEND' and INSTR_ID

select * from fT_T_iedf b  where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1);

---To update the end dated IEDF's which might cause Uniqness Constraint failuer as we are going to update start_tms of active IEDF's with the truncated sys date. 

select * from fT_T_iedf a 
where (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id and ev_typ='DIVIDEND') >1
and end_tms is not null and start_tms=(select trunc(sysdate,'DDD') from fT_T_iedf c where a.instr_id=c.instr_id and a.ev_typ=c.ev_typ and end_tms is null  and start_tms > sysdate and ev_typ='DIVIDEND')
and ev_typ='DIVIDEND';

--To Update start tms of active IEDF's with the truncated sys date amongst the duplicate IEDF's

select * from ft_T_iedf a 
where ev_typ='DIVIDEND'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) >1 
and end_tms is null
and sysdate <= start_tms;

--To Update start tms of active IEDF's with the truncated sys date of standalone IEDF's

select * from ft_T_iedf a
where ev_typ='DIVIDEND'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) =1
and end_tms is null
and sysdate <= start_tms;

set define on;