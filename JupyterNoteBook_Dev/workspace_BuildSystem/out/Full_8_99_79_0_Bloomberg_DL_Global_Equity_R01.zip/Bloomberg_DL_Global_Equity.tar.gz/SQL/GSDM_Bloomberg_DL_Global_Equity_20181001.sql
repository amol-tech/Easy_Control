
SET DEFINE OFF;
-- |--------------------------------------------------------------------------------------------------------------------------------------------------------
-- | Front Office #: 460548
-- | GT Ticket #:149810
-- | Date: 2018-09-07
-- |---------------------------------------------------------------------------------------------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------------------------------------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Script to Update GLOBAL_UNIQ_IND=S of ISID rows which is set up with GLOBAL_UNIQ_IND=G for ID_CTXT_TYP='WI-TRDGSYSID' , 'TRDGSYSID'
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20181001_Select.sql
-- |-----------------------------------------------------------------------------------------------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_T_ISID_BKP_GT149810
AS SELECT *
  FROM FT_T_ISID
 WHERE     ID_CTXT_TYP IN (''TRDGSYSID'',''WI-TRDGSYSID'')
       AND GLOBAL_UNIQ_IND=''G''
       AND REGEXP_LIKE (LAST_CHG_USR_ID,
                        ''BBEQEURO|BBNONEQLISOP|BBEQLISFUT|BBEQLISOP'')
       AND END_TMS IS NULL';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_ISID_BKP_GT149810 ADD CONSTRAINT FT_T_ISID_BKP_GT149810_PK PRIMARY KEY(ISID_OID)';
END;


DECLARE
   v_NumErrors   NUMBER (10);

   CURSOR CUR_ISID
   IS
      SELECT * FROM FT_T_ISID_BKP_GT149810;

   TYPE TAB_ISID IS TABLE OF CUR_ISID%ROWTYPE;

   VAR_TAB       TAB_ISID;
BEGIN
   OPEN CUR_ISID;

   LOOP
      FETCH CUR_ISID
         BULK COLLECT INTO VAR_TAB
         LIMIT 1000;

      FORALL I IN 1 .. VAR_TAB.COUNT () SAVE EXCEPTIONS
         UPDATE FT_T_ISID
            SET GLOBAL_UNIQ_IND = 'S',
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:CON:149810:' || LAST_CHG_USR_ID
          WHERE ISID_OID = VAR_TAB (I).ISID_OID;

      COMMIT;

      EXIT WHEN CUR_ISID%NOTFOUND;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || ' and Message ' || SQLERRM);
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20181001.sql',
             1,
             'GT149810',
             SYSDATE,
             '8.99.72.0',
             '8.99.73.0',
             'A',
             SYSDATE);

COMMIT;


SET DEFINE ON;