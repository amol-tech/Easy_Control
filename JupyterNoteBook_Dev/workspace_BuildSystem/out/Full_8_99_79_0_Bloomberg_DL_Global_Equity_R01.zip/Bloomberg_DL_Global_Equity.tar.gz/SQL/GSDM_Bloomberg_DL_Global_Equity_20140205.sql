-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT #: 101399
-- | Date: 2014-02-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Swapnali Jadhav
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: IEDF,IEVP,IPDF
-- | Change Reason:  Migration script provided for following reasons:
-- |                 1. To delete the IPDF records that were created due to duplicate IEDF records, (the duplicate IEDFs were set up due to START_TMS being a future date (at the time of setting up the row) for same insturment and EV_TYP="INTEREST" or "DIVIDEND")
-- |                 2. To End date IEVP records that were created due to duplicate IEDF records, (the duplicate IEDFs were set up due to START_TMS being a future date (at the time of setting up the row) for same insturment and EV_TYP="INTEREST" or "DIVIDEND")
-- |                 3. To end date duplicate IEDF records that were created on the basis of START_TMS (future date at the time of setting up) for same insturment and EV_TYP="INTEREST" or "DIVIDEND"
-- |                 4. To update the START_TMS of active IEDF with sysdate if START_TMS is greater than sysdate and EV_TYP="INTEREST" or "DIVIDEND" to ensure no duplicates of IEDF occur in the future.
-- | Select Patch: GSDM_Bloomberg_DL_Global_Equity_20140205_SELECT.sql
-- |----------------------------------------------------------------

set define off;
---===================================================INTEREST=========================================================================
---To update the IPDF's of duplicated IEDF's

insert into ft_bak_ipdf
select e.*, 1,'dup IPDF BB:101399' || SYSDATE reason  from
ft_T_ipdf e   where INC_EV_PRT_ID in (select INC_EV_PRT_ID from FT_T_ievp where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1)
and end_tms is null);

delete from ft_t_ipdf where INC_PAY_DEF_ID  in (select INC_PAY_DEF_ID  from ft_bak_ipdf);

---To update the IEVP's of duplicated IEDF's

update ft_t_ievp set end_tms=sysdate,last_chg_usr_id='GS101399:BBEXTDPF' where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1)
and end_tms is null;

---To end date the duplicate IEDF records present on the basis of EV_TYP='INTEREST' and INSTR_ID

update fT_T_iedf b set end_tms=sysdate,last_chg_usr_id='GS101399:BBEXTDPF' where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='INTEREST' ) where cnt !=1);

---To update the end dated IEDF's which might cause Uniqness Constraint failuer as we are going to update start_tms of active IEDF's with the truncated last_chg_tms. 

update fT_T_iedf a set start_tms=(select min(start_tms)-1 from fT_t_iedf d where a.ev_typ=d.ev_typ and a.instr_id=d.instr_id and ev_typ='INTEREST'),last_chg_usr_id='GS101399:BBEXTDPF'
where (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id and ev_typ='INTEREST') >1
and end_tms is not null and start_tms=(select trunc(sysdate,'DDD') from fT_T_iedf c where a.instr_id=c.instr_id and a.ev_typ=c.ev_typ and end_tms is null  and start_tms > sysdate and ev_typ='INTEREST')
and ev_typ='INTEREST';

--To Update start tms of active IEDF's with the truncated last change tms amongst the duplicate IEDF's

update ft_T_iedf a set start_tms=trunc(sysdate,'DDD'),last_chg_usr_id='GS101399:BBEXTDPF' 
where ev_typ='INTEREST'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) >1 
and end_tms is null
and sysdate <= start_tms;

--To Update start tms of active IEDF's with the truncated last change tms of standalone IEDF's

update ft_T_iedf a set start_tms=trunc(sysdate,'DDD'),last_chg_usr_id='GS101399:BBEXTDPF' 
where ev_typ='INTEREST'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) =1
and end_tms is null
and sysdate <= start_tms;

---===========================================================DIVIDEND===========================================

---To update the IPDF's of duplicated IEDF's

insert into ft_bak_ipdf
select e.*, 1,'dup IPDF BB:101399' || SYSDATE reason  from
ft_T_ipdf e   where INC_EV_PRT_ID in (select INC_EV_PRT_ID from FT_T_ievp where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1)
and end_tms is null);

delete from ft_t_ipdf where INC_PAY_DEF_ID  in (select INC_PAY_DEF_ID  from ft_bak_ipdf);

---To update the IEVP's of duplicated IEDF's

update ft_t_ievp set end_tms=sysdate,last_chg_usr_id='GS101399:BBEXTDPF' where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1)
and end_tms is null;


---To end date the duplicate IEDF records present on the basis of EV_TYP='DIVIDEND' and INSTR_ID

update fT_T_iedf b set end_tms=sysdate,last_chg_usr_id='GS101399:BBEXTDPF' where INC_EV_DEF_ID in         
(SELECT INC_EV_DEF_ID FROM (SELECT INC_EV_DEF_ID,EV_TYP,START_TMS,INSTR_ID ,row_number()                     
over(partition by EV_TYP,INSTR_ID ORDER BY LAST_CHG_TMS desc) cnt           
FROM fT_T_iedf where end_tms is  null and EV_TYP ='DIVIDEND' ) where cnt !=1);

---To update the end dated IEDF's which might cause Uniqness Constraint failuer as we are going to update start_tms of active IEDF's with the truncated last_chg_tms. 

update fT_T_iedf a set start_tms=(select min(start_tms)-1 from fT_t_iedf d where a.ev_typ=d.ev_typ and a.instr_id=d.instr_id and ev_typ='DIVIDEND'),last_chg_usr_id='GS101399:BBEXTDPF'
where (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id and ev_typ='DIVIDEND') >1
and end_tms is not null and start_tms=(select trunc(sysdate,'DDD') from fT_T_iedf c where a.instr_id=c.instr_id and a.ev_typ=c.ev_typ and end_tms is null  and start_tms > sysdate and ev_typ='DIVIDEND')
and ev_typ='DIVIDEND';

--To Update start tms of active IEDF's with the truncated last change tms amongst the duplicate IEDF's

update ft_T_iedf a set start_tms=trunc(sysdate,'DDD'),last_chg_usr_id='GS101399:BBEXTDPF' 
where ev_typ='DIVIDEND'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) >1 
and end_tms is null
and sysdate <= start_tms;

--To Update start tms of active IEDF's with the truncated last change tms of standalone IEDF's

update ft_T_iedf a set start_tms=trunc(sysdate,'DDD'),last_chg_usr_id='GS101399:BBEXTDPF' 
where ev_typ='DIVIDEND'
and (select count(*) from fT_t_iedf b where a.ev_typ=b.ev_typ and a.instr_id=b.instr_id) =1
and end_tms is null
and sysdate <= start_tms;

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20140205.sql', 1, 'GT101399', sysdate, '8.99.0.1', '8.99.23.0', 'A',  SYSDATE);

set define on;