SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 462828
-- | GT Ticket #: 155136 
-- | Date: 2019-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Nusrat Khan
-- | Approved By: Adil Shaikh
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: Script to revert back changes made in Update Script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190410.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISID_UPD
   IS
      SELECT * FROM FT_BAK_ISID_GT155136;


   TYPE TYP_ISID_UPD IS TABLE OF CUR_ISID_UPD%ROWTYPE;

   VAR_ISID      TYP_ISID_UPD;

   V_NUMERRORS   NUMBER (10);

   L_LIMIT       NUMBER := 1000;
   
BEGIN
   OPEN CUR_ISID_UPD;

   LOOP
      FETCH CUR_ISID_UPD
         BULK COLLECT INTO VAR_ISID
         LIMIT L_LIMIT;

      FORALL I IN 1 .. VAR_ISID.COUNT SAVE EXCEPTIONS
         UPDATE /*+ APPEND +*/
               FT_T_ISID
            SET END_TMS = NULL,
                LAST_CHG_USR_ID = VAR_ISID (I).LAST_CHG_USR_ID,
                LAST_CHG_TMS = VAR_ISID (I).LAST_CHG_TMS
          WHERE ISID_OID = VAR_ISID (I).ISID_OID;

      COMMIT;

      EXIT WHEN CUR_ISID_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS);

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || V_COUNT
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;