-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT #: 87317
-- | Date: 2012-01-21
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Swapnali Jadhav
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: IEDF
-- |
-- | Change Reason: Migration script to change IEDF.days_mth_bas_typ as per respective IEDF.day_cnt_desc .
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'IEM' where day_cnt_desc = 'ISMA-30/ACT' and last_chg_usr_id like '%BBEXTDPF%';

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'IEM' where day_cnt_desc = 'ISMA-30/360' and last_chg_usr_id like '%BBEXTDPF%';

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'IEM' where day_cnt_desc = 'ISMA-30/365' and last_chg_usr_id like '%BBEXTDPF%';

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'I30' where day_cnt_desc = 'ISMA30/ACT NON-EOM' and last_chg_usr_id like '%BBEXTDPF%';

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'I30' where day_cnt_desc = 'ISMA-30/360 NONEOM' and last_chg_usr_id like '%BBEXTDPF%';

update ft_T_IEDF set last_chg_usr_id='GS:MIG:87317:BBEXTDPF', days_mth_bas_typ = 'I30' where day_cnt_desc = 'ISMA30/365 NON-EOM' and last_chg_usr_id like '%BBEXTDPF%';


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130121.sql', 1, 'GT#87317', TO_DATE( '07/25/2010 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.0.43', 'A',  SYSDATE);


SET DEFINE ON;
