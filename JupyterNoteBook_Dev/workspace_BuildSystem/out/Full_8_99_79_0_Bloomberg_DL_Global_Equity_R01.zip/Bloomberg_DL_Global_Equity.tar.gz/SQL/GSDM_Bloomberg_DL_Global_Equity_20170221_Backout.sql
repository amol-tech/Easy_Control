SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 453367
-- | GT Ticket #: 133077
-- | Date: 2017-01-24
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Script to restore the updated records in IEDF 
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170221_Select.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_BAK_IEDF
   IS
      SELECT   * FROM FT_BAK_IEDF_GT133077;

   TYPE TAB_BAK_IEDF IS TABLE OF CUR_BAK_IEDF%ROWTYPE;

   VAR_BAK_IEDF   TAB_BAK_IEDF;
   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_BAK_IEDF;

   LOOP
      FETCH CUR_BAK_IEDF BULK COLLECT INTO   VAR_BAK_IEDF LIMIT 10000;

      FORALL I IN 1 .. VAR_BAK_IEDF.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_IEDF
            SET   RTFX_BAS_TXT = VAR_BAK_IEDF (I).RTFX_BAS_TXT,
                  RTFX_BAS_TYP = VAR_BAK_IEDF (I).RTFX_BAS_TYP,
                  LAST_CHG_USR_ID = VAR_BAK_IEDF (I).LAST_CHG_USR_ID,
                  LAST_CHG_TMS = VAR_BAK_IEDF (I).LAST_CHG_TMS
          WHERE   INC_EV_DEF_ID = VAR_BAK_IEDF (I).INC_EV_DEF_ID;

      COMMIT;

      EXIT WHEN CUR_BAK_IEDF%NOTFOUND;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS
      );

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || V_COUNT
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
      END LOOP;
END;