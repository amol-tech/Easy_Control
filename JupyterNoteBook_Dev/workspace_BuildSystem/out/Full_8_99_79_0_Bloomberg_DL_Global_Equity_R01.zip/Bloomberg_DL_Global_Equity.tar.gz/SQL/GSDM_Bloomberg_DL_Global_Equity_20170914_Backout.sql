-- |----------------------------------------------------------------
-- | Front Office #:456025
-- | GT Ticket #:139574
-- | Date: 2017-09-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Reason: Script to revert changes made by GSDM_Bloomberg_DL_Global_Equity_20170914.sql script
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170914.sql
-- |----------------------------------------------------------------
SET DEFINE OFF;

DECLARE
   v_NumErrors    NUMBER (10);

   CURSOR CUR_ISID_BAK
   IS
      SELECT   * FROM FT_T_ISID_BKP_139574
      UNION
      SELECT   * FROM FT_T_ISID_DUP_BKP_139574;


   TYPE TAB_ISID_BAK IS TABLE OF CUR_ISID_BAK%ROWTYPE;

   VAR_ISID_BAK   TAB_ISID_BAK;
BEGIN
   OPEN CUR_ISID_BAK;

   LOOP
      FETCH CUR_ISID_BAK BULK COLLECT INTO   VAR_ISID_BAK LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_BAK.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_ISID
            SET   MKT_OID = VAR_ISID_BAK (I).MKT_OID,
                  LAST_CHG_USR_ID = VAR_ISID_BAK (I).LAST_CHG_USR_ID,
                  LAST_CHG_TMS = VAR_ISID_BAK (I).LAST_CHG_TMS
          WHERE   ISID_OID = VAR_ISID_BAK (I).ISID_OID;
          
      COMMIT;

      EXIT WHEN CUR_ISID_BAK%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_BAK;
   
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors
      );

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || v_Count
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(v_Count).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(v_Count).ERROR_CODE));
      END LOOP;
END;
/