-- |----------------------------------------------------------------
-- | Front Office #:439291
-- | GT Ticket #: 92352
-- | Date: 2013-06-12
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Yash Somaiya
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected : FT_CFG_VRET
-- | Change Reason: Require support to request BB data for newly added SECURITY_TYP
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

INSERT INTO ft_cfg_vret   (VND_RQST_TYP, EXT_ISS_TYP_TXT)  SELECT 'Equity','MLP'    FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ft_cfg_vret WHERE VND_RQST_TYP = 'Equity' and EXT_ISS_TYP_TXT='MLP' );

SET DEFINE ON;