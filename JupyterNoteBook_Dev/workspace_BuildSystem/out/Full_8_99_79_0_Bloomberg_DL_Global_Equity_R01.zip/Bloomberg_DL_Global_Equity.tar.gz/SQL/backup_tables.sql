set define off;


-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rajath Shetty
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: Back up Tables
-- | Change Reason: Script to create a backup of following table to restoring the data.
-- |----------------------------------------------------------------

set define off;



create table ft_bak_pevp as Select * from ft_t_pevp a where 1 = 2;
alter table ft_bak_pevp add REASON varchar2 (100);



create table ft_bak_ppdf as Select * from ft_t_ppdf a where 1 = 2;
alter table ft_bak_ppdf add REASON varchar2 (100);



create table ft_bak_isll as Select * from ft_t_isll a where 1 = 2;
alter table ft_bak_isll add REASON varchar2 (100);

set define on;