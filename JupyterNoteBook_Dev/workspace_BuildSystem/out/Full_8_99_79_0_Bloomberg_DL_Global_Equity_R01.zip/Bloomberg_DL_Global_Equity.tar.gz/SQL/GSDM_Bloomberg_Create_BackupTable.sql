-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Sanjiv Arjunagi
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: Back up Tables
-- | Change Reason: Script to create a backup of following tables to restoring the data.
-- |----------------------------------------------------------------

set define off;

create table ft_bak_eqst as Select * from ft_t_eqst a where 1 = 2;
alter table ft_bak_eqst add REASON varchar2 (100);

create table ft_bak_ipdf as Select a.*,1 cnt from ft_t_ipdf a where 1 = 2;
alter table ft_bak_ipdf add REASON varchar2 (100);

create table ft_bak_isll as Select * from ft_t_isll a where 1 = 2;
alter table ft_bak_isll add REASON varchar2 (100);

create table ft_bak_ppdf as Select a.*,1 cnt from ft_t_ppdf a where 1 = 2;
alter table ft_bak_ppdf add REASON varchar2 (100); --GT127316

set define on;