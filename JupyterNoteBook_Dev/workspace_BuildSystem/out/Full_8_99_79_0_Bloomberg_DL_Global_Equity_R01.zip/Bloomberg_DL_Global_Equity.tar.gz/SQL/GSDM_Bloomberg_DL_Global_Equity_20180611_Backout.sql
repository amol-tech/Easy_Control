SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | FrontOffice ID: 459860
-- | GT Ticket #: 148243
-- | Date: 2018-06-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Renita Raphael
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISGU,FT_T_IRGU,FT_T_FIGU
-- | Change Reason: Script to rollback the changes made by script GSDM_Bloomberg_DL_Global_Equity_20180629.sql
-- | Backout Query Patch: GSDM_Bloomberg_DL_Global_Equity_20180611_Backout.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISGU
   IS
      SELECT   * FROM FT_T_ISGU_BKP_148243;

   CURSOR CUR_IRGU
   IS
      SELECT   * FROM FT_T_IRGU_BKP_148243;
      
   CURSOR CUR_FIGU
   IS
      SELECT   * FROM FT_T_FIGU_BKP_148243;

   
BEGIN
   FOR I IN CUR_ISGU
   LOOP
      UPDATE   FT_T_ISGU
         SET   GU_TYP = I.GU_TYP,
               END_TMS = I.END_TMS,
               LAST_CHG_TMS = I.LAST_CHG_TMS,
               LAST_CHG_USR_ID = I.LAST_CHG_USR_ID
       WHERE   ISGU_OID = I.ISGU_OID;

      COMMIT;
   END LOOP;

   FOR I IN CUR_IRGU
   LOOP
      UPDATE   FT_T_IRGU
         SET   GU_TYP = I.GU_TYP,
               END_TMS = I.END_TMS,
               LAST_CHG_TMS = I.LAST_CHG_TMS,
               LAST_CHG_USR_ID = I.LAST_CHG_USR_ID
       WHERE   IRGU_OID = I.IRGU_OID;

      COMMIT;
   END LOOP;
   
    FOR I IN CUR_FIGU
   LOOP
      UPDATE   FT_T_FIGU
         SET   GU_TYP = I.GU_TYP,
               END_TMS = I.END_TMS,
               LAST_CHG_TMS = I.LAST_CHG_TMS,
               LAST_CHG_USR_ID = I.LAST_CHG_USR_ID
       WHERE   FIGU_OID = I.FIGU_OID;

      COMMIT;
   END LOOP;

EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || ' and Message ' || SQLERRM
      );
END;

SET DEFINE ON;