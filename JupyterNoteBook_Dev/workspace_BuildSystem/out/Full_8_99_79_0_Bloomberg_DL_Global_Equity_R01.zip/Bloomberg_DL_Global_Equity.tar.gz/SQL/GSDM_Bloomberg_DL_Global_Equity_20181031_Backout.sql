SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462342
-- | GT Ticket #:151805
-- | Date: 2018-10-31
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS
-- | Change Reason: Script to revert back changes made in Update Script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181031.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_MKIS_BKP
   IS
      SELECT * FROM FT_BAK_MKIS_GT151805;

   TYPE TYP_MKIS_BKP IS TABLE OF CUR_MKIS_BKP%ROWTYPE;

   VAR_MKIS_BKP   TYP_MKIS_BKP;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_MKIS_BKP;

   LOOP
      FETCH CUR_MKIS_BKP
         BULK COLLECT INTO VAR_MKIS_BKP
         LIMIT 10000;

      FORALL I IN 1 .. VAR_MKIS_BKP.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_MKIS
            SET PRC_UT_MEAS_TYP = VAR_MKIS_BKP (I).PRC_UT_MEAS_TYP,
                LAST_CHG_TMS = VAR_MKIS_BKP (I).LAST_CHG_TMS,
                LAST_CHG_USR_ID = VAR_MKIS_BKP (I).LAST_CHG_USR_ID
          WHERE MKT_ISS_OID = VAR_MKIS_BKP (I).MKT_ISS_OID;

      COMMIT;

      EXIT WHEN CUR_MKIS_BKP%NOTFOUND;
   END LOOP;

   CLOSE CUR_MKIS_BKP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;