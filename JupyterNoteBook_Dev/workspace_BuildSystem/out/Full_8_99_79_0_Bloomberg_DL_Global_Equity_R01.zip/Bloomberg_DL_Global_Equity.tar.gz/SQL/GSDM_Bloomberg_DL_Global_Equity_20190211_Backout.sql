SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 463543
-- | GT Ticket #: 153620 
-- | Date: 2019-02-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Connections
-- | Requested By: Nusrat Khan
-- | Approved By: Neha Chaturvedi
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: Script to revert back changes made in Update Script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190211_Backout.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISID_UPD
   IS
      SELECT * FROM FT_T_ISID_BAK_153620;

   TYPE TYP_ISID_UPD IS TABLE OF CUR_ISID_UPD%ROWTYPE;

   VAR_ISID_UPD   TYP_ISID_UPD;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISID_UPD;

   LOOP
      FETCH CUR_ISID_UPD
         BULK COLLECT INTO VAR_ISID_UPD
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_UPD.COUNT SAVE EXCEPTIONS
		UPDATE FT_T_ISID
		SET  MERGE_UNIQ_OID = NULL,
			 LAST_CHG_USR_ID = VAR_ISID_UPD (I).LAST_CHG_USR_ID,
			 LAST_CHG_TMS = VAR_ISID_UPD (I).LAST_CHG_TMS
			WHERE    ISID_OID = VAR_ISID_UPD (I).ISID_OID;
			
      COMMIT;

      EXIT WHEN CUR_ISID_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_UPD;
   
   
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;
