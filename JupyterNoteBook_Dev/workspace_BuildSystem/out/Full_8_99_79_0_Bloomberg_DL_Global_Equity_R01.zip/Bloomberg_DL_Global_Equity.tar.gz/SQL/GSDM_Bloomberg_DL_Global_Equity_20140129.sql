-- |----------------------------------------------------------------
-- | Front Office #:439312
-- | GT Ticket #:99365
-- | Date: 2014-01-29
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Keval Savla
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_RIDF,FT_T_RISS,FT_T_RIXR
-- | Select Query Patch : GSDM_Bloomberg_DL_Global_Equity_20140129_SELECT.sql
-- | Change Reason: Migration script provided to endate the duplicate RIDF rows present with with REL_TYP= 'CONV' and 'WARRANT' for the same instr_id having same LEG_NUM and its respective RISS's and RIXR's.
-- |----------------------------------------------------------------


SET DEFINE OFF;

update ft_T_ridf set end_tms=sysdate,last_chg_usr_id='GS:MIG:BBEXTDPF:99365' where 
 RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from (select RLD_ISS_FEAT_ID,rel_typ,instr_id,last_chg_tms,row_number() over
(partition by instr_id,rel_typ,leg_num order by last_chg_tms desc)  cnt 
from ft_T_ridf where rel_typ in ('CONV','WARRANT') and end_tms is null )x where cnt!=1);

update ft_T_riss set end_tms=sysdate,last_chg_usr_id='GS:MIG:BBEXTDPF:99365' where RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from fT_T_ridf where last_chg_usr_id like '%GS:MIG:BBEXTDPF:99365%') and end_tms is null;

update fT_t_rixr set end_tms=sysdate,last_chg_usr_id='GS:MIG:BBEXTDPF:99365' where riss_oid in (select riss_oid from fT_T_riss where RLD_ISS_FEAT_ID in (select RLD_ISS_FEAT_ID from fT_T_ridf where last_chg_usr_id like '%GS:MIG:BBEXTDPF:99365%')) and end_tms is null;

INSERT INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20140129.sql', 1, 'GT#99365', SYSDATE, '8.99.22.0', '8.99.23.0', 'A',  SYSDATE);

SET DEFINE ON;