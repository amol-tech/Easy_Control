SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462342
-- | GT Ticket #:151805
-- | Date: 2018-10-31
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS
-- | Change Reason:Value of MKIS.PRC_UT_MEAS_TYP to be update to 'Per Share' of records created via BB Global Equity mapping having MKIS.PRC_UT_MEAS_TYP='Blank'
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181031_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_MKIS_GT151805
AS
   SELECT MKT_ISS_OID,
       INSTR_ID,
       MKT_OID,
       PRC_UT_MEAS_TYP,
       LAST_CHG_USR_ID,
       LAST_CHG_TMS,
       END_TMS
  FROM FT_T_MKIS
 WHERE     END_TMS IS NULL
       AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%''
       AND PRC_UT_MEAS_TYP = ''Blank''';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_BAK_MKIS_GT151805 ADD CONSTRAINT PK_BAK_MKIS_GT151805 PRIMARY KEY(MKT_ISS_OID)';
END;

DECLARE
   CURSOR CUR_MKIS_UPD
   IS
      SELECT * FROM FT_BAK_MKIS_GT151805;


   TYPE TYP_MKIS_UPD IS TABLE OF CUR_MKIS_UPD%ROWTYPE;

   VAR_MKIS_UPD   TYP_MKIS_UPD;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_MKIS_UPD;

   LOOP
      FETCH CUR_MKIS_UPD
         BULK COLLECT INTO VAR_MKIS_UPD
         LIMIT 10000;

      FORALL I IN 1 .. VAR_MKIS_UPD.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_MKIS
            SET PRC_UT_MEAS_TYP = 'Per Share',
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:MIG:151805:' || LAST_CHG_USR_ID
          WHERE MKT_ISS_OID = VAR_MKIS_UPD (I).MKT_ISS_OID;

      COMMIT;
      EXIT WHEN CUR_MKIS_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_MKIS_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;


INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20181031.sql',
             1,
             'GT151805',
             SYSDATE,
             '8.99.72.0',
             '8.99.73.2',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;