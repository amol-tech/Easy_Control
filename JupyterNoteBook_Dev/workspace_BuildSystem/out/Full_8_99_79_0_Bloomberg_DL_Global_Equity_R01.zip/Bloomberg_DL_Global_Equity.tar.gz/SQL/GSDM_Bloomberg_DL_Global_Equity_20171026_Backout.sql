SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #:141102
-- | Date: 2017-10-26
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RGCH
-- | Change Reason: Script to rollback the changes provided through GSDM_Bloomberg_DL_Global_Equity_20171026.sql
-- | Update Query : GSDM_Bloomberg_DL_Global_Equity_20171026.sql
-- |----------------------------------------------------------------

-- |NOTE :- Migration script is applicable only when the CCO RecordRegInfoForGeoRegion is set to NO.

DECLARE
   CURSOR CUR_RGCH
   IS
        SELECT   *
          FROM   FT_BAK_RGCH_141102
         WHERE   RGCH_OID IN (SELECT   RGCH_OID
                                FROM   FT_T_RGCH
                               WHERE   LAST_CHG_USR_ID LIKE '%141102%')
      ORDER BY   INSTR_ID, GU_ID NULLS LAST;

   CURSOR CUR_CLDF
   IS
      SELECT   *
        FROM   FT_T_CLDF
       WHERE   TBL_ID = 'RGCH'
               AND COL_NME NOT IN
                        ('DATA_SRC_ID',
                         'DATA_STAT_TYP',
                         'INSTR_ID',
                         'RGCH_OID');


   VAR_COLUMNS    VARCHAR2 (2000);
   VAR_SELECT     CLOB;
   VAR_CUR_DATA   CLOB;
   V_NUMERRORS    NUMBER (10);
BEGIN
   FOR VAR_CUR_CLDF IN CUR_CLDF
   LOOP
      VAR_COLUMNS := VAR_COLUMNS || VAR_CUR_CLDF.COL_NME || ' ,';
   END LOOP;


   VAR_COLUMNS := RTRIM (VAR_COLUMNS, ',') || ')';


   FOR VAR_CUR_RGCH IN CUR_RGCH
   LOOP
      VAR_SELECT :=
            'UPDATE FT_T_RGCH RGCH_UPD SET ('
         || VAR_COLUMNS
         || '= (SELECT '
         || RTRIM (LTRIM (VAR_COLUMNS, '('), ')')
         || ' FROM FT_BAK_RGCH_141102 WHERE RGCH_OID ='''
         || VAR_CUR_RGCH.RGCH_OID
         || ''')'
         || ' WHERE RGCH_OID ='''
         || VAR_CUR_RGCH.RGCH_OID
         || '''';

      EXECUTE IMMEDIATE VAR_SELECT;

      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('SQLCODE : ' || SQLCODE||' SQL ERROR MESSAGE : '||SQLERRM);
END;