-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:90032
-- | Date: 2013-04-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Suvarna Rane
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MKIS, FT_T_ISSU
-- | Change Reason: 1) To select the rows where MKIS.ACTIVELY_TRADED_IND is null when ISSU.ISS_ACTVY_STAT_TYP is 'ACTIVE'
-- |                2) To select the rows where MKIS.ACTIVELY_TRADED_IND is null when ISSU.ISS_ACTVY_STAT_TYP is 'INACTIVE'  
-- |                3) To select the rows where ISS_ACTVY_STAT_TYP='INACTIVE' for last_chg_usr_id is 'BBEXTDPF'
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

select * from ft_t_mkis a where instr_id in  (select instr_id from ft_t_issu b  where ISS_ACTVY_STAT_TYP ='ACTIVE' and last_chg_usr_id like '%BBEXTDPF%' and a.instr_id=b.instr_id )and ACTIVELY_TRADED_IND is null  and last_chg_usr_id like '%BBEXTDPF%';

select * from ft_t_mkis a where instr_id in  (select instr_id from ft_t_issu b where ISS_ACTVY_STAT_TYP ='INACTIVE' and last_chg_usr_id like '%BBEXTDPF%' and a.instr_id=b.instr_id )and ACTIVELY_TRADED_IND is null  and last_chg_usr_id like '%BBEXTDPF%';

select * from ft_t_issu where last_chg_usr_id like '%BBEXTDPF%' and ISS_ACTVY_STAT_TYP = 'INACTIVE';

SET DEFINE ON;