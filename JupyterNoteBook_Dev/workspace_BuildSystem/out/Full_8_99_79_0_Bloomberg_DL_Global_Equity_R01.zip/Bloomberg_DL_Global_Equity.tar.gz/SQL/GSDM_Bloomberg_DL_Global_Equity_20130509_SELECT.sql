-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:91331
-- | Date: 2013-05-09
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Suvarna Rane
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Migration script to view the records where DAYS_MTH_BAS_TYP='IEM' with last_chg_usr_id is 'BBEXTDPF'
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

SELECT * FROM  FT_T_IEDF WHERE DAY_CNT_DESC IN ('ISMA-30/ACT','ISMA-30/360','ISMA-30/365') AND LAST_CHG_USR_ID LIKE '%BBEXTDPF%' and DAYS_MTH_BAS_TYP='IEM';

SET DEFINE ON