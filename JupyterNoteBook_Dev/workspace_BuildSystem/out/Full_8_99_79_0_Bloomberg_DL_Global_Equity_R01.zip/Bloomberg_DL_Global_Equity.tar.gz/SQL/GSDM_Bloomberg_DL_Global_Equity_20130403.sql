-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:89988
-- | Date: 2013-04-03
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rajath Shetty
-- | Approved By: Rajeshwari C
-- |----------------------------------------------------------------
-- |Tables Affected:FT_T_EQST
-- | Select Query Patch : GSDM_Bloomberg_DL_Global_Equity_20130403_select.sql
-- | Change Reason: Duplicate entries in EQST with same mkt_oid and instr_oid

SET DEFINE OFF;


insert into ft_bak_eqst
select a.*,'dup eqst BBEQEURO:89988' || SYSDATE reason  from FT_T_eqst a where eqst_oid in  
(SELECT eqst_oid FROM (SELECT eqst_oid,instr_id,mkt_oid,LAST_CHG_TMS  ,row_number()                     
over(partition by instr_id,mkt_oid ORDER BY LAST_CHG_TMS desc) cnt           
FROM FT_T_eqst where STATS_CURR_CDE is not NULL ) where cnt !=1 );


insert into ft_bak_eqst
select a.*,'dup eqst BBEQEURO:89988' || SYSDATE reason  from FT_T_eqst a where eqst_oid in  
(SELECT eqst_oid FROM (SELECT eqst_oid,instr_id,mkt_oid,LAST_CHG_TMS  ,row_number()                     
over(partition by instr_id,mkt_oid ORDER BY LAST_CHG_TMS desc) cnt           
FROM FT_T_eqst where STATS_CURR_CDE is NULL ) where cnt !=1 );




insert into ft_bak_eqst
select a.*,'dup eqst BBEQEURO:89988' || SYSDATE reason  from FT_T_eqst a where eqst_oid in(
select eqst_oid from ft_T_eqst a where (select count(*) from ft_t_eqst b where a.instr_id=b.instr_id and a.MKT_OID=b.MKT_OID )>1 and   STATS_CURR_CDE is null);





delete from ft_t_eqst where eqst_oid in ( select eqst_oid from ft_bak_eqst);

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130403.sql', 1,'GT#89988', TO_DATE( '07/25/2010 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.4.0', 'A',  SYSDATE);


SET DEFINE ON;