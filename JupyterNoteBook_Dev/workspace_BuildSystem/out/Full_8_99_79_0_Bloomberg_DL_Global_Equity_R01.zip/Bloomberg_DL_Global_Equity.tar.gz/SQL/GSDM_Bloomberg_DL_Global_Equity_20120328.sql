-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:73780
-- | Date: 2012-03-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By:Navin Agarwal
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEVP,FT_T_PEVP
-- | Change Reason:
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update   FT_T_IEVP  set end_tms=SYSDATE,LAST_CHG_USR_ID='GS:CONMIG' where INC_EV_PRT_ID in 
(Select INC_EV_PRT_ID from (Select INC_EV_PRT_ID,INC_EV_DEF_ID,PRT_PURP_TYP,last_chg_tms,row_number() 
over(partition by INC_EV_DEF_ID,PRT_PURP_TYP,PRT_DESC order by last_chg_tms desc) cnt 
From ft_t_IEVP where PRT_PURP_TYP='DIVIDEND' and LAST_CHG_USR_ID='BBEXTDPF' ) where cnt !=1  );


update   FT_T_PEVP  set end_tms=SYSDATE,LAST_CHG_USR_ID='GS:CONMIG' where PRIN_EV_PRT_ID in 
(Select PRIN_EV_PRT_ID from (Select PRIN_EV_PRT_ID,PRIN_EV_DEF_ID,PRT_PURP_TYP,last_chg_tms,row_number() 
over(partition by PRIN_EV_DEF_ID,PRT_PURP_TYP,PRT_DESC order by last_chg_tms desc) cnt 
From ft_t_PEVP where PRT_PURP_TYP='SHS' and LAST_CHG_USR_ID='BBEXTDPF' ) where cnt !=1  );

SET DEFINE ON;

