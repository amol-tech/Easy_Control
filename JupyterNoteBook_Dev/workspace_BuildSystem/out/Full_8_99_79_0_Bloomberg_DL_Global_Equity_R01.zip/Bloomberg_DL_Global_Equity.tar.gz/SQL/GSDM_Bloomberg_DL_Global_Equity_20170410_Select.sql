SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454205
-- | GT Ticket #: 132863
-- | Date: 2017-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_INCL, FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to retrieve data from INCL and FT_T_FICL,  FT_T_IRCL WHERE INDUS_CL_SET_ID = 'NAICS'
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170410.sql
-- |----------------------------------------------------------------

SELECT   *
  FROM   FT_T_INCL
 WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
         AND (CL_VALUE, INDUS_CL_SET_ID) IN
                  (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                       FROM   FT_T_INCL
                      WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                   GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                     HAVING   COUNT (1) > 1)
UNION
SELECT   *
  FROM   FT_T_INCL
 WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
         AND (CL_VALUE, INDUS_CL_SET_ID) IN
                  (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                       FROM   FT_T_INCL
                      WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                   GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                     HAVING   COUNT (1) = 1)
         AND LEVEL_NUM IS NULL
         AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

SELECT   *
  FROM   FT_T_FICL
 WHERE   END_TMS IS NULL AND INDUS_CL_SET_ID = 'NAICS'
         AND (CL_VALUE, CLSF_OID) IN
                  (SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_T_INCL
                    WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                            AND (CL_VALUE, INDUS_CL_SET_ID) IN
                                     (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                                          FROM   FT_T_INCL
                                         WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                                      GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                                        HAVING   COUNT (1) > 1)
                            AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
                   UNION
                   SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_T_INCL
                    WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                            AND (CL_VALUE, INDUS_CL_SET_ID) IN
                                     (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                                          FROM   FT_T_INCL
                                         WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                                      GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                                        HAVING   COUNT (1) = 1)
                            AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
                            AND LEVEL_NUM IS NULL);

SELECT   *
  FROM   FT_T_IRCL
 WHERE   END_TMS IS NULL AND INDUS_CL_SET_ID = 'NAICS'
         AND (CL_VALUE, CLSF_OID) IN
                  (SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_T_INCL
                    WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                            AND (CL_VALUE, INDUS_CL_SET_ID) IN
                                     (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                                          FROM   FT_T_INCL
                                         WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                                      GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                                        HAVING   COUNT (1) > 1)
                            AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
                   UNION
                   SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_T_INCL
                    WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                            AND (CL_VALUE, INDUS_CL_SET_ID) IN
                                     (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                                          FROM   FT_T_INCL
                                         WHERE   INDUS_CL_SET_ID = 'NAICS' AND END_TMS IS NULL
                                      GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                                        HAVING   COUNT (1) = 1)
                            AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
                            AND LEVEL_NUM IS NULL);


SET DEFINE ON;