SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456436
-- | GT Ticket #:139015
-- | Date: 2017-10-12
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST, FT_T_MUST
-- | Change Reason: Script to rollbcak the changes provided through GSDM_Bloomberg_DL_Global_Equity_20171012.sql
-- | Query Pacth: GSDM_Bloomberg_DL_Global_Equity_20171012.sql
-- |----------------------------------------------------------------

BEGIN
	
EXECUTE IMMEDIATE 'DELETE FROM FT_T_MUST WHERE LAST_CHG_USR_ID LIKE ''%139015%''';	
	
COMMIT;	

END;	

DECLARE
   CURSOR CUR_ISST
   IS
      SELECT   STAT_ID, LAST_CHG_TMS, LAST_CHG_USR_ID
        FROM   FT_T_ISST_BKP_GT139015;

   VAR_ISST   CUR_ISST%ROWTYPE;
BEGIN
   FOR VAR_ISST IN CUR_ISST
   LOOP
      EXIT WHEN CUR_ISST%NOTFOUND;

      UPDATE   FT_T_ISST
         SET   END_TMS = NULL,
               LAST_CHG_TMS = VAR_ISST.LAST_CHG_TMS,
               LAST_CHG_USR_ID = VAR_ISST.LAST_CHG_USR_ID
       WHERE   STAT_ID = VAR_ISST.STAT_ID;

      COMMIT;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'SQLCODE : ' || SQLCODE || ' SQLERRM : ' || SQLERRM
      );
END;