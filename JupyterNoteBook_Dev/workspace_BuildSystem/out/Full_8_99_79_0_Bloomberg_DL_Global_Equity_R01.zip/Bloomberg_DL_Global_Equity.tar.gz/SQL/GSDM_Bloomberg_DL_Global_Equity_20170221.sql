SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 453367
-- | GT Ticket #: 133077
-- | Date: 2017-01-24
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Script to move data from IEDF.RTFX_BAS_TYP to IEDF.RTFX_BAS_TXT
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170221_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_IEDF_GT133077
AS SELECT   INC_EV_DEF_ID,
         RTFX_BAS_TYP,
         RTFX_BAS_TXT,
         LAST_CHG_TMS,
         LAST_CHG_USR_ID
  FROM   FT_T_IEDF
 WHERE   END_TMS IS NULL
         AND RTFX_BAS_TYP IS NOT NULL
         AND LAST_CHG_USR_ID LIKE ''%BBEXTDPF%''';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_BAK_IEDF_GT133077 ADD CONSTRAINT IEDF_BAK_133077_PK PRIMARY KEY(INC_EV_DEF_ID)';
END;

DECLARE
   CURSOR CUR_IEDF_UPD
   IS
      SELECT   INC_EV_DEF_ID, RTFX_BAS_TXT, RTFX_BAS_TYP
        FROM   FT_T_IEDF
       WHERE       END_TMS IS NULL
               AND RTFX_BAS_TYP IS NOT NULL
               AND LAST_CHG_USR_ID LIKE '%BBEXTDPF%';


   TYPE TAB_IEDF_UPD IS TABLE OF CUR_IEDF_UPD%ROWTYPE;

   VAR_IEDF_UPD   TAB_IEDF_UPD;


   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_IEDF_UPD;

   LOOP
      FETCH CUR_IEDF_UPD BULK COLLECT INTO   VAR_IEDF_UPD LIMIT 10000;

      FORALL I IN 1 .. VAR_IEDF_UPD.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_IEDF
            SET   RTFX_BAS_TXT = RTFX_BAS_TYP,
                  RTFX_BAS_TYP = NULL,
                  LAST_CHG_USR_ID = 'GS:MIG:BBEXTDPF:133077',
                  LAST_CHG_TMS = SYSDATE
          WHERE   INC_EV_DEF_ID = VAR_IEDF_UPD (I).INC_EV_DEF_ID;

      COMMIT;
      EXIT WHEN CUR_IEDF_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_IEDF_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS
      );

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || V_COUNT
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   ('GSDM_Bloomberg_DL_Global_Equity_20170221.sql',
            1,
            'GT133077',
            SYSDATE,
            '8.99.58.0',
            '8.99.59.0',
            'A',
            SYSDATE);

COMMIT;


SET DEFINE ON;