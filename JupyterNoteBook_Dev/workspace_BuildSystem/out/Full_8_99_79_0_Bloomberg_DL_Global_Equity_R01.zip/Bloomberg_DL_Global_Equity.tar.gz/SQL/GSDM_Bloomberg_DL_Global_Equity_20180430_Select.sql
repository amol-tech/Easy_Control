SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | FrontOffice ID: 456382 
-- | GT Ticket #: 138745
-- | Date: 2018-04-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISST
-- | Change Reason: Script to fetch rows from FT_T_ISST where where STAT_DEF_ID='PREEURPR' and DENOM_CURR_CDE is not null and LAST_CHG_USR_ID='BBEQEURO'
-- |                and END_TMS is null
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20180430.sql
-- |----------------------------------------------------------------


SELECT   *
  FROM   FT_T_ISST
 WHERE   STAT_ID IN
               (SELECT   STAT_ID
                  FROM   (SELECT   STAT_ID,
                                   ROW_NUMBER ()
                                      OVER (PARTITION BY INSTR_ID
                                            ORDER BY LAST_CHG_TMS DESC)
                                      CNT
                            FROM   FT_T_ISST
                           WHERE       STAT_DEF_ID = 'PREEURPR'
                                   AND DENOM_CURR_CDE IS NOT NULL
                                  AND LAST_CHG_USR_ID = 'BBEQEURO' 
                                  AND END_TMS IS NULL));

SET DEFINE ON;