-- |----------------------------------------------------------------
-- | Front Office #: 448274
-- | GT Ticket #:120463
-- | Date: 2015-11-04
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pooja Munj
-- | Approved By: Prashant Zambre
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_INCL, FT_T_ISCL
-- | Select Script name : GSDM_Bloomberg_DL_Global_Equity_20151104_Select.sql
-- | Change Reason: Migration provided to update INDUS_CL_SET_ID with 'BBINDSGR' from 'INDSUBGR  ' in tables FT_T_INCL and FT_T_ISCL. 
-- |----------------------------------------------------------------
SET DEFINE OFF;

--- UPDATE STATEMENT TO END DATE INCL

Update FT_T_INCL
SET END_TMS = SYSDATE,
LAST_CHG_USR_ID = 'GS:MIG:120463:BBEXTDPF'
WHERE  CLSF_OID IN (SELECT   CLSF_OID
                    FROM   FT_T_INCL a
                    WHERE   EXISTS( SELECT b.CL_VALUE, b.INDUS_CL_SET_iD
                                      FROM FT_T_INCL b
                                     WHERE b.INDUS_CL_SET_id = 'BBINDSGR'
                                       AND a.CL_VALUE = b.CL_VALUE
                                  GROUP BY b.CL_VALUE, b.INDUS_CL_SET_id)
                   AND INDUS_CL_SET_ID = 'INDSUBGR'
                   AND END_TMS IS NULL
                   AND LAST_CHG_USR_ID = 'BBEXTDPF');

-- UPDATE STATEMENT UPDATE INDUS_CL_SET_ID TO 'BBINDSGR' FROM 'INDSUBGR'.
                   
UPDATE  FT_T_INCL
SET     INDUS_CL_SET_ID = 'BBINDSGR',
        LAST_CHG_USR_ID = 'GS:MIG:120463:BBEXTDPF'
WHERE   LAST_CHG_USR_ID = 'BBEXTDPF'
AND     INDUS_CL_SET_ID = 'INDSUBGR  '
AND     END_TMS IS NULL;


-- UPDATE STATEMENT TO UPDATE ISCL RECORDS OF INDUS_CL_SET_ID WITH 'BBINDSGR' AND TO UPDATE CLSF_OID WITH THE ACTIVE RECORD IN INCL.


MERGE INTO FT_T_ISCL b
USING (SELECT   b.CLSF_OID,b.cl_value
                        FROM   FT_T_INCL b
                        where b.end_tms is null
                          and b.INDUS_CL_SET_ID = 'BBINDSGR'
                          and b.LAST_CHG_USR_ID not like '%120463%'
--                          AND a.cl_value = b.cl_value
                          and b.CLSF_OID in (select CLSF_OID from (select CLSF_OID,INDUS_CL_SET_ID,CL_VALUE,LEVEL_NUM,LAST_CHG_USR_ID,CL_NME,last_chg_tms, row_number() over 
                                                                  (partition by CL_VALUE order by last_chg_tms desc)cnt
                                                                   from ft_t_incl 
                                                                   where INDUS_CL_SET_ID = 'BBINDSGR'
                                                                  )x where cnt = 1
                                            )
        ) e
ON (b.cl_value = e.CL_value
and b.end_tms is null
and b.clsf_oid IN(SELECT  CLSF_OID
                        FROM  FT_T_INCL 
                        WHERE end_tms is not null
                        and LAST_CHG_USR_ID LIKE '%120463%'
))
WHEN MATCHED THEN
  UPDATE SET b.INDUS_CL_SET_ID = 'BBINDSGR',
            B.CLSF_OID = e.CLSF_OID,
            LAST_CHG_USR_ID = 'GS:MIG:120463:BBEXTDPF';
            
---UPDATE STATEMENT TO UPDATE REMAINING ISCL RECORDS WITH 'BBINDSGR'.

UPDATE  FT_T_ISCL
SET     INDUS_CL_SET_ID = 'BBINDSGR',
        LAST_CHG_USR_ID = 'GS:MIG:120463:BBEXTDPF'
WHERE   LAST_CHG_USR_ID = 'BBEXTDPF'
AND     INDUS_CL_SET_ID = 'INDSUBGR  '
AND     END_TMS IS NULL;


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20151104.sql', 1, 'GT120463', SYSDATE, '8.99.45.0', '8.99.47.0', 'A',  SYSDATE);

SET DEFINE ON;