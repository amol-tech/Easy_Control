SET DEFINE OFF;
--------------------------------------------------------------
-- | Front Office #: 442475
-- | GT Ticket #: 102991
-- | Date: 03/04/2014
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nilesh Desai
-- | Approved By: Abhijeet Dhuru
-- | SQL Patch: GSDM_Bloomberg_DL_Global_Equity_20140403.sql
-- | Change Reason: Below SELECT query will fetch the corresponding PPDF records for the PEDF having the EV_TYP 'SINKING which will get updated with correct END_TMS by migration script.
 


SELECT * FROM FT_t_PPDF where PRIN_PAY_DEF_ID 
in (select PRIN_PAY_DEF_ID from ft_t_ppdf where  PRIN_EV_PRT_ID  in (select PRIN_EV_PRT_ID  from FT_T_pevp where PRIN_EV_DEF_ID in (select PRIN_EV_DEF_ID from FT_T_pedf where ev_typ='SINKING')))  ;




SET DEFINE ON;