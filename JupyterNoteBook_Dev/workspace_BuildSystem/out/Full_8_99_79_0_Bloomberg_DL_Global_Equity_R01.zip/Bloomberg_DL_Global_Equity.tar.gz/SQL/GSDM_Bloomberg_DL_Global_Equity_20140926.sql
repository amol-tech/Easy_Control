-- |----------------------------------------------------------------
-- | Front Office #:438083,445515
-- | GT Ticket #: 101019,112101
-- | Date: 2014-10-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Yash Somaiya
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISLL
-- | Change Reason: Migration script provided 
-- |                a.To delete ISLL record, if duplicate ACTIVE ISLL record is present on the basis of INSTR_ID.
-- |                b.To backdate start_tms of enddated record to avoid unique contraint.
-- |                c.To update COLL_ID ='PRIMARY' if single ACTIVE ISLL record present for INSTR_ID and COLL_TYP.
-- | Select Script: GSDM_Bloomberg_DL_Global_Equity_20140926_SELECT.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

-- To delete ISLL record created through BB if duplicate ACTIVE ISLL record is present on the basis of INSTR_ID.


      INSERT INTO ft_bak_isll
         SELECT a.*, 'dup isll BB:101019' || SYSDATE reason
           FROM ft_t_isll a
          WHERE a.isll_oid IN (
                   SELECT isll_oid
                     FROM (SELECT isll_oid, instr_id, last_chg_tms,
                                  ROW_NUMBER () OVER (PARTITION BY instr_id ORDER BY last_chg_tms DESC)
                                                                          cnt
                             FROM ft_t_isll
                            WHERE end_tms IS NULL)
                    WHERE cnt != 1);

      DELETE FROM ft_t_isll
            WHERE isll_oid IN (SELECT isll_oid
                                 FROM ft_bak_isll);

      COMMIT;


--To backdate start_tms of enddated record to avoid unique contraint.

DECLARE
   v_numerrors     NUMBER (10);
   v_err_code      VARCHAR2 (20);
   v_err_msg       VARCHAR2 (200);

   TYPE r_type IS RECORD (
      p_start_tms   ft_t_isll.start_tms%TYPE,
      p_isll_oid    ft_t_isll.isll_oid%TYPE
   );

   TYPE tr_type IS TABLE OF r_type;

   p_bulkcleanup   tr_type;
   p_array_size    NUMBER         := 10000;

   CURSOR c
   IS
      SELECT (SELECT MIN (start_tms) - 1
                FROM ft_t_isll d
               WHERE a.instr_id = d.instr_id) "STARTTMS", a.isll_oid
        FROM ft_t_isll a
       WHERE (SELECT COUNT (*)
                FROM ft_t_isll b
               WHERE a.coll_typ = b.coll_typ AND a.instr_id = b.instr_id) > 1
         AND end_tms IS NOT NULL
         AND coll_id = 'PRIMARY'
         AND TRUNC (start_tms, 'DDD') =
                          (SELECT TRUNC (start_tms, 'DDD')
                             FROM ft_t_isll c
                            WHERE a.instr_id = c.instr_id AND end_tms IS NULL);
BEGIN
  
      DBMS_OUTPUT.put_line ('Before Bulk Collect 1: ' || SYSTIMESTAMP);

      OPEN c;

      LOOP
         FETCH c
         BULK COLLECT INTO p_bulkcleanup LIMIT p_array_size;

         FORALL i IN 1 .. p_bulkcleanup.COUNT SAVE EXCEPTIONS
            UPDATE ft_t_isll
               SET start_tms = p_bulkcleanup (i).p_start_tms,
                   last_chg_usr_id = 'GS:CONN:101019:BBEXTDPF'
             WHERE isll_oid = p_bulkcleanup (i).p_isll_oid;
         COMMIT;
         EXIT WHEN c%NOTFOUND;
      END LOOP;

      DBMS_OUTPUT.put_line ('After Bulk Collect 1: ' || SYSTIMESTAMP);

      CLOSE c;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line ('Got exception: ' || SQLERRM);
      v_numerrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.put_line (   'Number of errors during processing: '
                            || v_numerrors
                           );

      FOR v_count IN 1 .. v_numerrors
      LOOP
         DBMS_OUTPUT.put_line
                         (   'Error '
                          || v_count
                          || ', iteration '
                          || SQL%BULK_EXCEPTIONS (v_count).ERROR_INDEX
                          || ' is: '
                          || SQLERRM
                                   (  0
                                    - SQL%BULK_EXCEPTIONS (v_count).ERROR_CODE
                                   )
                         );
      END LOOP;
END;
/

--To update COLL_ID ='PRIMARY' if single ACTIVE ISLL record present for INSTR_ID and COLL_TYP.

DECLARE
   v_numerrors    NUMBER (10);
   v_err_code     VARCHAR2 (20);
   v_err_msg      VARCHAR2 (200);

   TYPE isll_cur_arr IS TABLE OF ft_t_isll.isll_oid%TYPE;

   v_isll_arr     isll_cur_arr;
   p_array_size   NUMBER         := 10000;

   CURSOR c
   IS
      (SELECT isll_oid
         FROM ft_t_isll a
        WHERE (SELECT COUNT (*)
                 FROM ft_t_isll b
                WHERE a.instr_id = b.instr_id AND end_tms IS NULL) = 1
          AND end_tms IS NULL
          AND coll_id IS NULL);
BEGIN
  

      DBMS_OUTPUT.put_line ('Before Bulk Collect 2: ' || SYSTIMESTAMP);

      OPEN c;

      LOOP
         FETCH c
         BULK COLLECT INTO v_isll_arr LIMIT p_array_size;

         FORALL i IN 1 .. v_isll_arr.COUNT SAVE EXCEPTIONS
            UPDATE ft_t_isll
               SET coll_id = 'PRIMARY',
                   last_chg_usr_id = 'GS:CONN:101019:BBEXTDPF'
             WHERE isll_oid = v_isll_arr (i);
         COMMIT;
         EXIT WHEN c%NOTFOUND;
      END LOOP;

      DBMS_OUTPUT.put_line ('After Bulk Collect 2: ' || SYSTIMESTAMP);

      CLOSE c;
  
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line ('Got exception: ' || SQLERRM);
      v_numerrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.put_line (   'Number of errors during processing: '
                            || v_numerrors
                           );

      FOR v_count IN 1 .. v_numerrors
      LOOP
         DBMS_OUTPUT.put_line
                         (   'Error '
                          || v_count
                          || ', iteration '
                          || SQL%BULK_EXCEPTIONS (v_count).ERROR_INDEX
                          || ' is: '
                          || SQLERRM
                                   (  0
                                    - SQL%BULK_EXCEPTIONS (v_count).ERROR_CODE
                                   )
                         );
      END LOOP;
END;
/

INSERT INTO ft_o_sctl
            (patch_id, patch_seq_num, patch_id_ctxt_typ,
             release_tms,
             base_modl_ver_id, curr_modl_ver_id, patch_stat_typ,
             patch_applied_tms
            )
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20140926.sql', 1, 'GT101019',
             TO_DATE ('09/26/2014 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'),
             '8.99.0.1', '8.99.33.0', 'A',
             SYSDATE
            );


SET DEFINE ON;