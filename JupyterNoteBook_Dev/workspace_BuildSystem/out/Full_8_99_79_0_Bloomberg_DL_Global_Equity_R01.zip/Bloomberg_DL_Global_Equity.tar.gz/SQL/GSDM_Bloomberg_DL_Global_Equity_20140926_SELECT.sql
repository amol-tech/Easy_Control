-- |----------------------------------------------------------------
-- | Front Office #:438083,445515
-- | GT Ticket #:101019,112101
-- | Date: 2014-10-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Yash Somaiya
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISLL
-- | Change Reason: Migration script provided 
-- |                a.To delete ISLL record, if duplicate ACTIVE ISLL record is present on the basis of INSTR_ID.
-- |                b.To backdate start_tms of enddated record to avoid unique contraint.
-- |                c.To update COLL_ID ='PRIMARY' if single ACTIVE ISLL record present for INSTR_ID and COLL_TYP.
-- |----------------------------------------------------------------

SET DEFINE OFF;

-- To delete ISLL record created through BB if duplicate ACTIVE ISLL record is present on the basis of INSTR_ID.

SELECT *
  FROM ft_t_isll a
 WHERE isll_oid IN (
          SELECT isll_oid
            FROM (SELECT isll_oid, instr_id, last_chg_tms,
                         ROW_NUMBER () OVER (PARTITION BY instr_id ORDER BY last_chg_tms DESC)
                                                                          cnt
                    FROM ft_t_isll
                   WHERE end_tms IS NULL)
           WHERE cnt != 1);

--To backdate start_tms of enddated record to avoid unique contraint.

SELECT a.*
  FROM ft_t_isll a
 WHERE (SELECT COUNT (*)
          FROM ft_t_isll b
         WHERE a.coll_typ = b.coll_typ AND a.instr_id = b.instr_id) > 1
   AND end_tms IS NOT NULL
   AND coll_id = 'PRIMARY'
   AND TRUNC (start_tms, 'DDD') =
                          (SELECT TRUNC (start_tms, 'DDD')
                             FROM ft_t_isll c
                            WHERE a.instr_id = c.instr_id AND end_tms IS NULL);

-- To update COLL_ID ='PRIMARY' if single ACTIVE ISLL record present for INSTR_ID and COLL_TYP.

SELECT *
  FROM ft_t_isll a
 WHERE (SELECT COUNT (*)
          FROM ft_t_isll b
         WHERE a.instr_id = b.instr_id AND end_tms IS NULL) = 1
   AND end_tms IS NULL
   AND coll_id IS NULL;

SET DEFINE ON;