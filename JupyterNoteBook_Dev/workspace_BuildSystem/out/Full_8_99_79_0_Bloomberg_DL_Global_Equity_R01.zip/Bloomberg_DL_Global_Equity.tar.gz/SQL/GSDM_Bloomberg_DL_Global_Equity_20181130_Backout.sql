SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462342
-- | GT Ticket #:151805
-- | Date: 2018-10-31
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS
-- | Change Reason: Script to revert back changes made in Update Script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181031.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISST_BKP
   IS
      SELECT * FROM FT_T_ISST_BACKUP_GT151138;

   TYPE TYP_ISST_BKP IS TABLE OF CUR_ISST_BKP%ROWTYPE;

   VAR_ISST_BKP   TYP_ISST_BKP;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISST_BKP;

   LOOP
      FETCH CUR_ISST_BKP
         BULK COLLECT INTO VAR_ISST_BKP
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISST_BKP.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISST
          SET END_TMS = VAR_ISST_BKP (I).END_TMS,
                DENOM_CURR_CDE = VAR_ISST_BKP (I).DENOM_CURR_CDE,
                LAST_CHG_TMS = VAR_ISST_BKP (I).LAST_CHG_TMS,
                LAST_CHG_USR_ID = VAR_ISST_BKP (I).LAST_CHG_USR_ID
          WHERE STAT_ID = VAR_ISST_BKP (I).STAT_ID;

      COMMIT;

      EXIT WHEN CUR_ISST_BKP%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISST_BKP;
   
   
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;