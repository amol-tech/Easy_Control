-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:74338
-- | Date: 2012-01-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Gaurav Mhasalkar
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_MKIS,FT_T_ISGU,FT_T_IRGU,FT_T_FIGU
-- | Change Reason: Adding condition in mapping of CNTRY_ISSUE_ISO for 'UNKNOWN' PRNT_GU_TYP / GU_TYP
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_MKIS SET GU_TYP ='UNKNOWN',LAST_CHG_USR_ID='GSCON:MIG' WHERE GU_ID IN('01','02','03','04','UNKNOWN') AND GU_TYP ='COUNTRY' AND LAST_CHG_USR_ID in('BBEQEURO','BBEXTDPF');

UPDATE FT_T_ISGU SET GU_TYP ='UNKNOWN',LAST_CHG_USR_ID='GSCON:MIG' WHERE GU_ID IN('01','02','03','04','UNKNOWN') AND GU_TYP ='COUNTRY' AND LAST_CHG_USR_ID in('BBEQEURO','BBEXTDPF');

UPDATE FT_T_IRGU SET GU_TYP ='UNKNOWN',LAST_CHG_USR_ID='GSCON:MIG' WHERE GU_ID IN('01','02','03','04','UNKNOWN') AND GU_TYP ='COUNTRY' AND LAST_CHG_USR_ID in('BBEQEURO','BBEXTDPF');

UPDATE FT_T_FIGU SET GU_TYP ='UNKNOWN',LAST_CHG_USR_ID='GSCON:MIG' WHERE GU_ID IN('01','02','03','04','UNKNOWN') AND GU_TYP ='COUNTRY' AND LAST_CHG_USR_ID in('BBEQEURO','BBEXTDPF');


SET DEFINE ON;