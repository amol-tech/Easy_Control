-- |----------------------------------------------------------------
-- | Front Office #: NA
-- | Bugzilla #: 76885
-- | Date: 2012-03-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Yash Somaiya
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_MKIS
-- |
-- | Change Reason: Duplicate MKIS records are setup from BB and TK
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE  FT_T_MKIS MKIS set END_TMS=SYSDATE,LAST_CHG_USR_ID='GSCON:MIG' WHERE 
MKIS.QUAL_ISID_OID is not null
and  exists(select 1 from ft_t_MKIS where QUAL_ISID_OID is  null
and MKT_OID = MKIS.MKT_OID and INSTR_ID = MKIS.INSTR_ID and TRDNG_CURR_CDE = MKIS.TRDNG_CURR_CDE) and LAST_CHG_USR_ID ='BBEQEURO';

UPDATE FT_T_MKIS SET QUAL_ISID_OID=NULL WHERE LAST_CHG_USR_ID ='BBEQEURO' and END_TMS is NULL;


SET DEFINE ON;