SET DEFINE OFF;
--------------------------------------------------------------
-- | Frontoffice ID #:454284
-- | GT Ticket #: 134195
-- | Date: 21-04-2017 
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- | Tables Affected: FT_T_ISID, FT_T_MIXR
-- | Change Reason: To nullify the mkt_oid for the ID_CTXT_TYP as BBUNIQUE and also endating duplicate ISID and it's MIXR.
-- | Select Patch Name: GSDM_Bloomberg_DL_Global_Equity_20170421_Select.sql
--------------------------------------------------------------


/* Create Backup Table of FT_T_ISID as FT_T_ISID_BAK_GT134195 */
CREATE TABLE FT_T_ISID_BAK_GT134195
AS
SELECT /*+PARALLEL(16)*/ DISTINCT ISID.*
FROM
 (SELECT   /*+PARALLEL(16)*/  A.*
                            FROM    FT_T_ISID A WHERE A.ID_CTXT_TYP = 'BBUNIQUE') ISID,
                            ( SELECT /*+PARALLEL(16)*/    B.INSTR_ID FROM
                                    FT_T_ISCL B,
                                    FT_T_INCL C
                            WHERE   B.CLSF_OID = C.CLSF_OID
                            and     B.CL_value = C.CL_VALUE 
                            AND     C.INDUS_CL_SET_ID = 'BBMKTSCT'    
                            AND     C.cl_nme IN ('Govt',
                                                                                          'Pfd',
                                                                                          'Corp',
                                                                                          'Mtge',
                                                                                          'Muni',
                                                                                          'ComdtyFut',
                                                                                          'ComdtyOpt',
                                                                                          'Comdty','Index','Curncy')) ISCL
              WHERE    ISID.INSTR_ID=ISCL.INSTR_ID
 UNION
 SELECT /*+PARALLEL(16)*/ * FROM (SELECT * FROM 
                      (SELECT /*+PARALLEL(16)*/ * FROM FT_T_ISID WHERE ID_CTXT_TYP='BBUNIQUE' ) A
                      WHERE  EXISTS( SELECT 1 FROM FT_T_ISID B
                                    WHERE A.ISS_ID=B.ISS_ID
                                    AND A.INSTR_ID!=B.INSTR_ID
                                    AND A.START_TMS=B.START_TMS
                                    AND B.ID_CTXT_TYP=A.ID_CTXT_TYP));              


ALTER TABLE FT_T_ISID_BAK_GT134195 ADD PRIMARY KEY (ISID_OID);
        
/* Create Backup Table of FT_T_MIXR as FT_T_MIXR_BAK_GT134195 */

CREATE TABLE FT_T_MIXR_BAK_GT134195
AS
   SELECT                                                   /*+ PARALLEL(16)*/
            C.MIXR_OID,
            C.ISID_OID,
            C.END_TMS,
            C.LAST_CHG_USR_ID,
            C.LAST_CHG_TMS
     FROM   FT_T_MIXR C,
            (SELECT                                         /*+ PARALLEL(16)*/
                   ISID_OID
               FROM   FT_T_ISID_BAK_GT134195) D
        WHERE   C.ISID_OID = D.ISID_OID AND C.END_TMS IS NULL;
    
    
/* UPDATE START_TMS - COUNT - 0.02 FOR U001 DUPLICATE RECORDS - START_TMS Inclusive */
DECLARE
   CURSOR CUR_ISID_U001
   IS
      SELECT   *
        FROM   (SELECT   ISID_OID,
                         START_TMS, LAST_CHG_USR_ID, 
                         DENSE_RANK ()
                            OVER (
                               PARTITION BY ID_CTXT_TYP,
                                            INSTR_ID,
                                            NVL (ISS_TENOR_TYP, 'A'),
                                            NVL (ISS_USAGE_TYP, 'A'),
                                            NVL (WHEN_ISSUED_IND, 'A'),
                                            NVL (TRDNG_CURR_CDE, 'A'),
                                            NVL (NOT_TRADABLE_IND, 'A'),
                                            START_TMS
                               ORDER BY START_TMS DESC,
                                        END_TMS DESC,
                                        LAST_CHG_TMS,
                                        ISID_OID
                            ) RANK_ISID
                  FROM   (SELECT                            /*+ PARALLEL(16)*/
                                A  .*
                           FROM   FT_T_ISID_BAK_GT134195 A
                           WHERE   (A.ID_CTXT_TYP,
                                        A.INSTR_ID,
                                        NVL (ISS_TENOR_TYP, 'A'),
                                        NVL (ISS_USAGE_TYP, 'A'),
                                        NVL (WHEN_ISSUED_IND, 'A'),
                                        NVL (TRDNG_CURR_CDE, 'A'),
                                        NVL (NOT_TRADABLE_IND, 'A'),
                                        START_TMS) IN
                                            (  SELECT       /*+ PARALLEL(16)*/
                                                     ID_CTXT_TYP,
                                                        INSTR_ID,
                                                        NVL (ISS_TENOR_TYP,'A'),
                                                        NVL (ISS_USAGE_TYP,'A'),
                                                        NVL (WHEN_ISSUED_IND,'A'),
                                                        NVL (TRDNG_CURR_CDE,'A'),
                                                        NVL (NOT_TRADABLE_IND,'A'),
                                                        START_TMS
                                                 FROM   FT_T_ISID_BAK_GT134195
                                             GROUP BY   ID_CTXT_TYP,
                                                        INSTR_ID,
                                                        ISS_TENOR_TYP,
                                                        ISS_USAGE_TYP,
                                                        WHEN_ISSUED_IND,
                                                        TRDNG_CURR_CDE,
                                                        NOT_TRADABLE_IND,
                                                        START_TMS
                                               HAVING   COUNT ( * ) > 1)));

   VAR_CUR_ISID_U001   CUR_ISID_U001%ROWTYPE;
   V_REC  NUMBER;
BEGIN
    V_REC:=0;
   OPEN CUR_ISID_U001;

   LOOP
      FETCH CUR_ISID_U001 INTO   VAR_CUR_ISID_U001;

      EXIT WHEN CUR_ISID_U001%NOTFOUND;

      IF VAR_CUR_ISID_U001.RANK_ISID > 1
      THEN
         UPDATE   FT_T_ISID
            SET   START_TMS = (START_TMS - (VAR_CUR_ISID_U001.RANK_ISID - 1 - 0.02)),
                  LAST_CHG_USR_ID = 'GS:CON:134195:'||VAR_CUR_ISID_U001.LAST_CHG_USR_ID
          WHERE   ISID_OID = VAR_CUR_ISID_U001.ISID_OID;
          V_REC:=V_REC+1;
          COMMIT;
      END IF;
   END LOOP;

   CLOSE CUR_ISID_U001;
   DBMS_OUTPUT.PUT_LINE('UPDATED RECORDS AS A PART OF STEP1 ' || V_REC);
EXCEPTION
   WHEN OTHERS
   THEN
      raise_application_error (-20101, 'ISID migration is failed' || SQLCODE || SQLERRM);
END;
/        

/* UPDATE START_TMS - COUNT - 0.02 FOR U002 DUPLICATE RECORDS - START_TMS Inclusive*/
DECLARE
   CURSOR CUR_ISID_U002
   IS
      SELECT   *
        FROM   (SELECT   ISID_OID,
                         START_TMS,LAST_CHG_USR_ID,
                         DENSE_RANK ()
                            OVER (
                               PARTITION BY ID_CTXT_TYP,
                                            ISS_ID,
                                            NVL (ISS_TENOR_TYP, 'A'),
                                            NVL (ISS_USAGE_TYP, 'A'),
                                            NVL (WHEN_ISSUED_IND, 'A'),
                                            NVL (TRDNG_CURR_CDE, 'A'),
                                            NVL (NOT_TRADABLE_IND, 'A'),
                                            NVL (MERGE_UNIQ_OID, 'A'),
                                            START_TMS
                               ORDER BY START_TMS DESC,
                                        END_TMS DESC,
                                        LAST_CHG_TMS,
                                        ISID_OID
                            ) RANK_ISID
                  FROM   (SELECT                            /*+ PARALLEL(16)*/
                                A  .*
                            FROM   FT_T_ISID_BAK_GT134195 A
                           WHERE    (A.ID_CTXT_TYP,
                                        ISS_ID,
                                        NVL (ISS_TENOR_TYP, 'A'),
                                        NVL (ISS_USAGE_TYP, 'A'),
                                        NVL (WHEN_ISSUED_IND, 'A'),
                                        NVL (TRDNG_CURR_CDE, 'A'),
                                        NVL (NOT_TRADABLE_IND, 'A'),
                                        NVL (MERGE_UNIQ_OID, 'A'),
                                        START_TMS) IN
                                            (  SELECT       /*+ PARALLEL(16)*/
                                                     ID_CTXT_TYP,
                                                        ISS_ID,
                                                        NVL (ISS_TENOR_TYP,'A'),
                                                        NVL (ISS_USAGE_TYP,'A'),
                                                        NVL (WHEN_ISSUED_IND,'A'),
                                                        NVL (TRDNG_CURR_CDE,'A'),
                                                        NVL (NOT_TRADABLE_IND,'A'),
                                                        NVL (MERGE_UNIQ_OID,'A'),
                                                        START_TMS
                                                 FROM   FT_T_ISID_BAK_GT134195
                                             GROUP BY   ID_CTXT_TYP,
                                                        ISS_ID,
                                                        ISS_TENOR_TYP,
                                                        ISS_USAGE_TYP,
                                                        WHEN_ISSUED_IND,
                                                        TRDNG_CURR_CDE,
                                                        NOT_TRADABLE_IND,
                                                        MERGE_UNIQ_OID,
                                                        START_TMS
                                               HAVING   COUNT ( * ) > 1)));

   VAR_CUR_ISID_U002   CUR_ISID_U002%ROWTYPE;
    V_REC  NUMBER;
BEGIN
     V_REC:=0;
   OPEN CUR_ISID_U002;

   LOOP
      FETCH CUR_ISID_U002 INTO   VAR_CUR_ISID_U002;

      EXIT WHEN CUR_ISID_U002%NOTFOUND;

      IF VAR_CUR_ISID_U002.RANK_ISID > 1
      THEN
         UPDATE   FT_T_ISID
            SET   START_TMS = (START_TMS - (VAR_CUR_ISID_U002.RANK_ISID - 1 - 0.02)),
                  LAST_CHG_USR_ID = 'GS:CON:134195:'||VAR_CUR_ISID_U002.LAST_CHG_USR_ID
          WHERE   ISID_OID = VAR_CUR_ISID_U002.ISID_OID;
          V_REC:=V_REC+1;
          COMMIT;
      END IF;
   END LOOP;

   CLOSE CUR_ISID_U002;
   DBMS_OUTPUT.PUT_LINE('UPDATED RECORDS AS A PART OF STEP2 ' || V_REC);
EXCEPTION
   WHEN OTHERS
   THEN
      raise_application_error (-20101, 'ISID migration is failed' || SQLCODE || SQLERRM);
END;
/


/* ENDATE DUPLICATE U001 RECORDS - START_TMS Exclusive*/
DECLARE
   CURSOR CUR_ISID_END_U001
   IS
      SELECT   *
        FROM   (SELECT   ISID_OID,LAST_CHG_USR_ID, 
                         DENSE_RANK ()
                            OVER (
                               PARTITION BY ID_CTXT_TYP,
                                            INSTR_ID,
                                            NVL (ISS_TENOR_TYP, 'A'),
                                            NVL (ISS_USAGE_TYP, 'A'),
                                            NVL (WHEN_ISSUED_IND, 'A'),
                                            NVL (TRDNG_CURR_CDE, 'A'),
                                            NVL (NOT_TRADABLE_IND, 'A')
                               ORDER BY LAST_CHG_TMS DESC,
                                                   START_TMS DESC,
                                                   ISID_OID
                            ) RANK_ISID
                  FROM   (SELECT                            /*+ PARALLEL(16)*/
                                A  .*
                            FROM   FT_T_ISID_BAK_GT134195 A
                           WHERE   A.END_TMS IS NULL
                                   AND (A.ID_CTXT_TYP,
                                        A.INSTR_ID,
                                        NVL (ISS_TENOR_TYP, 'A'),
                                        NVL (ISS_USAGE_TYP, 'A'),
                                        NVL (WHEN_ISSUED_IND, 'A'),
                                        NVL (TRDNG_CURR_CDE, 'A'),
                                        NVL (NOT_TRADABLE_IND, 'A')) IN
                                            (  SELECT       /*+ PARALLEL(16)*/
                                                     ID_CTXT_TYP,
                                                        INSTR_ID,
                                                        NVL (ISS_TENOR_TYP,'A'),
                                                        NVL (ISS_USAGE_TYP,'A'),
                                                        NVL (WHEN_ISSUED_IND,'A'),
                                                        NVL (TRDNG_CURR_CDE,'A'),
                                                        NVL (NOT_TRADABLE_IND,'A')
                                                 FROM   FT_T_ISID_BAK_GT134195
                                                WHERE   ID_CTXT_TYP = 'BBUNIQUE'  AND END_TMS IS NULL
                                             GROUP BY   ID_CTXT_TYP,
                                                        INSTR_ID,
                                                        ISS_TENOR_TYP,
                                                        ISS_USAGE_TYP,
                                                        WHEN_ISSUED_IND,
                                                        TRDNG_CURR_CDE,
                                                        NOT_TRADABLE_IND
                                               HAVING   COUNT ( * ) > 1))) WHERE RANK_ISID>1;

   
   VAR_CUR_ISID_END_U001   CUR_ISID_END_U001%ROWTYPE;
   V_REC  NUMBER;
BEGIN
     V_REC:=0;
     OPEN CUR_ISID_END_U001;

   LOOP
      FETCH CUR_ISID_END_U001 INTO   VAR_CUR_ISID_END_U001;

      EXIT WHEN CUR_ISID_END_U001%NOTFOUND;

      IF VAR_CUR_ISID_END_U001.RANK_ISID > 1
      THEN
         UPDATE   FT_T_ISID
            SET   END_TMS = SYSDATE,
                  LAST_CHG_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:CON:134195:'||VAR_CUR_ISID_END_U001.LAST_CHG_USR_ID
          WHERE   ISID_OID = VAR_CUR_ISID_END_U001.ISID_OID;
           V_REC:=V_REC+1;
                   COMMIT;
      END IF;
   END LOOP;

   CLOSE CUR_ISID_END_U001;
   DBMS_OUTPUT.PUT_LINE('UPDATED RECORDS AS A PART OF STEP3 ' || V_REC);
EXCEPTION
   WHEN OTHERS
   THEN
      raise_application_error (-20101, 'ISID migration is failed' || SQLCODE || SQLERRM);
END;
/

/* ENDATE DUPLICATE U002 RECORDS - START_TMS Exclusive*/
DECLARE
   CURSOR CUR_ISID_END_U002
   IS
      SELECT   *
        FROM   (SELECT   ISID_OID, LAST_CHG_USR_ID, 
                         DENSE_RANK ()
                            OVER (
                               PARTITION BY ID_CTXT_TYP,
                                            ISS_ID,
                                            NVL (ISS_TENOR_TYP, 'A'),
                                            NVL (ISS_USAGE_TYP, 'A'),
                                            NVL (WHEN_ISSUED_IND, 'A'),
                                            NVL (TRDNG_CURR_CDE, 'A'),
                                            NVL (NOT_TRADABLE_IND, 'A'),
                                            NVL (MERGE_UNIQ_OID, 'A')
                               ORDER BY LAST_CHG_TMS DESC,
                                                   START_TMS DESC,
                                                   ISID_OID
                            ) RANK_ISID
                  FROM   (SELECT                            /*+ PARALLEL(16)*/
                                A  .*
                            FROM   FT_T_ISID_BAK_GT134195 A
                             WHERE    A.END_TMS IS NULL
                                   AND (A.ID_CTXT_TYP,
                                        ISS_ID,
                                        NVL (ISS_TENOR_TYP, 'A'),
                                        NVL (ISS_USAGE_TYP, 'A'),
                                        NVL (WHEN_ISSUED_IND, 'A'),
                                        NVL (TRDNG_CURR_CDE, 'A'),
                                        NVL (NOT_TRADABLE_IND, 'A'),
                                        NVL (MERGE_UNIQ_OID, 'A')) IN
                                            (  SELECT       /*+ PARALLEL(16)*/
                                                     ID_CTXT_TYP,
                                                        ISS_ID,
                                                        NVL (ISS_TENOR_TYP,'A'),
                                                        NVL (ISS_USAGE_TYP,'A'),
                                                        NVL (WHEN_ISSUED_IND,'A'),
                                                        NVL (TRDNG_CURR_CDE,'A'),
                                                        NVL (NOT_TRADABLE_IND,'A'),
                                                        NVL (MERGE_UNIQ_OID,'A')
                                                 FROM   FT_T_ISID_BAK_GT134195
                                                WHERE   ID_CTXT_TYP = 'BBUNIQUE' AND END_TMS IS NULL
                                             GROUP BY   ID_CTXT_TYP,
                                                        ISS_ID,
                                                        ISS_TENOR_TYP,
                                                        ISS_USAGE_TYP,
                                                        WHEN_ISSUED_IND,
                                                        TRDNG_CURR_CDE,
                                                        NOT_TRADABLE_IND,
                                                        MERGE_UNIQ_OID
                                               HAVING   COUNT ( * ) > 1))) WHERE RANK_ISID>1;
                                               
   VAR_CUR_ISID_END_U002   CUR_ISID_END_U002%ROWTYPE;
   
   V_REC  NUMBER;
BEGIN
V_REC:=0;
      OPEN CUR_ISID_END_U002;

   LOOP
      FETCH CUR_ISID_END_U002 INTO   VAR_CUR_ISID_END_U002;

      EXIT WHEN CUR_ISID_END_U002%NOTFOUND;

      IF VAR_CUR_ISID_END_U002.RANK_ISID > 1
      THEN
         UPDATE   FT_T_ISID
            SET   END_TMS = SYSDATE,
                  LAST_CHG_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:CON:134195:'||VAR_CUR_ISID_END_U002.LAST_CHG_USR_ID
          WHERE   ISID_OID = VAR_CUR_ISID_END_U002.ISID_OID;
                V_REC:=V_REC+1;
     
          COMMIT;
      END IF;
   END LOOP;
   DBMS_OUTPUT.PUT_LINE('UPDATED RECORDS AS A PART OF STEP4 ' || V_REC);

   CLOSE CUR_ISID_END_U002;
EXCEPTION
   WHEN OTHERS
   THEN
      raise_application_error (-20101, 'ISID migration is failed' || SQLCODE || SQLERRM);
END;
/


/* Update ISID.MKT_OID as NULL records*/

DECLARE
  V_REC  NUMBER;
BEGIN

UPDATE /*+ PARALLEL(JOINVIEW) */
             (SELECT /*+ PARALLEL(T) PARALLEL(S) */
              T.MKT_OID AS OLD_MKT_OID,
              NULL AS NEW_MKT_OID,
              T.LAST_CHG_TMS AS OLD_LAST_CHG_TMS,
              SYSDATE AS NEW_LAST_CHG_TMS,
              T.LAST_CHG_USR_ID AS OLD_LAST_CHG_USR_ID,
              'GS:CON:134195:'||S.LAST_CHG_USR_ID AS NEW_LAST_CHG_USR_ID
              FROM    FT_T_ISID_BAK_GT134195 S, FT_T_ISID  T
                WHERE   T.ISID_OID = S.ISID_OID AND S.MKT_OID IS NOT NULL AND S.END_TMS IS NULL
               ) JOINVIEW
         SET   OLD_MKT_OID = NEW_MKT_OID,
               OLD_LAST_CHG_TMS=NEW_LAST_CHG_TMS,
               OLD_LAST_CHG_USR_ID=NEW_LAST_CHG_USR_ID;
 V_REC:=SQL%ROWCOUNT;
 COMMIT;              
DBMS_OUTPUT.PUT_LINE('UPDATED RECORDS AS A PART OF STEP5 ' || V_REC);

END;
/



/* Endate MIXR records*/
DECLARE
   CURSOR CUR_MIXR
   IS
      SELECT                                                /*+ PARALLEL(16)*/
            MIXR_OID, C.LAST_CHG_USR_ID
        FROM   FT_T_MIXR_BAK_GT134195  C,
               FT_T_ISID D
       WHERE   C.ISID_OID = D.ISID_OID
       AND     D.LAST_CHG_USR_ID LIKE '%GS:CON:134195%'
       AND     D.MKT_OID IS NULL;  

   TYPE TAB_CUR_MIXR IS TABLE OF CUR_MIXR%ROWTYPE;

   VAR_CUR_MIXR   TAB_CUR_MIXR;
BEGIN
   OPEN CUR_MIXR;

   LOOP
      FETCH CUR_MIXR BULK COLLECT INTO   VAR_CUR_MIXR LIMIT 10000;

      FORALL I IN 1 .. VAR_CUR_MIXR.COUNT
         UPDATE   FT_T_MIXR
            SET   END_TMS = SYSDATE,
                  LAST_CHG_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:CON:134195:'||VAR_CUR_MIXR(I).LAST_CHG_USR_ID
          WHERE   MIXR_OID = VAR_CUR_MIXR(I).MIXR_OID;
          
                COMMIT;
                
      EXIT WHEN CUR_MIXR%NOTFOUND;
   END LOOP;
   DBMS_OUTPUT.PUT_LINE('STEP6- MIXR END_DATE RECORDS COMPLETED');
   
   CLOSE CUR_MIXR;
EXCEPTION
   WHEN OTHERS
   THEN
      raise_application_error (-20101, 'MIXR migration is failed' || SQLCODE || SQLERRM);
END;
/


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20170421.sql', 1, 'GT134195',SYSDATE, '8.99.58.0', '8.99.61.0', 'A',  SYSDATE);  

COMMIT;