-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:91331
-- | Date: 2013-05-09
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Suvarna Rane 
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Migration script to update DAYS_MTH_BAS_TYP='IEM' to DAYS_MTH_BAS_TYP='I30E' where DAY_CNT_DESC is ISMA-30/ACT','ISMA-30/360' and 'ISMA-30/365.
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20130509_SELECT.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

UPDATE FT_T_IEDF SET DAYS_MTH_BAS_TYP='I30E', LAST_CHG_USR_ID='GS:MIG:91331:BBEXTDPF' WHERE DAY_CNT_DESC IN ('ISMA-30/ACT','ISMA-30/360','ISMA-30/365')AND LAST_CHG_USR_ID LIKE '%BBEXTDPF%' and DAYS_MTH_BAS_TYP='IEM';

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130509.sql', 1, 'GT#91331', TO_DATE( '05/09/2013 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.7.0', 'A',  SYSDATE);

SET DEFINE ON