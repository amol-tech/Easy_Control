SET DEFINE OFF;
-- | GT Ticket #:160637
-- | Date: 2020-01-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Kamini Shukla
-- | Approved By: Nilesh Desai
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Script to rollback the changes .
-- | Main Query:GSDM_Bloomberg_DL_Global_Equity_20200115.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_IEDF
   IS
      SELECT * FROM FT_T_IEDF_BAK_GT160637;

   TYPE TAB_IEDF IS TABLE OF CUR_IEDF%ROWTYPE;



   VAR_IEDF      TAB_IEDF;

   v_NumErrors   NUMBER (10);
BEGIN
   OPEN CUR_IEDF;

   LOOP
      FETCH CUR_IEDF
         BULK COLLECT INTO VAR_IEDF
         LIMIT 10000;



      FORALL I IN 1 .. VAR_IEDF.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_IEDF
            SET EV_DESC =  VAR_IEDF (I).EV_DESC,
                DAY_CNT_DESC = VAR_IEDF (I).DAY_CNT_DESC,
                LAST_CHG_TMS = VAR_IEDF (I).LAST_CHG_TMS,
                LAST_CHG_USR_ID = VAR_IEDF (I).LAST_CHG_USR_ID
          WHERE INC_EV_DEF_ID = VAR_IEDF (I).INC_EV_DEF_ID;

      COMMIT;
      EXIT WHEN CUR_IEDF%NOTFOUND;
   END LOOP;

   CLOSE CUR_IEDF;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;