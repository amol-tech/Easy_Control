SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #:443350
-- | GT Ticket #:106746
-- | Date: 2014-10-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Suvarna Rane
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISCL, FT_T_MICL
-- | Select Script name : GSDM_Bloomberg_DL_Global_Equity_20141030_SELECT.sql
-- | Change Reason: Migration script to end date ISCL records created for [LSE_SEGMENT] and [LSE_SECTOR] fields having INDUS_CL_SET_ID 'LSESEGMENT' and CLSF_PURP_TYP as 'INSUBTYP','INDCLASS'
-- |               and also to move the data of the latest ISCL active record into MICL table.
-- |----------------------------------------------------------------

DECLARE

    v_NumErrors     NUMBER(10);

    V_ERR_CODE      VARCHAR2(20);
    V_ERR_MSG       VARCHAR2(200);
    

   TYPE TR_TYPE IS TABLE OF FT_T_ISCL.ISS_CLSF_OID%TYPE;

    P_BULKCLEANUP   TR_TYPE;

   P_ARRAY_SIZE   NUMBER := 10000;

   CURSOR C
   IS
        SELECT  B.ISS_CLSF_OID
        FROM    FT_T_ISCL B
        WHERE   B.INDUS_CL_SET_ID = 'LSESEGMENT'
        AND     B.CLSF_PURP_TYP IN ('INSUBTYP','INDCLASS')
        AND     B.END_TMS IS NULL
        AND     EXISTS (SELECT 1
                        FROM    FT_T_ISID C
                        WHERE   B.INSTR_ID = C.INSTR_ID
                        AND     B.ISID_OID = C.ISID_OID
                        AND     C.ID_CTXT_TYP in ('TICKER', 'WI-TICKER'));

        
BEGIN
	

    -- FT_T_MICL

     INSERT INTO FT_T_MICL(MICL_OID, INDUS_CL_SET_ID, CLSF_OID, CL_VALUE, START_TMS, LAST_CHG_TMS, LAST_CHG_USR_ID, DATA_SRC_ID, MKT_ISS_OID, DATA_STAT_TYP)
        SELECT  DISTINCT NEW_OID(),
                INDUS_CL_SET_ID, CLSF_OID, CL_VALUE, START_TMS, SYSDATE, 'GS:MIG:BBEQEURO:106746', DATA_SRC_ID, MKT_ISS_OID, DATA_STAT_TYP
        FROM    (
                    SELECT  DISTINCT B.INDUS_CL_SET_ID, B.CLSF_OID, B.CL_VALUE, A.MKT_ISS_OID, B.LAST_CHG_USR_ID, B.START_TMS, B.LAST_CHG_TMS, B.DATA_SRC_ID, B.DATA_STAT_TYP,
                            ROW_NUMBER() OVER (PARTITION BY A.INSTR_ID, A.MKT_OID, B.INDUS_CL_SET_ID ORDER BY B.LAST_CHG_TMS DESC) CNT
                    FROM    FT_T_MKIS A,
                            FT_T_ISCL B,
                            FT_T_ISID C
                    WHERE   A.INSTR_ID = B.INSTR_ID
                    AND     B.INDUS_CL_SET_ID = 'LSESEGMENT'
                    AND     B.CLSF_PURP_TYP IN ('INSUBTYP','INDCLASS')
                    AND     B.ISID_OID = C.ISID_OID
                    AND     A.INSTR_ID = C.INSTR_ID
                    AND     B.INSTR_ID = C.INSTR_ID
                    AND     C.ID_CTXT_TYP in ('TICKER','WI-TICKER')
                    AND     A.MKT_OID = C.MKT_OID
                    AND     A.END_TMS IS NULL
                    AND     C.END_TMS IS NULL
                    AND     B.END_TMS IS NULL
                    )MKIS_ISCL
        WHERE   CNT = 1
        AND     NOT EXISTS (SELECT    1
                                    FROM    FT_T_MICL
                                    WHERE     MKIS_ISCL.INDUS_CL_SET_ID = INDUS_CL_SET_ID
                                    AND     MKIS_ISCL.CLSF_OID = CLSF_OID
                                    AND     MKIS_ISCL.CL_VALUE = CL_VALUE
                                    AND     MKIS_ISCL.MKT_ISS_OID = MKT_ISS_OID);
                                    
   
    
    DBMS_OUTPUT.PUT_LINE ('Before Bulk Collect : ' || SYSTIMESTAMP);


    OPEN C;

       LOOP
          FETCH C BULK COLLECT INTO   P_BULKCLEANUP LIMIT P_ARRAY_SIZE;

          FORALL I IN 1 .. P_BULKCLEANUP.COUNT SAVE EXCEPTIONS
                  
        --  FT_T_ISCL
                  
                  
             UPDATE  FT_T_ISCL
              SET   END_TMS = SYSDATE,
                    LAST_CHG_USR_ID = 'GS:MIG:BBEQEURO:106746'
              WHERE   ISS_CLSF_OID = P_BULKCLEANUP (I)
              AND       END_TMS IS NULL;
                      
                    
          COMMIT;

          EXIT WHEN C%NOTFOUND;
          
       END LOOP;

       CLOSE C;
           

     DBMS_OUTPUT.PUT_LINE ('After Bulk Collect : ' || SYSTIMESTAMP);
     
     
 --   COMMIT;

             
     Insert INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
        VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20141030.sql', 1, 'GT106746', SYSDATE, '8.99.1.0', '8.99.33.0', 'A',  SYSDATE);
        

           
     EXCEPTION
           WHEN OTHERS THEN
                     
             V_ERR_MSG := SUBSTR(SQLERRM,1,200);
                      
             DBMS_OUTPUT.PUT_LINE('Got exception: ' || V_ERR_MSG);
             v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
             DBMS_OUTPUT.PUT_LINE(
               'Number of errors during processing: ' || v_NumErrors);
                       
             FOR v_Count IN 1..v_NumErrors LOOP
                     
                V_ERR_MSG:=SUBSTR((SQLERRM(0 - SQL%BULK_EXCEPTIONS(v_Count).error_code)),1,150);
                           
                DBMS_OUTPUT.PUT_LINE('Error ' || v_Count || ', iteration ' ||
                 SQL%BULK_EXCEPTIONS(v_Count).error_index || ' is: ' ||V_ERR_MSG);
                         
             END LOOP;

      DBMS_OUTPUT.PUT_LINE ('After Bulk Collect : ' || SYSTIMESTAMP);
      
      


          
END;
/

   