-- |----------------------------------------------------------------
-- | Front Office #: 447653
-- | GT Ticket #: 118858
-- | Date: 2015-07-20
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Sushant Hole
-- | Approved By: Sapana Chaaparwal
-- |----------------------------------------------------------------
-- | Tables Affected : FT_CFG_VRET
-- | Change Reason: VRET insert needs to be provided for Issue type = Savings Share
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

INSERT INTO ft_cfg_vret (VND_RQST_TYP, EXT_ISS_TYP_TXT)
                 SELECT 'Equity','Savings Share'  FROM DUAL
                       WHERE NOT EXISTS (SELECT 1 FROM ft_cfg_vret WHERE VND_RQST_TYP = 'Equity' and EXT_ISS_TYP_TXT='Savings Share' );

SET DEFINE ON;