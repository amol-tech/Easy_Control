-- |----------------------------------------------------------------
-- | Front Office #: 448274
-- | GT Ticket #:120463
-- | Date: 2015-11-04
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pooja Munj
-- | Approved By: Prashant Zambre
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_INCL, FT_T_ISCL
-- | Change Reason: Script to fetch records from INCL which will get end dated and also updated for INDUS_CL_SET_ID = 'INDSUBGR' to 'BBINDSGR'.
-- |                Script to fetch records from ISCL which will get updated for INDUS_CL_SET_ID from 'INDSUBGR' to 'BBINDSGR' and CLSF_OID to the active INCL record.
-- |                ISCL Select statement will execute once INCL is updated.
-- |----------------------------------------------------------------
SET DEFINE OFF;

--- SELECT STATEMENT TO FETCH RECORDS WHICH WILL GET END DATED IN INCL.

SELECT   *
  FROM   FT_T_INCL a
 WHERE   EXISTS
            (  SELECT   b.CL_VALUE, b.INDUS_CL_SET_iD
                 FROM   FT_T_INCL b
                WHERE   b.INDUS_CL_SET_id = 'BBINDSGR'
                        AND a.CL_VALUE = b.CL_VALUE
             GROUP BY   b.CL_VALUE, b.INDUS_CL_SET_id)
         AND INDUS_CL_SET_ID = 'INDSUBGR'
         AND END_TMS IS NULL
         AND LAST_CHG_USR_ID = 'BBEXTDPF';

--- SELECT STATEMENT TO UPDATE STAND ALONE RECORDS IN INCL HAVING  INDUS_CL_SET_ID AS 'INDSUBGR ' TO 'BBINDSGR' FOR  LAST_CHG_USR_ID AS 'BBEXTDPF'.         
                   
select * from ft_t_incl                   
where END_TMS IS NULL
AND LAST_CHG_USR_ID = 'BBEXTDPF'  
and INDUS_CL_SET_id = 'INDSUBGR  '                  
and CLSF_OID not in (SELECT   CLSF_OID
  FROM   FT_T_INCL a
 WHERE   EXISTS
            (  SELECT   b.CL_VALUE, b.INDUS_CL_SET_iD
                 FROM   FT_T_INCL b
                WHERE   b.INDUS_CL_SET_id = 'BBINDSGR'
                        AND a.CL_VALUE = b.CL_VALUE
             GROUP BY   b.CL_VALUE, b.INDUS_CL_SET_id)
         AND INDUS_CL_SET_ID = 'INDSUBGR'
         AND END_TMS IS NULL
         AND LAST_CHG_USR_ID = 'BBEXTDPF');
         


-- SELECT STATEMENT TO FETCH ISCL RECORDS WHICH WILL GET UPDATED. 
-- THIS STATEMENT WILL RUN ONLY WHEN INCL IS END DATAED AND UPDATED WITH 'BBINDSGR'.

select * from FT_T_ISCL 
where CLSF_OID in(SELECT CLSF_OID FROM FT_T_INCL WHERE END_TMS IS NOT NULL AND LAST_CHG_USR_ID LIKE '%120463%')
and LAST_CHG_USR_ID = 'BBEXTDPF';

--- SELECT STATEMENT TO FETCH RECORDS FROM INCL WHOES CLSF_OID IS ACTIVE WHICH SHOULD BE UPDATED IN INCS HAVING CL_NAME COMMON 
--- AND WHOES CORRESPONDING CLSF_OID IS END DATED.
select   * 
from    (select CLSF_OID,INDUS_CL_SET_ID,CL_VALUE,LEVEL_NUM,LAST_CHG_USR_ID,CL_NME,last_chg_tms, row_number() over 
                  (partition by CL_VALUE order by last_chg_tms desc)cnt
                 from ft_t_incl 
                 where INDUS_CL_SET_ID = 'BBINDSGR')x   
         where   cnt = 1
and     INDUS_CL_SET_ID = 'BBINDSGR'
and     LAST_CHG_USR_ID not like '%120463%';

SET DEFINE ON;


                 
    