-- |----------------------------------------------------------------
-- | Front Office #:438240
-- | GT Ticket #:87299
-- | Date: 2013-01-18
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Prashant Zambre	
-- | Approved By: Rajeshwari Chandramouli
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: To end date duplicate ISID row present for ID_CTXT_TYP=BBTRDGSYMB, for the same instrument and same market and same issue usage type
--                  and retain only the latest row among the duplicates.
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update ft_t_isid
set end_tms = sysdate,
last_chg_usr_id = 'GS:MIG:87299:BB'
where isid_oid in (SELECT ISID_OID FROM
(SELECT ISID_OID,instr_id,mkt_oid,ISS_USAGE_TYP,LAST_CHG_TMS ,row_number()                     
over(partition by instr_id,mkt_oid,ISS_USAGE_TYP,ID_CTXT_TYP ORDER BY LAST_CHG_TMS desc)cnt
FROM ft_t_isid WHERE ID_CTXT_TYP = 'BBTRDGSYMB') where cnt !=1);


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20130125.sql', 1, 'GT#87299',SYSDATE, '8.99.0.40', '8.99.0.43', 'A',  SYSDATE);

SET DEFINE ON;