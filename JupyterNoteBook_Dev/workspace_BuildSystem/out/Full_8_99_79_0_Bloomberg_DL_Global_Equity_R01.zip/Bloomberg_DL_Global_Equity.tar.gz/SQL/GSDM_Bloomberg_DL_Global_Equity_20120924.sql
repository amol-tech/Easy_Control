-- |----------------------------------------------------------------
-- | Front Office #: 
-- | GT #: 81255
-- | Date: 2012-09-21
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Swapnali Jadhav
-- | Approved By: Chandramouli Rajeshwari
-- |----------------------------------------------------------------
-- | Tables Affected: ISCL
-- |
-- | Change Reason: Migration script to update the CLSFPURTYP from "INDCLASS" to "BBISSTYP".

-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update FT_T_ISCL  set CLSF_PURP_TYP='BBISSTYP',LAST_CHG_USR_ID='GS:MIG:81255:BB' where clsf_oid in (select CLSF_OID from fT_T_incl where level_num='1' and INDUS_CL_SET_ID='BBSECTYP' and LAST_CHG_usr_id like 'BB%') and CLSF_PURP_TYP='INDCLASS';

Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20120924.sql', 1, 'GT#81255', TO_DATE( '07/25/2010 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), '8.99.0.1', '8.99.0.35', 'A',  SYSDATE);

SET DEFINE ON;