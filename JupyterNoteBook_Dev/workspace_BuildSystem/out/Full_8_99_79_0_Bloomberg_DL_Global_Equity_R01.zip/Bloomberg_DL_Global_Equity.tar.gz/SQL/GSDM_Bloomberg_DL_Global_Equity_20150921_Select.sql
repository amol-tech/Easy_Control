SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #: 447816
-- | GT Ticket #:120400
-- | Date: 2015-09-21
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sushant Hole
-- | Approved By: Sapana Chaaparwal
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason:Migration provided where ISID with BBCPGLOBAL and BBGLOBAL and MKT_OID = 'EXCH=00117' will get aligned with MKT_OID = '0001W2LM0m'. 
-- |----------------------------------------------------------------

SET DEFINE OFF;


    SELECT * FROM FT_T_ISID
    WHERE MKT_OID = 'EXCH=00117' AND ID_CTXT_TYP IN ('CPGLOBAL','BBGLOBAL');
   
SET DEFINE ON;