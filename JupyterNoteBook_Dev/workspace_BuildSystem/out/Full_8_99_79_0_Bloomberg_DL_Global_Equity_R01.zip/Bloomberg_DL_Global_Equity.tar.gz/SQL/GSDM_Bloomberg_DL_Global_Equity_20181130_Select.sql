
SET DEFINE OFF;
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | FrontOffice ID: 461733
-- | GT Ticket #: 151138
-- | Date: 2018-11-30
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Mihir Sabnis
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Tables Affected:FT_T_ISST
-- | Change Reason: Script to fetch ISST records which have been set up with single instrument with STAT_DEF_ID='POSEURPR'
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181031.sql
-- |--------------------------------------------------------------------------------------------------------------------------------

SELECT *
  FROM FT_T_ISST
 WHERE STAT_DEF_ID = 'POSEURPR'
   AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
   AND END_TMS IS NULL;

SET DEFINE ON;