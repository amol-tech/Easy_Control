-- |----------------------------------------------------------------
-- | Front Office #:438759
-- | GT Ticket #:101712
-- | Date: 2014-02-06
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Divya Poojari
-- | Approved By: Abhijeet Dhuru
-- | Change Reason: To nullify the mkt_oid for the ID_CTXT_TYP as BBUNIQUE.
-- |----------------------------------------------------------------
set define off;

--1) script to endate dupicate rows where mkt_oid is not null

update FT_T_isid isid set isid.END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF'  where isid_oid in                                                                                                                 
(SELECT ISID_OID FROM (SELECT ISID_OID,INSTR_ID,ISS_ID,LAST_CHG_TMS,row_number()                                                                                                                             
over(partition by INSTR_ID,ISS_ID ORDER BY LAST_CHG_TMS desc) cnt                                                                                                                   
FROM FT_T_ISID WHERE ID_CTXT_TYP='BBUNIQUE'  and mkt_oid is not null and END_TMS is NULL ) where cnt !=1 and END_TMS is NULL )
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')))
and id_ctxt_typ='BBUNIQUE'  ;  


--2) script to endate dupicate rows where mkt_oid is null 

update FT_T_isid isid set isid.END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where isid_oid in                                                                                                                 
(SELECT ISID_OID FROM (SELECT ISID_OID,INSTR_ID,ISS_ID,LAST_CHG_TMS,row_number()                                                                                                                             
over(partition by INSTR_ID,ISS_ID ORDER BY LAST_CHG_TMS desc) cnt                                                                                                                   
FROM FT_T_ISID WHERE ID_CTXT_TYP='BBUNIQUE'  and mkt_oid is null and END_TMS is NULL ) where cnt !=1 and END_TMS is NULL )
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')))
and id_ctxt_typ='BBUNIQUE'  ;  


--3)Script to endate  ISID rows for BBUNIQUE with market when there exist a row without market.

update FT_T_isid b set b.END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where ISid_OID in (select ISid_OID from fT_T_isid a where exists (select 1 from fT_T_isid where instr_id =a.instr_id  and iss_id=a.iss_id  and end_tms is null
 and mkt_oid is null) and exists ( select 1 from fT_T_isid where  instr_id =a.instr_id  and iss_id=a.iss_id and end_tms is null
and mkt_oid is not null)and mkt_oid is not null  ) and end_tms is null and id_ctxt_typ='BBUNIQUE'
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')));


--4)Script to nullify mkt_oid of a BBUNIQUE row provided ther does not exist a row with same ISS_ID.

update fT_T_isid a set mkt_oid=null,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id ) =1 and mkt_oid is not null and end_tms is null and id_ctxt_typ='BBUNIQUE'
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')));


--5)Script to activate endated isid row without market when there exist an active row present with market

update ft_T_isid isid set end_tms=null,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where mkt_oid is null AND ID_CTXT_TYP='BBUNIQUE' and  END_TMS IS NOT NULL AND exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is not null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE' and end_tms is null  )                                                                                                 
AND not exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is null and end_tms is null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE')
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')))
and instr_id not in (select instr_id from fT_T_isid a where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id and a.instr_id!=b.instr_id and a.start_tms=b.start_tms  AND ID_CTXT_TYP='BBUNIQUE' )>=1);


--6)Script to endate active isid row with market when there exist an active row without market.

update FT_T_isid isid set END_TMS=SYSDATE,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where mkt_oid is not null AND ID_CTXT_TYP='BBUNIQUE' and  exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is not null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE' and end_tms is null  )                                                                                                 
AND  exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is null and end_tms is null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE')
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty'))) 
and instr_id not in (select instr_id from fT_T_isid a where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id and a.instr_id!=b.instr_id and a.start_tms=b.start_tms AND ID_CTXT_TYP='BBUNIQUE'  )>=1);


--7) Script to nullify an isid row provided there does not exist an isid row without market

update FT_T_isid isid set mkt_oid=null,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF'  where mkt_oid is not null AND ID_CTXT_TYP='BBUNIQUE' and end_tms is null and exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is not null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE' and end_tms is null  )                                                                                                 
AND  exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is not null and end_tms is not null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE')
AND not exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is  null and isid.start_tms=start_tms and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE')
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty'))) 
and instr_id not in (select instr_id from fT_T_isid a where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id and a.instr_id!=b.instr_id and a.start_tms=b.start_tms AND ID_CTXT_TYP='BBUNIQUE'  )>=1);

--8)Script to nullify iss_usage_typ of active ISID rows migrated with above scripts

update FT_T_isid isid set iss_usage_typ=null,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' where isid_oid in (select isid_oid from FT_T_isid where end_tms is null  and mkt_oid is null and iss_usage_typ is not null and id_ctxt_typ='BBUNIQUE'
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty')))
and instr_id not in (select instr_id from fT_T_isid a where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id and a.instr_id!=b.instr_id and a.start_tms=b.start_tms AND ID_CTXT_TYP='BBUNIQUE'  )>=1)
AND not exists (select 'x' from ft_t_isid where                                                                                                                                                                                                                 
mkt_oid is  null and end_tms is  null and isid.iss_id=iss_id  AND isid.instr_id =instr_id and id_ctxt_typ='BBUNIQUE' and iss_usage_typ is null));

--9)Script to nullify mkt_oid of active ISID rows for same BBUNIQUE linked with multiple securities.
update FT_T_isid a set mkt_oid = null,last_chg_usr_id='GS:CON:101712:BBEXTDPF' where (select count(*) from fT_t_isid b where a.iss_id=b.iss_id and a.instr_id!=b.instr_id and a.start_tms!=b.start_tms ) >=1
and instr_id in (select instr_id from ft_t_iscl where clsf_oid in (select clsf_oid from ft_t_incl where  indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty'))) and id_ctxt_typ='BBUNIQUE' and end_tms is  null and mkt_oid is not null
AND not exists (select 'x' from ft_t_isid c where                                                                                                                                                                                                                 
mkt_oid is null and a.iss_id=c.iss_id and a.instr_id!=c.instr_id and a.start_tms=c.start_tms and c.id_ctxt_typ='BBUNIQUE');

    
--10)Script to endate mixrs for endated isids from above scripts
update FT_T_mixr set end_tms=SYSDATE,LAST_CHG_USR_ID='GS:CON:101712:BBEXTDPF' WHERE ISID_OID IN (select ISID_OID from  fT_t_isid  where instr_id in (select instr_id from ft_t_iscl 
where clsf_oid in (select clsf_oid from ft_t_incl where indus_cl_set_id='BBMKTSCT' and cl_nme in ('Govt','Pfd','Corp', 'Mtge', 'Muni','ComdtyFut','ComdtyOpt','Comdty'))) 
and id_ctxt_typ='BBUNIQUE' and LAST_CHG_USR_ID LIKE '%GS:CON:101712:BBEXTDPF%')   and end_tms is null ;




Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20140206.sql', 1, '101712',SYSDATE, '8.99.1.0', '8.99.23.0', 'A',  SYSDATE);    


 set define on;
 