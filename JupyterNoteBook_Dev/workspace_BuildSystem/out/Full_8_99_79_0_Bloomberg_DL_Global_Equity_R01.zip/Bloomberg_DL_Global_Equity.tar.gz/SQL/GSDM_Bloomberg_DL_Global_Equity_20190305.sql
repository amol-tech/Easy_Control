SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462389
-- | GT Ticket #:154683
-- | Date: 2019-03-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISMC
-- | Change Reason:Script to create rows in ISMC against ISST.STAT_DEF_ID = 'SHROUTOT'
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190305_Select.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISMC
   IS
      SELECT INSTR_ID, STAT_DEF_ID, STAT_VAL_CAMT
        FROM FT_T_ISST ISST
       WHERE     END_TMS IS NULL
             AND STAT_DEF_ID = 'SHROUTOT'
             AND STAT_VAL_CAMT IS NOT NULL
             AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
             AND NOT EXISTS
                        (SELECT 'X'
                           FROM FT_T_ISMC ISMC
                          WHERE     ISMC.INSTR_ID = ISST.INSTR_ID
                                AND ISMC.CAP_SEC_CQTY = ISST.STAT_VAL_CAMT
                                AND ISMC.CAPITAL_TYP = 'CSEQSHS'
                                AND END_TMS IS NULL);

   TYPE TYP_ISMC IS TABLE OF CUR_ISMC%ROWTYPE;

   VAR_ISMC      TYP_ISMC;
   V_NUMERRORS   NUMBER (10);
BEGIN
   OPEN CUR_ISMC;

   LOOP
      FETCH CUR_ISMC
         BULK COLLECT INTO VAR_ISMC
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISMC.COUNT SAVE EXCEPTIONS
         INSERT INTO FT_T_ISMC (ISMC_OID,
                                INSTR_ID,
                                CAPITAL_TYP,
                                START_TMS,
                                DATA_STAT_TYP,
                                DATA_SRC_ID,
                                LAST_CHG_TMS,
                                LAST_CHG_USR_ID,
                                CAP_SEC_CQTY)
              VALUES (NEW_OID (),
                      VAR_ISMC (I).INSTR_ID,
                      'CSEQSHS',
                      TRUNC (SYSDATE),
                      'ACTIVE',
                      'BB',
                      SYSDATE,
                      'GS:CON:154683:BBEQEURO',
                      VAR_ISMC (I).STAT_VAL_CAMT);

      COMMIT;
      EXIT WHEN CUR_ISMC%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISMC;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20190305.sql',
             1,
             'GT154683',
             SYSDATE,
             '8.99.61.2',
             '8.99.74.4',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;