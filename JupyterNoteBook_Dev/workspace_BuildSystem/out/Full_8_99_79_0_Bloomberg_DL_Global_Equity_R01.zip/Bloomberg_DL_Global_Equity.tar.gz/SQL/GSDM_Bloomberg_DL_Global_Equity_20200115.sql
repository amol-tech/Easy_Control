SET DEFINE OFF;
-- | GT Ticket #:160637
-- | Date: 2020-01-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Kamini Shukla
-- | Approved By: Nilesh Desai
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Script to remove '-----' from IEDF.EV_DESC and IEDF.DAY_CNT_DESC.
-- | Main Query:GSDM_Bloomberg_DL_Global_Equity_20200115.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_T_IEDF_BAK_GT160637
AS
   SELECT *
  FROM FT_T_IEDF
 WHERE    EV_DESC IN
             (''ISDA 30E/360-----'', ''ISDA 30E/365-----'', ''ISDA 30E/ACT-----'')
       OR DAY_CNT_DESC IN
             (''ISDA 30E/360-----'', ''ISDA 30E/365-----'', ''ISDA 30E/ACT-----'')';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_IEDF_BAK_GT160637 ADD CONSTRAINT FT_T_IEDF_BAK_GT160637  PRIMARY KEY (INC_EV_DEF_ID)';
END;

DECLARE
   CURSOR CUR_IEDF
   IS
      SELECT * FROM FT_T_IEDF_BAK_GT160637;

   TYPE TAB_IEDF IS TABLE OF CUR_IEDF%ROWTYPE;



   VAR_IEDF      TAB_IEDF;

   v_NumErrors   NUMBER (10);
BEGIN
   OPEN CUR_IEDF;

   LOOP
      FETCH CUR_IEDF
         BULK COLLECT INTO VAR_IEDF
         LIMIT 10000;



      FORALL I IN 1 .. VAR_IEDF.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_IEDF
            SET EV_DESC = REPLACE (EV_DESC, '-----', ''),
                DAY_CNT_DESC = REPLACE (DAY_CNT_DESC, '-----', ''),
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID =
                   'GS:CON:160637' || VAR_IEDF (I).LAST_CHG_USR_ID
          WHERE INC_EV_DEF_ID = VAR_IEDF (I).INC_EV_DEF_ID;

      COMMIT;
      EXIT WHEN CUR_IEDF%NOTFOUND;
   END LOOP;

   CLOSE CUR_IEDF;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20200115.sql',
             1,
             'GT 160637',
             SYSDATE,
             '8.99.76.0',
             '8.99.76.3',
             'A',
             SYSDATE);

COMMIT;

SET DEFINE ON;