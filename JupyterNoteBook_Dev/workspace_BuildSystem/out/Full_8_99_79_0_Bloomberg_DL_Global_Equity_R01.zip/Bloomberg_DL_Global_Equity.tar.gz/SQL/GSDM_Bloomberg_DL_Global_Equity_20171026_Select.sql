SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #:141102
-- | Date: 2017-10-26
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RGCH
-- | Change Reason: Script to retrieve RGCH records.
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171026.sql
-- |----------------------------------------------------------------

-- |NOTE :- Migration script is applicable only when the CCO RecordRegInfoForGeoRegion is set to NO.

SELECT   *
  FROM   FT_T_RGCH A
 WHERE   END_TMS IS NULL;

SET DEFINE ON;