SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 464164
-- | GT Ticket #: 156691
-- | Date: 2019-07-15
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Nilesh Desai
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID, FT_T_IBMR
-- | Change Reason: Script to endate the ISID's been created with null ISS_USAGE_TYP in FT_T_ISID, thereby updating the INSTR_ID in FT_T_IBMR to the one for which the BBIDXTKR ISID is present with ISS_USAGE_TYP (i.e. the one being left as ACTIVE).
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20190715_Select.sql
-- |----------------------------------------------------------------


BEGIN

    EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISID_BKP_156691
                        AS
                        SELECT  *
                        FROM    FT_T_ISID
                        WHERE   (ISS_ID,ID_CTXT_TYP) IN (
                                            SELECT  ISS_ID,ID_CTXT_TYP
                                            FROM    FT_T_ISID
                                            WHERE   ID_CTXT_TYP = ''BBIDXTKR''
                                            AND     END_TMS IS NULL
                                            GROUP BY ISS_ID,ID_CTXT_TYP
                                            HAVING COUNT(1) > 1)
                        AND     ID_CTXT_TYP = ''BBIDXTKR''
                        AND     END_TMS IS NULL
                        AND     ISS_USAGE_TYP IS NULL';
                        
    EXECUTE IMMEDIATE 'ALTER TABLE FT_T_ISID_BKP_156691 ADD CONSTRAINT FT_T_ISID_BKP_156691_PK  PRIMARY KEY (ISID_OID)';
    
    EXECUTE IMMEDIATE 'CREATE TABLE FT_T_IBMR_BKP_156691 AS
                        SELECT  DISTINCT B.*
                        FROM    FT_T_ISID A,
                                FT_T_IBMR B
                        WHERE   A.INSTR_ID = B.INSTR_ID
                        AND     A.ID_CTXT_TYP = ''BBIDXTKR''
                        AND     A.ISS_USAGE_TYP IS NULL
                        AND     B.END_TMS IS NULL
                        AND     (A.ISS_ID,ID_CTXT_TYP) IN ( 
                                        SELECT  ISS_ID,
                                                ID_CTXT_TYP
                                        FROM    FT_T_ISID
                                        WHERE   (ISS_ID, ID_CTXT_TYP) IN (
                                                                        SELECT  DISTINCT C.ISS_ID,
                                                                                C.ID_CTXT_TYP
                                                                        FROM    FT_T_ISID C,
                                                                                FT_T_IBMR D
                                                                        WHERE   C.INSTR_ID = D.INSTR_ID
                                                                        AND     C.ID_CTXT_TYP = ''BBIDXTKR''
                                                                        AND     C.ISS_USAGE_TYP IS NULL
                                                                        INTERSECT
                                                                        SELECT  DISTINCT C.ISS_ID,
                                                                                C.ID_CTXT_TYP
                                                                        FROM    FT_T_ISID C,
                                                                                FT_T_IBMR D
                                                                        WHERE   C.INSTR_ID = D.INSTR_ID
                                                                        AND     C.ID_CTXT_TYP = ''BBIDXTKR''
                                                                        AND     C.ISS_USAGE_TYP IS NOT NULL)
                                        AND     ID_CTXT_TYP = ''BBIDXTKR''
                                        GROUP BY ISS_ID, ID_CTXT_TYP
                                        HAVING COUNT(1) > 1)';
                        
    EXECUTE IMMEDIATE   'ALTER TABLE FT_T_IBMR_BKP_156691 ADD CONSTRAINT FT_T_IBMR_BKP_156691_PK  PRIMARY KEY (IBMR_OID)';
    
    EXECUTE IMMEDIATE 'CREATE TABLE FT_T_IBMR_BKP_156691_2 AS 
                        SELECT  Y.*, X.INSTR_ID AS ACTIVE_INSTR_ID
                        FROM    (   SELECT  B.*,
                                            (   SELECT  C.INSTR_ID
                                                FROM    FT_T_ISID C
                                                WHERE   B.ISS_ID = C.ISS_ID
                                                AND     C.ID_CTXT_TYP = ''BBIDXTKR''
                                                AND     C.ISS_USAGE_TYP IS NULL) AS INACTIVE_INSTR_ID
                                    FROM    FT_T_ISID B
                                    WHERE   (B.ISS_ID, B.ID_CTXT_TYP) IN (
                                                                SELECT  ISS_ID,ID_CTXT_TYP
                                                                FROM    FT_T_ISID
                                                                WHERE   ID_CTXT_TYP = ''BBIDXTKR''
                                                                AND     END_TMS IS NULL
                                                                GROUP BY ISS_ID,ID_CTXT_TYP
                                                                HAVING COUNT(1) > 1)
                                    AND     NOT EXISTS (SELECT  ''X''
                                                        FROM    FT_T_IBMR C
                                                        WHERE   B.INSTR_ID = C.INSTR_ID)
                                    AND     ID_CTXT_TYP = ''BBIDXTKR'') X,
                                    FT_T_IBMR Y
                        WHERE   X.INACTIVE_INSTR_ID = Y.INSTR_ID
                        AND     Y.END_TMS IS NULL';
                                            
    EXECUTE IMMEDIATE   'ALTER TABLE FT_T_IBMR_BKP_156691_2 ADD CONSTRAINT FT_T_IBMR_BKP_156691_2_PK  PRIMARY KEY (IBMR_OID)';
    
END;


DECLARE

    CURSOR CUR_ISID IS
    
        SELECT  *
        FROM    FT_T_ISID_BKP_156691;
        
    TYPE TYP_CUR_ISID   IS TABLE OF CUR_ISID%ROWTYPE;
        
    V_BULK_TYPE_ISID     TYP_CUR_ISID;
    
    CURSOR CUR_IBMR IS
    
        SELECT  *
        FROM    FT_T_IBMR_BKP_156691;
        
    TYPE TYP_CUR_IBMR   IS TABLE OF CUR_IBMR%ROWTYPE;
        
    V_BULK_TYPE_IBMR     TYP_CUR_IBMR;
    
    
    CURSOR CUR_IBMR_INSTR IS
    
        SELECT  *
        FROM    FT_T_IBMR_BKP_156691_2;
        
    TYPE TYP_CUR_IBMR_INSTR   IS TABLE OF CUR_IBMR_INSTR%ROWTYPE;
        
    V_BULK_TYPE_IBMR_INSTR     TYP_CUR_IBMR_INSTR;
    
    V_NUMERRORS    NUMBER (10);
    
    

BEGIN

    OPEN CUR_IBMR;
    
    LOOP
    
        FETCH CUR_IBMR BULK COLLECT INTO  V_BULK_TYPE_IBMR LIMIT 1000;
        
        FORALL I IN 1..V_BULK_TYPE_IBMR.COUNT SAVE EXCEPTIONS
        
            UPDATE  FT_T_IBMR
            SET     END_TMS = SYSDATE,
                    LAST_CHG_USR_ID = 'GS:CON:156691:'|| V_BULK_TYPE_IBMR(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = SYSDATE
            WHERE   IBMR_OID = V_BULK_TYPE_IBMR(I).IBMR_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_IBMR%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_IBMR;
   
   
    OPEN CUR_ISID;
    
    LOOP
    
        FETCH CUR_ISID BULK COLLECT INTO V_BULK_TYPE_ISID LIMIT 1000;
    
        FORALL I IN 1..V_BULK_TYPE_ISID.COUNT SAVE EXCEPTIONS 
        
            UPDATE  FT_T_ISID
            SET     END_TMS = SYSDATE,
                    LAST_CHG_USR_ID = 'GS:CON:156691:'|| V_BULK_TYPE_ISID(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = SYSDATE
            WHERE   ISID_OID = V_BULK_TYPE_ISID(I).ISID_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_ISID%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_ISID;
    
    
    OPEN CUR_IBMR_INSTR;
    
    LOOP
    
        FETCH CUR_IBMR_INSTR BULK COLLECT INTO V_BULK_TYPE_IBMR_INSTR LIMIT 1000;
    
        FORALL I IN 1..V_BULK_TYPE_IBMR_INSTR.COUNT SAVE EXCEPTIONS 
        
            UPDATE  FT_T_IBMR
            SET     INSTR_ID = V_BULK_TYPE_IBMR_INSTR(I).ACTIVE_INSTR_ID,
                    LAST_CHG_USR_ID = 'GS:CON:156691:'|| V_BULK_TYPE_IBMR_INSTR(I).LAST_CHG_USR_ID,
                    LAST_CHG_TMS = SYSDATE
            WHERE   IBMR_OID = V_BULK_TYPE_IBMR_INSTR(I).IBMR_OID;
            
            COMMIT;
            
        EXIT WHEN CUR_IBMR_INSTR%NOTFOUND;
        
        END LOOP;
        
    CLOSE CUR_IBMR_INSTR;

    EXCEPTION
       WHEN OTHERS
       THEN
          DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
          V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
          DBMS_OUTPUT.PUT_LINE (
             'Number of errors during processing: ' || V_NUMERRORS);

          FOR v_Count IN 1 .. V_NUMERRORS
          LOOP
             DBMS_OUTPUT.PUT_LINE (
                   'Error '
                || v_Count
                || ', iteration '
                || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
                || ' is: '
                || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
          END LOOP;
END;


INSERT INTO FT_O_SCTL (
							  PATCH_ID,
							  PATCH_SEQ_NUM,
							  PATCH_ID_CTXT_TYP,
							  RELEASE_TMS,
							  BASE_MODL_VER_ID,
							  CURR_MODL_VER_ID,
							  PATCH_STAT_TYP,
							  PATCH_APPLIED_TMS
			   )
	  VALUES   (
				   'GSDM_Bloomberg_DL_Global_Equity_20190715.sql',
				   1,
				   'GT156691',
				   SYSDATE,
				   '8.99.75.1',
				   '8.99.75.3',
				   'A',
				   SYSDATE
			   );		  
	COMMIT;

SET DEFINE ON;