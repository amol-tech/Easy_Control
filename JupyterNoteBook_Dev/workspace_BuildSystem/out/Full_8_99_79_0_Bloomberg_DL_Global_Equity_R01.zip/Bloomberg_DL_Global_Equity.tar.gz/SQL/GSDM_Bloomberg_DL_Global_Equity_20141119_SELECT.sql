-- |----------------------------------------------------------------
-- | Front Office #:NA
-- | GT Ticket #:111712
-- | Date: 2014-11-19
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Bhuvanesh Mavatkar
-- | Approved By: Abhijeet Dhuru
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_RISS
-- | Main Query Patch Name - GSDM_Bloomberg_DL_Global_Equity_20141119.sql
-- | Change Reason: 1. To end date the duplicate entries present in RISS provided REL_TYP is CONV in RIDF table.
-- | 								2. To Remove the value of END_TMS if only single future ENDATED RISS segment is present against a single RIDF where RIDF.REL_TYP as CONV
-- |								3. In case of Multiple future ENDATED RISS segment is present against a single RIDF, then keep the latest records end_tms as Null and enddate the other records with timestamp
-- | 
-- |----------------------------------------------------------------


SET DEFINE OFF;


(SELECT   *
   FROM   (SELECT   riss_oid,
                    RLD_ISS_FEAT_ID,
                    INSTR_ID,
                    PART_UNITS_TYP,
                    last_chg_usr_id,
                    ROW_NUMBER ()
                       OVER (
                          PARTITION BY RLD_ISS_FEAT_ID,
                                       INSTR_ID,
                                       PART_UNITS_TYP
                          ORDER BY last_chg_tms DESC
                       )
                       cnt
             FROM   ft_T_riss a
            WHERE   end_tms > SYSDATE
                    AND EXISTS
                          (SELECT   'X'
                             FROM   ft_T_ridf b
                            WHERE   a.RLD_ISS_FEAT_ID = b.RLD_ISS_FEAT_ID
                                    AND b.REL_TYP = 'CONV')));


(SELECT   *
   FROM  (SELECT   riss_oid,
                    RLD_ISS_FEAT_ID,
                    INSTR_ID,
                    PART_UNITS_TYP,
                    last_chg_usr_id,
                                   ROW_NUMBER ()
                                      OVER (
                                         PARTITION BY RLD_ISS_FEAT_ID,
                                                      INSTR_ID,
                                                      PART_UNITS_TYP
                                         ORDER BY last_chg_tms DESC
                                      )
                                      cnt
                            FROM   ft_T_riss a
                           WHERE   end_tms IS NULL
                                   AND EXISTS
                                         (SELECT   'X'
                                            FROM   ft_T_ridf b
                                           WHERE   a.RLD_ISS_FEAT_ID =
                                                      b.RLD_ISS_FEAT_ID
                                                   AND b.REL_TYP = 'CONV'))
                 WHERE   cnt != 1);

SET DEFINE ON;