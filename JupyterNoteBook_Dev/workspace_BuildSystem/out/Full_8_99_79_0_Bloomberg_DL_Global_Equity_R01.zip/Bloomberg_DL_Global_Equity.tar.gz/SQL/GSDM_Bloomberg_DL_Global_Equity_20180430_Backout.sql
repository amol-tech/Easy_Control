SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | FrontOffice ID: 456382
-- | GT Ticket #: 138745
-- | Date: 2018-04-30
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISST
-- | Change Reason: Script to rollback the changes made by script GSDM_Bloomberg_DL_Global_Equity_20180430.sql
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20180430.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISST
   IS
      SELECT * FROM FT_T_ISST_BKP_138745;

   TYPE TAB_ISST IS TABLE OF CUR_ISST%ROWTYPE;

   VAR_ISST      TAB_ISST;

   v_NumErrors   NUMBER (10);
BEGIN
   OPEN CUR_ISST;

   LOOP
      FETCH CUR_ISST
         BULK COLLECT INTO VAR_ISST
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISST.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISST
            SET DENOM_CURR_CDE = VAR_ISST (I).DENOM_CURR_CDE,
                LAST_CHG_TMS = VAR_ISST (I).LAST_CHG_TMS,
                LAST_CHG_USR_ID = VAR_ISST (I).LAST_CHG_USR_ID,
                END_TMS = VAR_ISST (I).END_TMS,
                START_TMS = VAR_ISST (I).START_TMS
          WHERE STAT_ID = VAR_ISST (I).STAT_ID;


      COMMIT;

      EXIT WHEN CUR_ISST%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISST;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;