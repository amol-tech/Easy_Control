SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 463543
-- | GT Ticket #: 153620
-- | Date: 2019-02-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Connections
-- | Requested By: Nusrat Khan
-- | Approved By: Neha Chaturvedi
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Script to move end-dated data from ISID.ISID_OID to ISID.MERGE_UNIQ_OID for BBUNIQUE and TICKER.
-- |
-- |----------------------------------------------------------------


BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISID_BAK_153620
AS
   (SELECT *
	FROM (SELECT A.*,
               ROW_NUMBER ()
               OVER (
                  PARTITION BY INSTR_ID,
                               MKT_OID,
                               ISS_ID,
                               ISS_USAGE_TYP,
                               START_TMS
                  ORDER BY END_TMS DESC)
                  COUNT
          FROM FT_T_ISID A
         WHERE     LAST_CHG_USR_ID IN (''BBGLMFND'', ''BBEQEURO'')
               AND ID_CTXT_TYP IN (''BBUNIQUE'', ''TICKER''))
	WHERE COUNT > 1
	)';

   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_ISID_BAK_153620 ADD CONSTRAINT ISID_BAK_153620_PK PRIMARY KEY(ISID_OID)';
END;

DECLARE
   CURSOR CUR_ISID_UPD
   IS
      SELECT *
		FROM 	(SELECT A.*,
					ROW_NUMBER ()
					OVER (
					PARTITION BY INSTR_ID,
                               MKT_OID,
                               ISS_ID,
                               ISS_USAGE_TYP,
                               START_TMS
                  ORDER BY END_TMS DESC )
                  COUNT
          FROM FT_T_ISID A
         WHERE     LAST_CHG_USR_ID IN ('BBGLMFND', 'BBEQEURO')
               AND ID_CTXT_TYP IN ('BBUNIQUE', 'TICKER'))
 WHERE COUNT > 1; 
 

   TYPE TYP_ISID_UPD IS TABLE OF CUR_ISID_UPD%ROWTYPE;

   VAR_ISID_UPD   TYP_ISID_UPD;

   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISID_UPD;

   LOOP
      FETCH CUR_ISID_UPD
         BULK COLLECT INTO VAR_ISID_UPD
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_UPD.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISID
            SET MERGE_UNIQ_OID = VAR_ISID_UPD (I).ISID_OID,
                LAST_CHG_USR_ID =
                   'GS:CON:153620:' || VAR_ISID_UPD (I).LAST_CHG_USR_ID
          WHERE    ISID_OID = VAR_ISID_UPD (I).ISID_OID
			AND 	INSTR_ID = VAR_ISID_UPD (I).INSTR_ID
            AND 	START_TMS = VAR_ISID_UPD (I).START_TMS
            AND 	ISS_ID = VAR_ISID_UPD (I).ISS_ID
            AND 	MKT_OID = VAR_ISID_UPD (I).MKT_OID
            AND 	ISS_USAGE_TYP = VAR_ISID_UPD (I).ISS_USAGE_TYP
			AND 	END_TMS IS NOT NULL;

      COMMIT;

      EXIT WHEN CUR_ISID_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS);

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || V_COUNT
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (V_COUNT).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES (
               'GSDM_Bloomberg_DL_Global_Equity_20190220.sql',
               1,
               'GT153620',
               SYSDATE,
               '8.99.9.0',
               '8.99.74.2',
               'A',
               SYSDATE);
COMMIT;

SET DEFINE ON;