SET DEFINE OFF;

-- |----------------------------------------------------------------
-- | Front Office #: 447816
-- | GT Ticket #:120400
-- | Date: 2015-09-21
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sushant Hole
-- | Approved By: Sapana Chaaparwal
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Select Script name : GSDM_Bloomberg_DL_Global_Equity_20150921_Select.sql
-- | Change Reason:Migration provided where ISID with BBCPGLOBAL and BBGLOBAL and MKT_OID = 'EXCH=00117' will get aligned with MKT_OID = '0001W2LM0m'. 
-- |----------------------------------------------------------------

DECLARE

    v_NumErrors     NUMBER(10);
    CURSOR CUR_ISID IS 
    SELECT ISID_OID FROM FT_T_ISID
    WHERE MKT_OID = 'EXCH=00117' AND ID_CTXT_TYP IN ('CPGLOBAL','BBGLOBAL');
   
    TYPE TAB_ISID IS TABLE OF CUR_ISID%ROWTYPE;
    
    P_BULKCLEANUP_ISID TAB_ISID;
    
BEGIN
    
--    FOR VAR_CUR_LSE_CODES IN CUR_LSE_CODES LOOP

OPEN    CUR_ISID;

LOOP

    FETCH  CUR_ISID BULK COLLECT INTO P_BULKCLEANUP_ISID LIMIT 1000;
    
        FORALL I IN 1..P_BULKCLEANUP_ISID.COUNT SAVE EXCEPTIONS
    
            UPDATE  FT_T_ISID
            SET     MKT_OID = '0001W2LM0m',
                    LAST_CHG_USR_ID = 'GS:MIG:120400:BBEQEURO'
            WHERE   ISID_OID =  P_BULKCLEANUP_ISID (I).ISID_OID;
        
    EXIT WHEN CUR_ISID%NOTFOUND;
    
    END LOOP;

    CLOSE CUR_ISID;
       
         EXCEPTION
               WHEN OTHERS THEN
                 DBMS_OUTPUT.PUT_LINE('Got exception: ' || SQLERRM);
                 v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
                 DBMS_OUTPUT.PUT_LINE(
                   'Number of errors during processing: ' || v_NumErrors);
                 FOR v_Count IN 1..v_NumErrors LOOP
                   DBMS_OUTPUT.PUT_LINE('Error ' || v_Count || ', iteration ' ||
                     SQL%BULK_EXCEPTIONS(v_Count).error_index || ' is: ' ||
                     SQLERRM(0 - SQL%BULK_EXCEPTIONS(v_Count).error_code));
                 END LOOP;

    
END;

 Insert INTO FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
 VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20150921.sql', 1, 'GT120400', SYSDATE, '8.99.1.0', '8.99.46.0', 'A',  SYSDATE);