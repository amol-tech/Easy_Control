-- |----------------------------------------------------------------
-- | Front Office #:456025
-- | GT Ticket #:139574
-- | Date: 2017-09-11
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Meeta Shamkure
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Change Reason: Script to select records in ISID having IDCTXTTYP IN ('CPTICKER', 'CPSEDOL', 'CPBBUNIQ', 'CPGLOBAL','WI-CPGLOBAL') AND DATASRCID = 'BB' 
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170914.sql
-- |----------------------------------------------------------------

SET DEFINE OFF;

(SELECT   *
  FROM   FT_t_ISID
 WHERE   MKT_OID IN
               (SELECT   A.MKT_OID
                  FROM   FT_t_MKID A, FT_t_MKID B
                 WHERE       A.MKT_ID_CTXT_TYP = 'BBEXCH'
                         AND B.MKT_ID_CTXT_TYP = 'BBCOMPEXCH'
                         AND A.MKT_ID = B.MKT_ID
                         AND A.MKT_OID != B.MKT_OID
                         AND A.DATA_SRC_ID = 'BB'
                         AND B.DATA_SRC_ID = 'BB'
                         AND A.END_TMS IS NULL
                         AND B.END_TMS IS NULL)
         AND ID_CTXT_TYP IN ('CPTICKER', 'CPSEDOL', 'CPBBUNIQ', 'CPGLOBAL','WI-CPGLOBAL')
         AND DATA_SRC_ID = 'BB'
         AND END_TMS IS NULL
         AND MKT_OID NOT IN
                  (SELECT   DISTINCT MKT_OID
                     FROM   FT_t_MKID
                    WHERE   MKT_ID IN ('IA','BC','ZS','GU','JY','EK','AI','NX','LN','LI')
                            AND MKT_ID_CTXT_TYP = 'BBEXCH'
                            AND DATA_SRC_ID = 'BB')
UNION
SELECT  *
   FROM   FT_T_ISID
  WHERE   INSTR_ID IN
                (SELECT   INSTR_ID
                   FROM   FT_T_ISID
                  WHERE   MKT_OID IN
                                (SELECT   DISTINCT MKT_OID
                                   FROM   FT_T_MKID
                                  WHERE   MKT_ID IN('IA','BC','ZS','GU','JY','EK','AI','NX','LN','LI')
                                          AND MKT_ID_CTXT_TYP = 'BBEXCH'
                                          AND DATA_SRC_ID = 'BB'
                                          AND END_TMS IS NULL)
                          AND ID_CTXT_TYP = 'CPTICKER'
                          AND DATA_SRC_ID = 'BB'
                          AND END_TMS IS NULL)
          AND ID_CTXT_TYP IN ('CPTICKER', 'CPSEDOL', 'CPBBUNIQ', 'CPGLOBAL','WI-CPGLOBAL')
          AND MKT_OID IN (SELECT   DISTINCT MKT_OID
                      FROM   FT_T_MKID
                     WHERE   MKT_ID IN ('IA','BC','ZS','GU','JY','EK','AI','NX','LN','LI')
                             AND MKT_ID_CTXT_TYP = 'BBEXCH'
                             AND DATA_SRC_ID = 'BB'
                             AND END_TMS IS NULL)
          AND DATA_SRC_ID = 'BB'
          AND END_TMS IS NULL);
          
SET DEFINE ON;          



