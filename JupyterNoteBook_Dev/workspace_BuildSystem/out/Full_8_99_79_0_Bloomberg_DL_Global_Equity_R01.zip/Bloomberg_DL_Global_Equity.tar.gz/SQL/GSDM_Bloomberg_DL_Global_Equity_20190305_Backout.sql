SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462389
-- | GT Ticket #:154683
-- | Date: 2019-03-05
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISMC
-- | Change Reason:Script to rollback changes made in Update script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190305.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_BAK_ISMC
   IS
      SELECT ISMC_OID, INSTR_ID
        FROM FT_T_ISMC
       WHERE     CAPITAL_TYP = 'CSEQSHS'
             AND LAST_CHG_USR_ID LIKE '%GS:CON:154683:BBEQEURO%';

   TYPE TYP_BAK_ISMC IS TABLE OF CUR_BAK_ISMC%ROWTYPE;

   VAR_BAK_ISMC   TYP_BAK_ISMC;
   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_BAK_ISMC;

   LOOP
      FETCH CUR_BAK_ISMC
         BULK COLLECT INTO VAR_BAK_ISMC
         LIMIT 10000;

      FORALL I IN 1 .. VAR_BAK_ISMC.COUNT SAVE EXCEPTIONS
         DELETE FT_T_ISMC
          WHERE     ISMC_OID = VAR_BAK_ISMC (I).ISMC_OID
                AND INSTR_ID = VAR_BAK_ISMC (I).INSTR_ID;

      COMMIT;
      EXIT WHEN CUR_BAK_ISMC%NOTFOUND;
   END LOOP;

   CLOSE CUR_BAK_ISMC;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;