SET DEFINE OFF;
--------------------------------------------------------------
-- | Front Office #: 442475
-- | GT Ticket #: 102991
-- | Date: 03/04/2014
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nilesh Desai
-- | Approved By: Abhijeet Dhuru
-- | Change Reason: Migration script provided to Update the PPDF.END_TMS with the date same as the PPDF.START_TMS and appending the same with time " 23:59:59" for SINKING funds.  
-- | Select Patch Name: GSDM_Bloomberg_DL_Global_Equity_20140403_SELECT.sql



update ft_T_ppdf set 
end_tms = to_date(to_char(START_TMS, 'mm-dd-yyyy') || '23:59:59', 'mm/dd/yyyy hh24:mi:ss') , last_chg_usr_id ='GS:CON:102991:BBEXTDPF'
where PRIN_PAY_DEF_ID 
in (select PRIN_PAY_DEF_ID from ft_t_ppdf where  PRIN_EV_PRT_ID  in (select PRIN_EV_PRT_ID  from FT_T_pevp where PRIN_EV_DEF_ID in (select PRIN_EV_DEF_ID from FT_T_pedf where ev_typ='SINKING')));


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'GSDM_Bloomberg_DL_Global_Equity_20140403.sql', 1,'GT102991', SYSDATE, '8.99.9.0','8.99.26.0', 'A',  SYSDATE);   

SET DEFINE ON;