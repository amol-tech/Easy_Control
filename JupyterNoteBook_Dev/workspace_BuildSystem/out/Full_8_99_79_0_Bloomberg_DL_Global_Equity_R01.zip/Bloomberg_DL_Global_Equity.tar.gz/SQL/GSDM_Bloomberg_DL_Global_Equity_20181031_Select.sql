SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:462342
-- | GT Ticket #:151805
-- | Date: 2018-10-31
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_MKIS
-- | Change Reason: Script to retrieve records from FT_T_MKIS created via BB GLobal Equity having MKIS.PRC_UT_MEAS_TYP='Blank'
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181031.sql
-- |----------------------------------------------------------------

SELECT *
  FROM FT_T_MKIS
 WHERE     END_TMS IS NULL
       AND PRC_UT_MEAS_TYP = 'Blank'
       AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

SET DEFINE ON;