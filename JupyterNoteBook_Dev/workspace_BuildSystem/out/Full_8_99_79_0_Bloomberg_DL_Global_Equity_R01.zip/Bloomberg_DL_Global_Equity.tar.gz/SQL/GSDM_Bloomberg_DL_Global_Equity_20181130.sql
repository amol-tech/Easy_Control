
SET DEFINE OFF;
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | FrontOffice ID: 461733
-- | GT Ticket #: 151138
-- | Date: 2018-11-30
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Mihir Sabnis
-- |--------------------------------------------------------------------------------------------------------------------------------
-- | Tables Affected:FT_T_ISST
-- | Change Reason: Script to update ISST.DENOM_CURR_CDE to null for ISST records which have been set up with
-- |                single instrument with STAT_DEF_ID='POSEURPR' for latest records and end-date old ISST records.
-- | Select Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181130_Select.sql
-- |--------------------------------------------------------------------------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE
      'CREATE TABLE FT_T_ISST_BACKUP_GT151138
                    AS
                    SELECT STAT_DEF_ID,
       INSTR_ID,
       LAST_CHG_USR_ID,
       START_TMS,
       DENOM_CURR_CDE,
       LAST_CHG_TMS,
       STAT_ID,
       END_TMS
  FROM FT_T_ISST
 WHERE STAT_ID IN
          (SELECT STAT_ID
             FROM (SELECT STAT_ID,
                          ROW_NUMBER ()
                          OVER (PARTITION BY INSTR_ID
                                ORDER BY LAST_CHG_TMS DESC)
                             CNT
                     FROM FT_T_ISST
                    WHERE STAT_DEF_ID = ''POSEURPR''
                    AND   LAST_CHG_USR_ID LIKE ''%BBEQEURO%'')
            WHERE CNT >= 1)
    AND END_TMS IS NULL';


   EXECUTE IMMEDIATE
      'ALTER TABLE FT_T_ISST_BACKUP_GT151138 ADD CONSTRAINT FT_T_ISST_BACKUP_GT151138_PK PRIMARY KEY(STAT_ID)';
END;

DECLARE
   v_NumErrors    NUMBER (10);

   CURSOR CUR_ISST_END
   IS
      SELECT STAT_DEF_ID,
             INSTR_ID,
             LAST_CHG_USR_ID,
             START_TMS,
             LAST_CHG_TMS,
             STAT_ID
        FROM FT_T_ISST
       WHERE     STAT_ID IN
                    (SELECT STAT_ID
                       FROM (SELECT STAT_ID,
                                    ROW_NUMBER ()
                                    OVER (PARTITION BY INSTR_ID
                                          ORDER BY LAST_CHG_TMS DESC)
                                       CNT
                               FROM FT_T_ISST
                              WHERE     STAT_DEF_ID = 'POSEURPR'
                                    AND LAST_CHG_USR_ID LIKE '%BBEQEURO%')
                      WHERE CNT > 1)
             AND END_TMS IS NULL;



   TYPE TAB_ISST_END IS TABLE OF CUR_ISST_END%ROWTYPE;



   VAR_ISST_END   TAB_ISST_END;



   CURSOR CUR_ISST_UPD
   IS
      SELECT STAT_DEF_ID,
             INSTR_ID,
             LAST_CHG_USR_ID,
             START_TMS,
             STAT_ID,
             DENOM_CURR_CDE
        FROM FT_T_ISST
       WHERE     STAT_DEF_ID = 'POSEURPR'
             AND LAST_CHG_USR_ID LIKE '%BBEQEURO%'
             AND END_TMS IS NULL
             AND DENOM_CURR_CDE IS NOT NULL;



   TYPE TAB_ISST_UPD IS TABLE OF CUR_ISST_UPD%ROWTYPE;

   VAR_ISST_UPD   TAB_ISST_UPD;
BEGIN
   OPEN CUR_ISST_END;

   LOOP
      FETCH CUR_ISST_END
         BULK COLLECT INTO VAR_ISST_END
         LIMIT 10000;


      FORALL I IN 1 .. VAR_ISST_END.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISST
            SET END_TMS = SYSDATE,
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:MIG:151138:' || LAST_CHG_USR_ID
          WHERE STAT_ID = VAR_ISST_END (I).STAT_ID;

      COMMIT;

      EXIT WHEN CUR_ISST_END%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISST_END;

   OPEN CUR_ISST_UPD;

   LOOP
      FETCH CUR_ISST_UPD
         BULK COLLECT INTO VAR_ISST_UPD
         LIMIT 10000;


      FORALL I IN 1 .. VAR_ISST_UPD.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISST
            SET DENOM_CURR_CDE = NULL,
                LAST_CHG_TMS = SYSDATE,
                LAST_CHG_USR_ID = 'GS:MIG:151138:' || LAST_CHG_USR_ID
          WHERE STAT_ID = VAR_ISST_UPD (I).STAT_ID;

      COMMIT;

      EXIT WHEN CUR_ISST_UPD%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISST_UPD;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || ' and Message ' || SQLERRM);
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
     VALUES ('GSDM_Bloomberg_DL_Global_Equity_20181130.sql',
             1,
             'GT151138',
             SYSDATE,
             '8.99.72.0',
             '8.99.73.3',
             'A',
             SYSDATE);

COMMIT;


SET DEFINE ON;