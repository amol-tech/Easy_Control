SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 462828
-- | GT Ticket #: 155136 
-- | Date: 2019-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities 
-- | Project ID: Connections 
-- | Requested By: Nusrat Khan
-- | Approved By: Adil Shaikh
-- |----------------------------------------------------------------
-- | Table Affected: FT_T_ISID
-- |
-- | Change Reason: Script to fetch records wherein one INSTR_ID have multiple ISS_IDs with same MKT_OID and ISS_USAGE_TYP from FT_T_ISID table.
-- |----------------------------------------------------------------



SELECT /*+ PARALLEL(16) */
      *
  FROM (SELECT INSTR_ID,
               ISID_OID,
               ISS_ID,
               ID_CTXT_TYP,
               MKT_OID,
               END_TMS,
               LAST_CHG_TMS,
               ISS_USAGE_TYP,
               LAST_CHG_USR_ID,
               ROW_NUMBER ()
               OVER (PARTITION BY  NVL (MKT_OID, 'A'), INSTR_ID, NVL (ISS_USAGE_TYP, 'B'), ID_CTXT_TYP
                     ORDER BY LAST_CHG_TMS DESC)
                  CNT
          FROM FT_T_ISID
         WHERE     ID_CTXT_TYP IN ('BBCMPSEC', 'WI-BBCMPSEC')
               AND DATA_SRC_ID = 'BB'
               AND END_TMS IS NULL)
 WHERE CNT > 1;


 SET DEFINE OFF;
