
SET DEFINE OFF;
-- |--------------------------------------------------------------------------------------------------------------------------------------------------------
-- | Front Office #: 460548
-- | GT Ticket #:149810
-- | Date: 2018-09-07
-- |---------------------------------------------------------------------------------------------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Pradnya Jadhav
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISID
-- | Reason: Script to revert changes made by GSDM_Bloomberg_DL_Global_Equity_20181001.sql script
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20181001.sql
-- |----------------------------------------------------------------
SET DEFINE OFF;

DECLARE
   v_NumErrors    NUMBER (10);

   CURSOR CUR_ISID_BAK
   IS
      SELECT * FROM FT_T_ISID_BKP_GT149810;


   TYPE TAB_ISID_BAK IS TABLE OF CUR_ISID_BAK%ROWTYPE;

   VAR_ISID_BAK   TAB_ISID_BAK;
BEGIN
   OPEN CUR_ISID_BAK;

   LOOP
      FETCH CUR_ISID_BAK
         BULK COLLECT INTO VAR_ISID_BAK
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISID_BAK.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISID
            SET GLOBAL_UNIQ_IND = VAR_ISID_BAK (I).GLOBAL_UNIQ_IND,
                LAST_CHG_USR_ID = VAR_ISID_BAK (I).LAST_CHG_USR_ID,
                LAST_CHG_TMS = VAR_ISID_BAK (I).LAST_CHG_TMS
          WHERE ISID_OID = VAR_ISID_BAK (I).ISID_OID;

      COMMIT;

      EXIT WHEN CUR_ISID_BAK%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISID_BAK;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Got exception with code: ' || SQLCODE || ' and Message ' || SQLERRM);
END;