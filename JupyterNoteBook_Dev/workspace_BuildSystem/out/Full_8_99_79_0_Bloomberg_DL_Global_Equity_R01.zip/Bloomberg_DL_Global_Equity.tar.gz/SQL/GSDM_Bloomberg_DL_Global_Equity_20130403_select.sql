-- |----------------------------------------------------------------
-- | Front Office #:438083
-- | GT Ticket #:89988
-- | Date: 2013-04-03
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rajath Shetty
-- | Approved By: Rajeshwari C
-- |----------------------------------------------------------------


SET DEFINE OFF;


SELECT eqst_oid FROM (SELECT eqst_oid,instr_id,mkt_oid,LAST_CHG_TMS  ,row_number()                     
over(partition by instr_id,mkt_oid ORDER BY LAST_CHG_TMS desc) cnt           
FROM FT_T_eqst where STATS_CURR_CDE is not NULL ) where cnt !=1;



SELECT eqst_oid FROM (SELECT eqst_oid,instr_id,mkt_oid,LAST_CHG_TMS  ,row_number()                     
over(partition by instr_id,mkt_oid ORDER BY LAST_CHG_TMS desc) cnt           
FROM FT_T_eqst where STATS_CURR_CDE is NULL ) where cnt !=1 ;



select eqst_oid from ft_T_eqst a 
where (select count(*) from ft_t_eqst b where a.instr_id=b.instr_id and a.MKT_OID=b.MKT_OID )>1 and  STATS_CURR_CDE is null;


SET DEFINE ON;