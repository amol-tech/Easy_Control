SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 438083
-- | GT Ticket #: 138515
-- | Date: 2017-08-28
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISID
-- | Change Reason: Migration Script provided inorder to rollback changes done through script  GSDM_Bloomberg_DL_Global_Equity_20170828.sql
-- |----------------------------------------------------------------
DECLARE
CURSOR CUR_ISID_BAK
IS 
SELECT * FROM FT_BAK_ISID_138515;

BEGIN
FOR I IN CUR_ISID_BAK
LOOP
UPDATE FT_T_ISID
SET ISS_ID=I.ISS_ID,
    LAST_CHG_USR_ID=I.LAST_CHG_USR_ID,
    LAST_CHG_TMS=I.LAST_CHG_TMS
WHERE ISID_OID=I.ISID_OID;

COMMIT;


END LOOP;

EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (
         'Error Code ' || SQLCODE || 'Error Message ' || SQLERRM
      ); 



END;
SET DEFINE ON;