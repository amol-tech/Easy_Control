SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 454205
-- | GT Ticket #: 132863
-- | Date: 2017-04-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_INCL, FT_T_FICL, FT_T_IRCL
-- | Change Reason: Script to end date on-the-fly created INCL records where INDUS_CL_SET_ID = 'NAICS' and change the pointing of corresponding child FICL,IRCL records.
-- | Query Patch: GSDM_Bloomberg_DL_Global_Equity_20170410_Select.sql
-- |----------------------------------------------------------------

BEGIN
   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_INCL_GT132863
AS SELECT   CLSF_OID,
         INDUS_CL_SET_ID,
         CL_VALUE,
         CL_NME,
         LEVEL_NUM,
         LAST_CHG_TMS,
         LAST_CHG_USR_ID,
         END_TMS
  FROM   FT_T_INCL
 WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
         AND (CL_VALUE, INDUS_CL_SET_ID) IN
                  (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                       FROM   FT_T_INCL
                      WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
                   GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                     HAVING   COUNT (1) > 1)
         AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%''
UNION
SELECT   CLSF_OID,
         INDUS_CL_SET_ID,
         CL_VALUE,
         CL_NME,
         LEVEL_NUM,
         LAST_CHG_TMS,
         LAST_CHG_USR_ID,
         END_TMS
  FROM   FT_T_INCL
 WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
         AND (CL_VALUE, INDUS_CL_SET_ID) IN
                  (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                       FROM   FT_T_INCL
                      WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
                   GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                     HAVING   COUNT (1) = 1)
         AND LEVEL_NUM IS NULL
         AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%''';

   EXECUTE IMMEDIATE 'ALTER TABLE FT_BAK_INCL_GT132863 ADD CONSTRAINT INCL_BAK_132863_PK PRIMARY KEY(CLSF_OID,CL_VALUE)';

   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_FICL_GT132863
AS
SELECT   FINS_CLSF_OID,
         INST_MNEM,
         INDUS_CL_SET_ID,
         CLSF_OID,
         CL_VALUE,
         LAST_CHG_USR_ID,
         LAST_CHG_TMS,
         END_TMS
  FROM   FT_T_FICL
 WHERE   END_TMS IS NULL
         AND (CL_VALUE, CLSF_OID) IN
                  (SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_BAK_INCL_GT132863
                    WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
                            AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%'')';

   EXECUTE IMMEDIATE 'CREATE TABLE FT_BAK_IRCL_GT132863
AS
SELECT   ISSR_CLSF_OID,
         INSTR_ISSR_ID,
         INDUS_CL_SET_ID,
         CLSF_OID,
         CL_VALUE,
         LAST_CHG_USR_ID,
         LAST_CHG_TMS,
         END_TMS
  FROM   FT_T_IRCL
 WHERE   END_TMS IS NULL
         AND (CL_VALUE, CLSF_OID) IN
                  (SELECT   CL_VALUE, CLSF_OID
                     FROM   FT_BAK_INCL_GT132863
                    WHERE   INDUS_CL_SET_ID = ''NAICS'' AND END_TMS IS NULL
                            AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%'')';
END;

DECLARE
   CURSOR CUR_INCL_UPD
   IS
      SELECT   *
        FROM   FT_T_INCL
       WHERE   INDUS_CL_SET_ID = 'NAICS'
               AND (CL_VALUE, INDUS_CL_SET_ID) IN
                        (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                             FROM   FT_T_INCL
                            WHERE   INDUS_CL_SET_ID = 'NAICS'
                         GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                           HAVING   COUNT (1) > 1)
               AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

   TYPE TAB_INCL_UPD IS TABLE OF CUR_INCL_UPD%ROWTYPE;

   VAR_INCL_UPD     TAB_INCL_UPD;

   CURSOR CUR_INCL_ENDDT
   IS
      SELECT   *
        FROM   FT_T_INCL
       WHERE   INDUS_CL_SET_ID = 'NAICS'
               AND (CL_VALUE, INDUS_CL_SET_ID) IN
                        (  SELECT   CL_VALUE, INDUS_CL_SET_ID
                             FROM   FT_T_INCL
                            WHERE   INDUS_CL_SET_ID = 'NAICS'
                         GROUP BY   CL_VALUE, INDUS_CL_SET_ID
                           HAVING   COUNT (1) = 1)
               AND LEVEL_NUM IS NULL
               AND LAST_CHG_USR_ID LIKE '%BBEQEURO%';

   TYPE TAB_INCL_ENDDT IS TABLE OF CUR_INCL_ENDDT%ROWTYPE;

   VAR_INCL_ENDDT   TAB_INCL_ENDDT;

   V_NUMERRORS      NUMBER (10);
BEGIN
   OPEN CUR_INCL_UPD;

   LOOP
      FETCH CUR_INCL_UPD BULK COLLECT INTO   VAR_INCL_UPD LIMIT 10000;



      FORALL I IN 1 .. VAR_INCL_UPD.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_INCL
            SET   END_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_UPD (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_UPD (I).CL_VALUE;

      COMMIT;


      FORALL I IN 1 .. VAR_INCL_UPD.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_FICL FICL
            SET
                  (CLSF_OID,
                  CL_VALUE
                  ) =
                     (SELECT   CLSF_OID, CL_VALUE
                        FROM   FT_T_INCL INCL
                       WHERE       END_TMS IS NULL
                               AND INCL.CL_VALUE = FICL.CL_VALUE
                               AND INDUS_CL_SET_ID = 'NAICS'),
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_UPD (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_UPD (I).CL_VALUE;

      COMMIT;

      FORALL I IN 1 .. VAR_INCL_UPD.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_IRCL IRCL
            SET
                  (CLSF_OID,
                  CL_VALUE
                  ) =
                     (SELECT   CLSF_OID, CL_VALUE
                        FROM   FT_T_INCL INCL
                       WHERE       END_TMS IS NULL
                               AND INCL.CL_VALUE = IRCL.CL_VALUE
                               AND INDUS_CL_SET_ID = 'NAICS'),
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_UPD (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_UPD (I).CL_VALUE;

      COMMIT;

      EXIT WHEN CUR_INCL_UPD%NOTFOUND;
   END LOOP;



   CLOSE CUR_INCL_UPD;

   OPEN CUR_INCL_ENDDT;

   LOOP
      FETCH CUR_INCL_ENDDT BULK COLLECT INTO   VAR_INCL_ENDDT LIMIT 10000;



      FORALL I IN 1 .. VAR_INCL_ENDDT.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_INCL
            SET   END_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_ENDDT (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_ENDDT (I).CL_VALUE;

      COMMIT;


      FORALL I IN 1 .. VAR_INCL_ENDDT.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_FICL FICL
            SET   END_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_ENDDT (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_ENDDT (I).CL_VALUE;

      COMMIT;

      FORALL I IN 1 .. VAR_INCL_ENDDT.COUNT
      SAVE EXCEPTIONS
         UPDATE   FT_T_IRCL IRCL
            SET   END_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:MIG:' || LAST_CHG_USR_ID || ':132863',
                  LAST_CHG_TMS = SYSDATE
          WHERE   CLSF_OID = VAR_INCL_ENDDT (I).CLSF_OID
                  AND CL_VALUE = VAR_INCL_ENDDT (I).CL_VALUE;

      COMMIT;

      EXIT WHEN CUR_INCL_ENDDT%NOTFOUND;
   END LOOP;



   CLOSE CUR_INCL_ENDDT;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || V_NUMERRORS
      );

      FOR V_COUNT IN 1 .. V_NUMERRORS
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || V_COUNT
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   ('GSDM_Bloomberg_DL_Global_Equity_20170410.sql',
            1,
            'GT132863',
            SYSDATE,
            '8.99.57.0',
            '8.99.61.0',
            'A',
            SYSDATE);

COMMIT;


SET DEFINE ON;