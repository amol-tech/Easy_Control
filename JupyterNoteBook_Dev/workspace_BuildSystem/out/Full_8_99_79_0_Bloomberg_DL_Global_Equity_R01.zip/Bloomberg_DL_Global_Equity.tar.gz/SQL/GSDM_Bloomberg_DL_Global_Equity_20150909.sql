-- |----------------------------------------------------------------
-- | Front Office #: 437116
-- | GT Ticket #: 120036
-- | Date: 2015-09-10
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Sakshi Mehta
-- | Approved By: Chiranjib Kakoti
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_BDST
-- | Select Patch Name: GSDM_Bloomberg_DL_Global_Equity_20150909_Select.sql
-- | Change Reason: To update the OUTST_CAMT to NULL for the BDST rows where OUTST_CAMT = 0 and DATA_SRC_ID = 'BLOOMBERG'
-- | 		    				These rows currently have the OUTST_CAMT = 0 which is misleading  as there are cases where the vendor does not know the actual value and we were setting this value as 0.
-- | Thus mapping has been modified to compare incoming value against ".00" and if it equals, Null will be populated in OUTST_CAMT.
--------------------------------------------------------------------


SET DEFINE OFF;

UPDATE  FT_T_BDST
SET     OUTST_CAMT = NULL,
        LAST_CHG_USR_ID = 'GS:MIG:BBEXTDPF:120036' 
WHERE   OUTST_CAMT = 0
AND     DATA_SRC_ID = 'BB'
and     LAST_CHG_USR_ID LIKE '%BBEXTDPF%';


Insert into FT_O_SCTL ( PATCH_ID, PATCH_SEQ_NUM, PATCH_ID_CTXT_TYP, RELEASE_TMS, BASE_MODL_VER_ID,CURR_MODL_VER_ID, PATCH_STAT_TYP, PATCH_APPLIED_TMS ) 
VALUES ( 'Bloomberg_DL_Global_Equity_20150909.sql', 1, 'GT120036',SYSDATE, '8.99.45.0', '8.99.46.0', 'A',  SYSDATE); 

SET DEFINE ON;




