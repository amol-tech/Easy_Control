SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 456436
-- | GT Ticket #:139015
-- | Date: 2017-10-12
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Umesh Swain
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_ISST, FT_T_MUST
-- | Change Reason: Script to move the ISST rows to MUST provided there is only a single active row in MKIS for the same instrument.
-- | Select Query : GSDM_Bloomberg_DL_Global_Equity_20171012_Select.sql
-- |----------------------------------------------------------------

BEGIN

EXECUTE IMMEDIATE 'CREATE TABLE FT_T_ISST_BKP_GT139015
AS SELECT      ISST.*, MKIS.MKT_ISS_OID
  FROM      (SELECT   *
               FROM   FT_T_ISST
              WHERE   STAT_DEF_ID = ''ADJIPOPX'' AND STAT_VAL_CAMT IS NOT NULL AND LAST_CHG_USR_ID LIKE ''%BBEQEURO%'' AND END_TMS IS NULL) ISST
         JOIN
            (SELECT   *
               FROM   FT_T_MKIS
              WHERE   INSTR_ID IN (  SELECT   INSTR_ID
                                       FROM   FT_T_MKIS
                                      WHERE   END_TMS IS NULL
                                   GROUP BY   INSTR_ID
                                     HAVING   COUNT ( * ) = 1) AND END_TMS IS NULL ) MKIS
         ON (ISST.INSTR_ID = MKIS.INSTR_ID)';

EXECUTE IMMEDIATE 'ALTER TABLE FT_T_ISST_BKP_GT139015 ADD CONSTRAINT FT_T_ISST_BKP_GT139015_PK PRIMARY KEY(STAT_ID)';         
         
END;


DECLARE
   v_NumErrors   NUMBER (10);

   CURSOR CUR_ISST
   IS
      SELECT   * FROM FT_T_ISST_BKP_GT139015;

   TYPE TAB_ISST IS TABLE OF CUR_ISST%ROWTYPE;

   VAR_TAB       TAB_ISST;
BEGIN
   OPEN CUR_ISST;

   LOOP
      FETCH CUR_ISST BULK COLLECT INTO   VAR_TAB LIMIT 1000;

      FORALL I IN 1 .. VAR_TAB.COUNT ()
      SAVE EXCEPTIONS
         INSERT INTO FT_T_MUST (MUST_OID,
                                MKT_ISS_OID,
                                STAT_DEF_ID,
                                START_TMS,
                                LAST_CHG_TMS,
                                LAST_CHG_USR_ID,
                                STAT_VAL_CAMT,
                                DATA_STAT_TYP,
                                DATA_SRC_ID)
            SELECT   NEW_OID (),
                     VAR_TAB (I).MKT_ISS_OID,
                     'ADJIPOPX',
                     SYSDATE,
                     SYSDATE,
                     'GS:CON:139015:BBEQEURO',
                     VAR_TAB (I).STAT_VAL_CAMT,
                     'ACTIVE',
                     'BB'
              FROM   DUAL
             WHERE   NOT EXISTS
                        (SELECT   'X'
                           FROM   FT_T_MUST
                          WHERE   STAT_DEF_ID = 'ADJIPOPX'
                                  AND MKT_ISS_OID = VAR_TAB (I).MKT_ISS_OID);

      COMMIT;

      FORALL J IN 1 .. VAR_TAB.COUNT () 
      SAVE EXCEPTIONS
         UPDATE   FT_T_ISST
            SET   END_TMS = SYSDATE,
                  LAST_CHG_TMS = SYSDATE,
                  LAST_CHG_USR_ID = 'GS:CON:139015:BBEQEURO'
          WHERE   STAT_ID = VAR_TAB (J).STAT_ID;


      COMMIT;

      EXIT WHEN CUR_ISST%NOTFOUND;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors
      );

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE(   'Error '
                              || v_Count
                              || ', iteration '
                              || SQL%BULK_EXCEPTIONS(v_Count).ERROR_INDEX
                              || ' is: '
                              || SQLERRM(0
                                         - SQL%BULK_EXCEPTIONS(v_Count).ERROR_CODE));
      END LOOP;
END;

INSERT INTO FT_O_SCTL (PATCH_ID,
                       PATCH_SEQ_NUM,
                       PATCH_ID_CTXT_TYP,
                       RELEASE_TMS,
                       BASE_MODL_VER_ID,
                       CURR_MODL_VER_ID,
                       PATCH_STAT_TYP,
                       PATCH_APPLIED_TMS)
  VALUES   ('GSDM_Bloomberg_DL_Global_Equity_20171012.sql',
            1,
            'GT139015',
            SYSDATE,
            '8.99.65.3',
            '8.99.70.0',
            'A',
            SYSDATE);

COMMIT;


SET DEFINE ON;	
