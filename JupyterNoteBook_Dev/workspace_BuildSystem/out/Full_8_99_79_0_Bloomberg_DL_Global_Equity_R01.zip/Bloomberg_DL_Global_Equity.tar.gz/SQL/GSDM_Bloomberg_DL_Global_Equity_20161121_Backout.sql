SET DEFINE OFF;
--------------------------------------------------------------
-- | Frontoffice ID #:452378
-- | GT Ticket #: 129547
-- | Date: 21 November 2016
-- | Product ID: GS Securities
-- | Project ID: BBDLGlobalEquity
-- | Requested By: Supriya Kadam
-- | Approved By: Mihir Sabnis
-- | Tables Affected:FT_T_MKIS
-- | Change Reason:Script to Rollback the changes made through GSDM_Bloomberg_DL_Global_Equity_20161121.sql
-- | Query Patch Name:GSDM_Bloomberg_DL_Global_Equity_20161121.sql
----------------------------------------------------------------
DECLARE
v_NumErrors NUMBER(10);

CURSOR CUR_MKIS_BAK
IS   (SELECT MKT_ISS_OID,TRDNG_UT_MEAS_TYP,LAST_CHG_USR_ID,LAST_CHG_TMS 
     FROM FT_BAK_MKIS_129547 
	 );
	 
TYPE TAB_MKIS IS TABLE OF CUR_MKIS_BAK%ROWTYPE;

VAR_MKIS TAB_MKIS;	 

BEGIN
OPEN CUR_MKIS_BAK;

LOOP
     
    FETCH CUR_MKIS_BAK BULK COLLECT INTO VAR_MKIS LIMIT 10000;
        
        FORALL I IN 1..VAR_MKIS.COUNT SAVE EXCEPTIONS
        
            UPDATE FT_T_MKIS
            SET TRDNG_UT_MEAS_TYP=VAR_MKIS(I).TRDNG_UT_MEAS_TYP,
                LAST_CHG_USR_ID=VAR_MKIS(I).LAST_CHG_USR_ID,
                LAST_CHG_TMS=VAR_MKIS(I).LAST_CHG_TMS
            WHERE MKT_ISS_OID=VAR_MKIS(I).MKT_ISS_OID
			AND  LAST_CHG_USR_ID='GS:MIG:BBEQEURO:129547';
            
            COMMIT;
         
         EXIT WHEN CUR_MKIS_BAK%NOTFOUND;
      
    END LOOP;
     
   CLOSE CUR_MKIS_BAK;  
   
   EXCEPTION
           WHEN OTHERS THEN
             DBMS_OUTPUT.PUT_LINE('Got exception: ' || SQLERRM);
             V_NUMERRORS := SQL%BULK_EXCEPTIONS.COUNT;
             DBMS_OUTPUT.PUT_LINE(
               'Number of errors during processing: ' || V_NUMERRORS);
             FOR V_COUNT IN 1..V_NUMERRORS LOOP
               DBMS_OUTPUT.PUT_LINE('Error ' || V_COUNT || ', iteration ' ||
                 SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_INDEX || ' is: ' ||
                 SQLERRM(0 - SQL%BULK_EXCEPTIONS(V_COUNT).ERROR_CODE));
             END LOOP;

END;

SET DEFINE ON;