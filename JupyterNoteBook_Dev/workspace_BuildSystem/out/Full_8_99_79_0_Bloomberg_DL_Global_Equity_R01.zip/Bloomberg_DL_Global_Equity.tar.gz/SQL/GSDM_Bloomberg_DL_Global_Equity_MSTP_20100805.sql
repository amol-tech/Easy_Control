INSERT INTO FT_CFG_MSTP ( MSTP_OID, MSG_TYP_NME, MAPPING_URI, BSFD_OID, VDDB_PROPAGATION_IND,
USE_KEY_TYP, MSG_KEY_XPATH, WRITE_EXCEPTION_TYP, WRITE_NOTFCN_TYP, SAVE_INPUT_MSG_TYP,
SAVE_TRANSLATED_MSG_TYP, SAVE_PROCESSED_MSG_TYP, LAST_CHG_TMS, LAST_CHG_USR_ID,
CAPTURE_PROCESSED_MSG_IND, ROLLBACK_ON_ERROR_IND, SYNC_PUBLISHING_IND,
SAVE_VENDOR_DATA_TYP,APPL_PROD_TYP ) VALUES ( 
new_oid(), 'BBPreferredExchangeTraded', 'db://resource/msf/Bloomberg/BBPreferredExchangeTraded.msf'
,(Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 'Y', 'Y', NULL, 'SUCCESS', 'WARNING', 'ERROR', 'ERROR', 'ERROR'
,  TO_Date( '06/17/2010 08:46:22 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'autobnp', 'N', 'N'
, 'N', 'None','SECURITIESANDPROD'); 


INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_namr.dif.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),1, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_asia.out.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),2, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_asia.dif.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),3, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_lamr.out.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),4, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_lamr.dif.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),5, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_euro.out.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),6, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

INSERT INTO FT_CFG_VFMT ( VND_FILE_NME, MSTP_OID, ROW_SEQ_NUM, BSFD_OID,
VND_FILE_GRP_NUM ) 
VALUES ( 'pfd_exch_euro.dif.gz.enc.20*', (Select mstp_oid from ft_cfg_mstp where msg_typ_nme='BBPreferredExchangeTraded'),7, (Select bsfd_oid from ft_cfg_bsfd where bf_nme='Bloomberg_DL_Global_Equity'), 0); 

