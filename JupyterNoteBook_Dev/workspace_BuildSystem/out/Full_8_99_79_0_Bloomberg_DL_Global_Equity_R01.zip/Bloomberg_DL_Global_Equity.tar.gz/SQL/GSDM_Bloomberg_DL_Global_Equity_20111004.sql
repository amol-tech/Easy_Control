-- |----------------------------------------------------------------
-- | Front Office #:
-- | GT Ticket #:71075
-- | Date: 2011-10-04
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Nived Soman
-- | Approved By: Kakoti Chiranjib
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISMC
-- | Change Reason: 
-- | 
-- |----------------------------------------------------------------

SET DEFINE OFF;

update  FT_T_ismc set end_tms=sysdate ,last_chg_usr_id='GSCON:MIG'  where ismc_oid in         
(Select ismc_oid from (Select ismc_oid,INSTR_id,last_chg_tms,row_number()                     
over(partition by INSTR_id,CAP_SEC_CQTY,CAPITAL_TYP order by last_chg_tms desc) cnt           
From ft_t_ismc where CAPITAL_TYP='OUTSTAND' and last_chg_usr_id ='BBEQEURO') where cnt !=1  );


SET DEFINE ON;