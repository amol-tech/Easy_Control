SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #: 453367
-- | GT Ticket #: 133077  
-- | Date: 2017-02-21
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: Bloomberg
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected: FT_T_IEDF
-- | Change Reason: Script to retrieve active records from IEDF where RTFX_BAS_TYP IS NOT NULL
-- | Select Script: GSDM_Bloomberg_DL_Global_Equity_20170221_Select.sql
-- |----------------------------------------------------------------

SELECT   *
  FROM   FT_T_IEDF
 WHERE       END_TMS IS NULL
         AND RTFX_BAS_TYP IS NOT NULL
         AND LAST_CHG_USR_ID LIKE '%BBEXTDPF%';

SET DEFINE ON;