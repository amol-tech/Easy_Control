SET DEFINE OFF;
-- |----------------------------------------------------------------
-- | Front Office #:463371
-- | GT Ticket #:154246
-- | Date: 2019-02-18
-- |----------------------------------------------------------------
-- | Product ID: GS Securities
-- | Project ID: BB
-- | Requested By: Rashmi Shahane
-- | Approved By: Mihir Sabnis
-- |----------------------------------------------------------------
-- | Tables Affected:FT_T_ISSU
-- | Change Reason: Script to revert back the changes made in Update script
-- | Update Query Patch: GSDM_Bloomberg_DL_Global_Equity_20190218.sql
-- |----------------------------------------------------------------

DECLARE
   CURSOR CUR_ISSU_BAK
   IS
      SELECT * FROM FT_BAK_ISSU_GT154246;

   TYPE TYP_ISSU_BAK IS TABLE OF CUR_ISSU_BAK%ROWTYPE;

   VAR_ISSU_BAK   TYP_ISSU_BAK;
   V_NUMERRORS    NUMBER (10);
BEGIN
   OPEN CUR_ISSU_BAK;

   LOOP
      FETCH CUR_ISSU_BAK
         BULK COLLECT INTO VAR_ISSU_BAK
         LIMIT 10000;

      FORALL I IN 1 .. VAR_ISSU_BAK.COUNT SAVE EXCEPTIONS
         UPDATE FT_T_ISSU
            SET ISS_TYP = VAR_ISSU_BAK (I).ISS_TYP,
                ISCD_OID = VAR_ISSU_BAK (I).ISCD_OID,
                EIST_OID = VAR_ISSU_BAK (I).EIST_OID,
                LAST_CHG_TMS = VAR_ISSU_BAK (I).LAST_CHG_TMS,
                LAST_CHG_USR_ID = VAR_ISSU_BAK (I).LAST_CHG_USR_ID
          WHERE INSTR_ID = VAR_ISSU_BAK (I).INSTR_ID;

      COMMIT;

      EXIT WHEN CUR_ISSU_BAK%NOTFOUND;
   END LOOP;

   CLOSE CUR_ISSU_BAK;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE ('Got exception: ' || SQLERRM);
      v_NumErrors := SQL%BULK_EXCEPTIONS.COUNT;
      DBMS_OUTPUT.PUT_LINE (
         'Number of errors during processing: ' || v_NumErrors);

      FOR v_Count IN 1 .. v_NumErrors
      LOOP
         DBMS_OUTPUT.PUT_LINE (
               'Error '
            || v_Count
            || ', iteration '
            || SQL%BULK_EXCEPTIONS (v_Count).ERROR_INDEX
            || ' is: '
            || SQLERRM (0 - SQL%BULK_EXCEPTIONS (v_Count).ERROR_CODE));
      END LOOP;
END;

SET DEFINE ON;